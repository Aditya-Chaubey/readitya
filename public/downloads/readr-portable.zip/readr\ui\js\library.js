// Library window (BKLibraryManager + Books shelf UI): records, collections, import, covers.
import * as store from './store.js';
import { parseEpub } from './epub.js';
import { icon } from './icons.js';
import { $, $$, h, esc, menu, alertDialog, toast, closePopovers } from './ui.js';
import { windowControls } from './titlebar.js';
import { showStylePicker, ensureStudioFonts } from './stylepicker.js';
import { resolveStudio } from './studio.js';

const PREFS_KEY = 'library-prefs.json';

const lib = { books: [], collections: [] };
const states = {}; // id -> reading state (progress, finished, opened)
let prefs = { view: 'grid', sort: 'recent', section: 'home' };
let query = '';
let readerSettings = {};
let linkStatus = {};      // native host: { id: { path, exists } } for books kept in their original location // settings.json (shared with reader windows): studio style, Apple theme, appearance

// ---------------- studio style tint for the library ----------------
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const mixHex = (a, b, t) => {
  const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
  const c = [16, 8, 0].map(sh => Math.round(((pa >> sh) & 255) + ((((pb >> sh) & 255) - ((pa >> sh) & 255)) * t)));
  return '#' + c.map(v => v.toString(16).padStart(2, '0')).join('');
};
const STYLE_VARS = ['--bg', '--sidebar', '--sb-sel', '--label', '--label2', '--label3', '--sep', '--fill', '--fill2', '--accent', '--lib-head-font', '--lib-head-case', '--lib-head-color', '--lib-ui-font'];
function applyLibraryStyle() {
  const root = document.documentElement.style;
  const t = readerSettings.studio && resolveStudio(readerSettings.studio, readerSettings.appearance || 'auto');
  for (const id of [...document.body.classList]) if (id.startsWith('lib-')) document.body.classList.remove(id);
  document.body.classList.toggle('studio', !!t);
  $('#btn-styles').classList.toggle('active-style', !!t);
  if (!t) {
    STYLE_VARS.forEach(v => root.removeProperty(v));
    root.colorScheme = '';
    $('#main').style.backgroundImage = $('#sidebar').style.backgroundImage = '';
    const dark = matchMedia('(prefers-color-scheme: dark)').matches;
    store.hostSend('chrome', dark ? '#1E1E1E' : '#FFFFFF', dark ? 'dark' : 'light');
    return;
  }
  ensureStudioFonts();
  const v = t.studio.v, st = t.studio;
  document.body.classList.add('lib-' + st.id);
  root.colorScheme = v.dark ? 'dark' : 'light';
  root.setProperty('--bg', v.bg);
  root.setProperty('--sidebar', mixHex(v.bg, v.dark ? '#ffffff' : '#000000', v.dark ? 0.045 : 0.035));
  root.setProperty('--sb-sel', rgba(v.link, v.dark ? 0.22 : 0.16));
  root.setProperty('--label', v.text);
  root.setProperty('--label2', v.soft);
  root.setProperty('--label3', v.faint);
  root.setProperty('--sep', rgba(v.text, 0.12));
  root.setProperty('--fill', rgba(v.text, 0.07));
  root.setProperty('--fill2', rgba(v.text, 0.13));
  root.setProperty('--accent', v.link);
  root.setProperty('--lib-head-font', st.head);
  root.setProperty('--lib-head-case', st.uiCase === 'uppercase' ? 'uppercase' : 'none');
  root.setProperty('--lib-head-color', v.head);
  root.setProperty('--lib-ui-font', st.ui);
  $('#main').style.backgroundImage = st.texture;
  $('#sidebar').style.backgroundImage = st.texture;
  store.hostSend('chrome', v.bg, v.dark ? 'dark' : 'light');
}
async function pickStyle(id) {
  // merge into the latest settings.json so reader-side settings are never clobbered
  const latest = (await store.load('settings.json', {})) || {};
  latest.studio = id;
  readerSettings = { ...readerSettings, ...latest };
  store.save('settings.json', latest, 0);
  await store.flush('settings.json');
  store.broadcast({ type: 'settings', from: 'library', settings: { studio: id } });
  applyLibraryStyle();
}

// ---------------- data ----------------
async function loadAll() {
  const data = await store.load('library.json', null);
  if (data) Object.assign(lib, { books: data.books || [], collections: data.collections || [] });
  prefs = { ...prefs, ...(await store.load(PREFS_KEY, {})) };
  readerSettings = (await store.load('settings.json', {})) || {};
  await refreshLinks();
  await Promise.all(lib.books.map(async b => { states[b.id] = (await store.load(`state/${b.id}.json`, {})) || {}; }));
}
const saveLib = () => store.save('library.json', lib, 150);
const savePrefs = () => store.save(PREFS_KEY, prefs, 300);

const progressOf = b => (states[b.id] && states[b.id].fraction) || 0;
const lastOpen = b => Math.max((states[b.id] && (states[b.id].opened || states[b.id].updated)) || 0, 0);
const isFinished = b => !!(b.finished || (states[b.id] && states[b.id].finished && !b.unfinished));
const isNew = b => !lastOpen(b) && !isFinished(b);

// ---------------- sidebar ----------------
const SECTIONS = [
  { id: 'home', label: 'Home', icon: 'house' },
  { header: 'Library' },
  { id: 'all', label: 'All', icon: 'books' },
  { id: 'want', label: 'Want to Read', icon: 'wantToRead' },
  { id: 'finished', label: 'Finished', icon: 'finished' },
  { id: 'books', label: 'Books', icon: 'book' },
  { id: 'pdfs', label: 'PDFs', icon: 'pdf' },
];

function renderSidebar() {
  const box = $('#sb-items');
  box.innerHTML = '';
  for (const s of SECTIONS) {
    if (s.header) { box.append(h('div', { class: 'sb-header' }, s.header)); continue; }
    box.append(sbItem(s.id, s.label, s.icon));
  }
  box.append(h('div', { class: 'sb-header' }, 'My Collections'));
  for (const c of lib.collections) {
    const it = sbItem('c:' + c.id, c.title, 'listBullets');
    it.addEventListener('contextmenu', e => {
      e.preventDefault();
      menu(e.clientX, e.clientY, [
        { label: 'Rename', action: () => renameCollection(c) },
        { label: 'Delete Collection', action: () => deleteCollection(c) },
      ]);
    });
    it.addEventListener('dblclick', () => renameCollection(c));
    // drop books onto a collection
    it.addEventListener('dragover', e => { if (e.dataTransfer.types.includes('text/book-id')) { e.preventDefault(); it.classList.add('drop-target'); } });
    it.addEventListener('dragleave', () => it.classList.remove('drop-target'));
    it.addEventListener('drop', e => {
      e.preventDefault(); it.classList.remove('drop-target');
      const id = e.dataTransfer.getData('text/book-id');
      if (id && !c.members.includes(id)) { c.members.push(id); saveLib(); toast(`Added to “${c.title}”`); }
    });
    box.append(it);
  }
  box.append(h('button', { class: 'sb-item sb-new', onclick: () => newCollection() }, h('span', { class: 'sb-icon', html: icon('plus') }), h('span', {}, 'New Collection')));
}
function sbItem(id, label, ic) {
  const el = h('button', { class: 'sb-item' + (prefs.section === id && !query ? ' on' : ''), 'data-id': id },
    h('span', { class: 'sb-icon', html: icon(ic) }), h('span', { class: 'sb-label' }, label));
  el.onclick = () => { query = ''; $('#search').value = ''; go(id); };
  return el;
}
function go(id) {
  prefs.section = id;
  savePrefs();
  renderSidebar();
  render();
  $('#content').scrollTop = 0;
}

// ---------------- collections ----------------
async function newCollection(withBook) {
  const title = await alertDialog({ title: 'New Collection', message: 'Enter a name for this collection.', ok: 'Create', input: 'New Collection' });
  if (!title || !title.trim()) return;
  const c = { id: store.uid(), title: title.trim(), members: withBook ? [withBook.id] : [], created: Date.now() };
  lib.collections.push(c);
  saveLib();
  go('c:' + c.id);
}
async function renameCollection(c) {
  const t = await alertDialog({ title: 'Rename Collection', ok: 'Rename', input: c.title });
  if (t && t.trim()) { c.title = t.trim(); saveLib(); renderSidebar(); render(); }
}
async function deleteCollection(c) {
  const ok = await alertDialog({ title: `Delete “${c.title}”?`, message: 'The books in this collection will stay in your library.', ok: 'Delete', danger: true });
  if (!ok) return;
  lib.collections = lib.collections.filter(x => x !== c);
  saveLib();
  if (prefs.section === 'c:' + c.id) go('all'); else renderSidebar();
}

// ---------------- views ----------------
function sectionBooks(id) {
  const all = lib.books;
  switch (id) {
    case 'all': return all;
    case 'want': return all.filter(b => b.want);
    case 'finished': return all.filter(isFinished);
    case 'books': return all.filter(b => b.kind === 'epub');
    case 'pdfs': return all.filter(b => b.kind === 'pdf');
    default:
      if (id.startsWith('c:')) {
        const c = lib.collections.find(c => 'c:' + c.id === id);
        return c ? c.members.map(m => all.find(b => b.id === m)).filter(Boolean) : [];
      }
      return all;
  }
}
function sectionTitle(id) {
  if (query) return 'Search';
  const s = SECTIONS.find(s => s.id === id);
  if (s) return s.label;
  const c = lib.collections.find(c => 'c:' + c.id === id);
  return c ? c.title : 'Library';
}
function sorted(list) {
  const by = prefs.sort;
  const cmp = (a, b) => (a || '').localeCompare(b || '', undefined, { sensitivity: 'base', numeric: true });
  const out = list.slice();
  if (by === 'title') out.sort((a, b) => cmp(a.sortTitle || a.title, b.sortTitle || b.title));
  else if (by === 'author') out.sort((a, b) => cmp(a.sortAuthor || a.author, b.sortAuthor || b.author) || cmp(a.title, b.title));
  else if (by === 'manual' && prefs.section.startsWith('c:')) return out;
  else out.sort((a, b) => Math.max(lastOpen(b), b.added || 0) - Math.max(lastOpen(a), a.added || 0));
  return out;
}

function render() {
  const content = $('#content');
  const id = prefs.section;
  $('#mt-title').textContent = sectionTitle(id);
  const showControls = id !== 'home' || query;
  $('#btn-sort').style.visibility = showControls ? '' : 'hidden';
  $('#view-seg').style.visibility = showControls ? '' : 'hidden';
  renderToolbar();
  content.innerHTML = '';
  if (!lib.books.length) return renderEmpty(content);
  if (query) {
    const q = query.toLocaleLowerCase();
    const res = lib.books.filter(b => (b.title + ' ' + (b.author || '') + ' ' + (b.series || '')).toLocaleLowerCase().includes(q));
    content.append(h('h1', { class: 'page-title' }, `Results for “${query}”`));
    if (!res.length) content.append(h('div', { class: 'no-results' }, 'No Results'));
    else content.append(prefs.view === 'list' ? listView(sorted(res)) : gridView(sorted(res)));
    return;
  }
  if (id === 'home') return renderHome(content);
  const books = sorted(sectionBooks(id));
  content.append(h('h1', { class: 'page-title' }, sectionTitle(id)));
  if (!books.length) {
    const msgs = {
      want: ['No Books', 'Books you add to Want to Read appear here.'],
      finished: ['No Finished Books', 'Books you finish reading appear here.'],
      pdfs: ['No PDFs', 'Add PDFs to your library to see them here.'],
    };
    const [t, m] = msgs[id] || ['No Books', id.startsWith('c:') ? 'Drag books to this collection in the sidebar, or use the … menu on a book.' : 'Add books to see them here.'];
    content.append(h('div', { class: 'empty-section' }, h('div', { class: 'es-title' }, t), h('div', {}, m)));
    return;
  }
  content.append(prefs.view === 'list' ? listView(books) : gridView(books));
}

function renderToolbar() {
  const sortNames = { recent: 'Recent', title: 'Title', author: 'Author', manual: 'Manually' };
  $('#btn-sort').innerHTML = `<span>Sort by ${sortNames[prefs.sort] || 'Recent'}</span>` + icon('chevronDown');
  const seg = $('#view-seg');
  seg.innerHTML = '';
  for (const [v, ic, t] of [['grid', 'grid', 'Grid'], ['list', 'rows', 'List']]) {
    seg.append(h('button', { class: prefs.view === v ? 'on' : '', title: t, html: icon(ic), onclick: () => { prefs.view = v; savePrefs(); render(); } }));
  }
}

function renderEmpty(content) {
  content.append(h('div', { class: 'empty' },
    h('div', { class: 'empty-art', html: icon('books') }),
    h('div', { class: 'empty-title' }, 'Your Library Is Empty'),
    h('div', { class: 'empty-msg' }, 'Drag EPUB books or PDFs here, or add them from your computer.'),
    h('button', { class: 'btn btn-primary', onclick: pickFiles }, 'Add Books…')));
}

function renderHome(content) {
  content.append(h('h1', { class: 'page-title' }, 'Home'));
  const reading = lib.books.filter(b => lastOpen(b) && !isFinished(b)).sort((a, b) => lastOpen(b) - lastOpen(a)).slice(0, 12);
  if (reading.length) content.append(shelf('Continue', reading, 'all', true));
  const want = lib.books.filter(b => b.want && !isFinished(b));
  if (want.length) content.append(shelf('Want to Read', want, 'want'));
  const recent = lib.books.slice().sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 20);
  content.append(shelf('Recently Added', recent, 'all'));
  const finished = lib.books.filter(isFinished);
  if (finished.length) content.append(shelf('Finished', finished, 'finished'));
}
function shelf(title, books, target, large) {
  const head = h('div', { class: 'shelf-head' },
    h('button', { class: 'shelf-title', onclick: () => go(target) }, title, h('span', { html: icon('chevronRight') })));
  const row = h('div', { class: 'shelf-row' + (large ? ' large' : '') });
  for (const b of books) row.append(bookCell(b, large));
  return h('section', { class: 'shelf' }, head, row);
}

function gridView(books) {
  const grid = h('div', { class: 'grid' });
  for (const b of books) grid.append(bookCell(b));
  return grid;
}

async function refreshLinks() {
  if (!store.isHost) return;
  linkStatus = await store.links();
}
const isMissing = b => !!(linkStatus[b.id] && !linkStatus[b.id].exists);

function statusEl(b) {
  if (isMissing(b)) return h('span', { class: 'status missing', title: linkStatus[b.id].path }, 'Missing');
  if (isFinished(b)) return h('span', { class: 'status finished' }, 'Finished');
  if (isNew(b)) return h('span', { class: 'status new' }, 'NEW');
  const p = progressOf(b);
  return h('span', { class: 'status' }, `${Math.max(1, Math.round(p * 100))}%`);
}

function coverEl(b, cls = '') {
  const wrap = h('div', { class: 'cover ' + cls });
  if (b.cover) {
    const img = h('img', { src: b.cover, alt: '', loading: 'lazy', decoding: 'async', draggable: 'false' });
    img.onload = () => { wrap.style.aspectRatio = `${img.naturalWidth} / ${img.naturalHeight}`; wrap.classList.add('loaded'); };
    img.onerror = () => { wrap.replaceWith(genericCover(b, cls)); };
    if (b.coverRatio) wrap.style.aspectRatio = String(b.coverRatio);
    wrap.append(img);
  } else return genericCover(b, cls);
  if (b.kind === 'pdf') wrap.classList.add('pdf');
  return wrap;
}
// generic cover (genericCoverTemplate): colour from the title, serif title + author
function genericCover(b, cls = '') {
  let hsh = 0;
  for (const ch of b.title || '') hsh = (hsh * 31 + ch.charCodeAt(0)) | 0;
  const hue = Math.abs(hsh) % 360;
  return h('div', { class: 'cover generic loaded ' + cls, style: { '--h': hue, aspectRatio: b.kind === 'pdf' ? '0.773' : '0.66' } },
    h('div', { class: 'gc-title' }, b.title || 'Untitled'),
    h('div', { class: 'gc-rule' }),
    h('div', { class: 'gc-author' }, b.author || ''));
}

function bookCell(b, large) {
  const cell = h('div', { class: 'book' + (large ? ' large' : ''), 'data-id': b.id, title: b.title + (b.author ? '\n' + b.author : '') });
  const art = h('div', { class: 'book-art' }, coverEl(b));
  art.draggable = true;
  art.addEventListener('dragstart', e => { e.dataTransfer.setData('text/book-id', b.id); e.dataTransfer.effectAllowed = 'copy'; });
  art.onclick = () => openBook(b);
  const more = h('button', { class: 'more icon-btn', title: 'More', html: icon('more') });
  more.onclick = e => { e.stopPropagation(); const r = more.getBoundingClientRect(); bookMenu(b, r.left, r.bottom + 4); };
  const meta = h('div', { class: 'book-meta' }, statusEl(b), more);
  cell.append(art, meta);
  if (large) cell.append(h('div', { class: 'book-title' }, b.title), h('div', { class: 'book-author' }, b.author || ''));
  if (large && !isNew(b)) {
    const p = progressOf(b);
    art.append(h('div', { class: 'progress-bar' }, h('div', { style: { width: Math.max(2, p * 100) + '%' } })));
  }
  cell.addEventListener('contextmenu', e => { e.preventDefault(); bookMenu(b, e.clientX, e.clientY); });
  return cell;
}

function listView(books) {
  const table = h('div', { class: 'list' });
  table.append(h('div', { class: 'list-head' }, h('span'), h('span', {}, 'Title'), h('span', {}, 'Author'), h('span', {}, 'Kind'), h('span', {}, 'Progress'), h('span', {}, 'Date Added'), h('span')));
  for (const b of books) {
    const p = isMissing(b) ? 'Missing' : isFinished(b) ? 'Finished' : isNew(b) ? 'New' : `${Math.max(1, Math.round(progressOf(b) * 100))}%`;
    const more = h('button', { class: 'icon-btn more', html: icon('more') });
    more.onclick = e => { e.stopPropagation(); const r = more.getBoundingClientRect(); bookMenu(b, r.left, r.bottom + 4); };
    const row = h('div', { class: 'list-row', 'data-id': b.id },
      h('span', { class: 'list-cover' }, coverEl(b, 'mini')),
      h('span', { class: 'list-title' }, b.title),
      h('span', { class: 'list-author' }, b.author || ''),
      h('span', {}, b.kind === 'pdf' ? 'PDF' : 'Book'),
      h('span', {}, p),
      h('span', {}, b.added ? new Date(b.added).toLocaleDateString() : ''),
      more);
    row.ondblclick = () => openBook(b);
    row.onclick = () => { $$('.list-row.on').forEach(r => r.classList.remove('on')); row.classList.add('on'); };
    row.addEventListener('contextmenu', e => { e.preventDefault(); bookMenu(b, e.clientX, e.clientY); });
    row.draggable = true;
    row.addEventListener('dragstart', e => e.dataTransfer.setData('text/book-id', b.id));
    table.append(row);
  }
  return table;
}

function bookMenu(b, x, y) {
  const inCollection = prefs.section.startsWith('c:') && lib.collections.find(c => 'c:' + c.id === prefs.section);
  menu(x, y, [
    { label: 'Open', action: () => openBook(b) },
    { sep: true },
    isFinished(b)
      ? { label: 'Mark as Still Reading', action: () => setFinished(b, false) }
      : { label: 'Mark as Finished', action: () => setFinished(b, true) },
    b.want ? { label: 'Remove from Want to Read', action: () => { b.want = false; saveLib(); render(); } }
      : { label: 'Add to Want to Read', action: () => { b.want = true; saveLib(); render(); toast('Added to Want to Read'); } },
    {
      label: 'Add to Collection', submenu: [
        ...lib.collections.map(c => ({
          label: c.title, checked: c.members.includes(b.id),
          action: () => { if (!c.members.includes(b.id)) { c.members.push(b.id); saveLib(); toast(`Added to “${c.title}”`); } },
        })),
        lib.collections.length ? { sep: true } : null,
        { label: 'New Collection…', action: () => newCollection(b) },
      ],
    },
    inCollection ? { label: `Remove from “${inCollection.title}”`, action: () => { inCollection.members = inCollection.members.filter(m => m !== b.id); saveLib(); render(); } } : null,
    { sep: true },
    store.isHost ? { label: 'Show in File Explorer', action: () => store.hostSend('reveal', b.id + '/' + (b.kind === 'pdf' ? (b.file || 'book.pdf') : (b.root || 'content'))) } : null,
    { label: 'Remove…', action: () => removeBook(b) },
  ]);
}

async function setFinished(b, on) {
  b.finished = on ? Date.now() : null;
  b.unfinished = !on;
  const s = (states[b.id] = states[b.id] || {});
  if (!on) { s.finished = null; store.save(`state/${b.id}.json`, s, 50); }
  saveLib();
  render();
}

async function removeBook(b) {
  const linked = !!linkStatus[b.id];
  const ok = await alertDialog({
    title: `Remove “${b.title}”?`,
    message: linked ? 'This book will be removed from your library. The file itself stays where it is.' : 'This book will be removed from your library and deleted from this computer.',
    ok: 'Remove', danger: true,
  });
  if (!ok) return;
  lib.books = lib.books.filter(x => x !== b);
  for (const c of lib.collections) c.members = c.members.filter(m => m !== b.id);
  saveLib();
  await store.flush('library.json');
  await store.deleteBook(b.id);
  render();
}

function openBook(b) {
  if (isMissing(b)) {
    alertDialog({ title: `Can’t Find “${b.title}”`, message: `The file was moved or deleted:\n${linkStatus[b.id].path}\n\nOpen it again with readr. from its new location, or remove it from your library.`, ok: 'OK', cancel: null });
    return;
  }
  const url = `/ui/reader.html?id=${encodeURIComponent(b.id)}`;
  const cell = document.querySelector(`.book[data-id="${CSS.escape(b.id)}"] .cover`);
  if (cell) { cell.classList.add('opening'); setTimeout(() => cell.classList.remove('opening'), 500); }
  states[b.id] = { ...(states[b.id] || {}), opened: Date.now() };
  if (store.isHost) window.open(url, '_blank');
  else location.href = url;
  setTimeout(render, 600);
}

// ---------------- import ----------------
// In the native app the host shows the picker / receives dropped files, so it knows their real paths
// and links them in place (no copies). The browser dev build uploads bytes instead.
function pickFiles() {
  if (store.isHost) store.hostSend('pick');
  else $('#file-input').click();
}

async function importFiles(files) {
  files = [...files].filter(f => /\.(epub|pdf)$/i.test(f.name));
  if (!files.length) { toast('readr. opens EPUB and PDF files.'); return; }
  const box = $('#importing');
  box.classList.add('on');
  let added = 0, lastAdded = null;
  for (let i = 0; i < files.length; i++) {
    box.innerHTML = `<div class="spinner"></div><span>Adding ${files.length > 1 ? `${i + 1} of ${files.length}` : `“${esc(files[i].name)}”`}…</span>`;
    try {
      const rec = await addToLibrary(() => store.importFile(files[i]), files[i].name, files[i].size);
      if (rec) { added++; lastAdded = rec; }
    } catch (e) {
      console.error(e);
      toast(`Couldn’t add “${files[i].name}”`);
    }
  }
  box.classList.remove('on');
  if (added) {
    saveLib();
    if (prefs.section === 'home' || prefs.section === 'finished' || prefs.section === 'want') prefs.section = 'all';
    renderSidebar();
    render();
    toast(added === 1 ? `Added “${lastAdded.title}”` : `Added ${added} items`);
  }
  return lastAdded;
}

async function addToLibrary(doImport, name, size) {
  const r = await doImport();
  let rec;
  if (r.kind === 'epub') {
    const base = `/lib/${r.id}/${r.root}/`;
    let meta;
    try { meta = await parseEpub(base); }
    catch (e) { await store.deleteBook(r.id); throw e; }
    const dupe = lib.books.find(b => b.kind === 'epub' && meta.identifier && b.identifier === meta.identifier && b.title === meta.title);
    if (dupe) { await store.deleteBook(r.id); toast(`“${meta.title}” is already in your library`); return null; }
    rec = {
      id: r.id, kind: 'epub', root: r.root, fileName: name, size,
      title: meta.title, sortTitle: sortTitle(meta.title), author: meta.author, sortAuthor: meta.sortAuthor,
      language: meta.language, identifier: meta.identifier, publisher: meta.publisher, description: meta.description,
      series: meta.series, seriesIndex: meta.seriesIndex, ppd: meta.ppd, fixedLayout: meta.fixedLayout,
      cover: meta.coverURL ? new URL(meta.coverURL).pathname : null,
      added: Date.now(),
    };
    if (rec.cover) {
      const ratio = await imageRatio(rec.cover);
      if (ratio) rec.coverRatio = ratio;
    }
  } else {
    rec = { id: r.id, kind: 'pdf', file: r.file, fileName: name, size, title: name.replace(/\.pdf$/i, ''), author: '', added: Date.now() };
    try { Object.assign(rec, await pdfInfo(rec)); } catch (e) { console.warn(e); }
    rec.sortTitle = sortTitle(rec.title);
    rec.sortAuthor = rec.author;
  }
  lib.books.push(rec);
  states[rec.id] = {};
  return rec;
}
const sortTitle = t => (t || '').replace(/^(the|a|an)\s+/i, '');
function imageRatio(src) {
  return new Promise(res => { const i = new Image(); i.onload = () => res(i.naturalWidth / i.naturalHeight); i.onerror = () => res(null); i.src = src; });
}
async function pdfInfo(rec) {
  const pdfjs = await import('../vendor/pdfjs/pdf.min.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc = '/ui/vendor/pdfjs/pdf.worker.min.mjs';
  const pdf = await pdfjs.getDocument({ url: `/lib/${rec.id}/${rec.file}`, disableRange: true, isEvalSupported: false }).promise;
  const out = {};
  try {
    const { info } = await pdf.getMetadata();
    if (info && info.Title && info.Title.trim().length > 1 && !/^untitled|\.(docx?|pdf)$/i.test(info.Title.trim())) out.title = info.Title.trim();
    if (info && info.Author) out.author = info.Author.trim();
  } catch {}
  out.pages = pdf.numPages;
  // cover = first page
  const page = await pdf.getPage(1);
  const vp = page.getViewport({ scale: 1 });
  const scale = 520 / vp.width;
  const v = page.getViewport({ scale });
  const c = document.createElement('canvas');
  c.width = Math.round(v.width); c.height = Math.round(v.height);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: ctx, viewport: v, intent: 'print' }).promise;
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.86));
  await store.writeFile(`${rec.id}/cover.jpg`, blob);
  out.cover = `/lib/${rec.id}/cover.jpg`;
  out.coverRatio = c.width / c.height;
  pdf.destroy();
  return out;
}

// ---------------- wiring ----------------
function setupDrop() {
  const drop = $('#drop');
  let depth = 0;
  const hasFiles = e => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  document.addEventListener('dragenter', e => { if (!hasFiles(e)) return; e.preventDefault(); depth++; drop.classList.add('on'); });
  document.addEventListener('dragleave', e => { if (!hasFiles(e)) return; depth = Math.max(0, depth - 1); if (!depth) drop.classList.remove('on'); });
  document.addEventListener('dragover', e => { if (hasFiles(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
  document.addEventListener('drop', e => {
    if (!hasFiles(e)) return;
    e.preventDefault(); depth = 0; drop.classList.remove('on');
    if (store.isHost && window.chrome.webview.postMessageWithAdditionalObjects) window.chrome.webview.postMessageWithAdditionalObjects('drop', e.dataTransfer.files);
    else importFiles(e.dataTransfer.files);
  });
}

async function main() {
  const wc = windowControls();
  if (wc) $('.mt-actions').append(wc);
  $('.sb-search-icon').innerHTML = icon('search');
  $('#btn-styles').innerHTML = icon('palette');
  $('#btn-styles').onclick = e => showStylePicker(e.currentTarget, readerSettings, pickStyle);
  $('#btn-add').innerHTML = icon('plus');
  $('#drop .drop-icon').innerHTML = icon('upload');
  await loadAll();
  renderSidebar();
  render();
  applyLibraryStyle();
  document.body.classList.add('ready');

  $('#btn-add').onclick = pickFiles;
  $('#file-input').onchange = e => { importFiles(e.target.files); e.target.value = ''; };
  $('#btn-sort').onclick = e => {
    const r = e.currentTarget.getBoundingClientRect();
    const opts = [['recent', 'Recent'], ['title', 'Title'], ['author', 'Author']];
    if (prefs.section.startsWith('c:')) opts.push(['manual', 'Manually']);
    menu(r.left, r.bottom + 4, opts.map(([v, l]) => ({ label: l, checked: prefs.sort === v, action: () => { prefs.sort = v; savePrefs(); render(); } })));
  };
  const search = $('#search');
  search.addEventListener('input', () => { query = search.value.trim(); renderSidebar(); render(); });
  search.addEventListener('keydown', e => { if (e.key === 'Escape') { search.value = ''; query = ''; renderSidebar(); render(); search.blur(); } });
  document.addEventListener('keydown', e => {
    const ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && (e.key === 'o' || e.key === 'O')) { e.preventDefault(); pickFiles(); }
    if (ctrl && (e.key === 'f' || e.key === 'F')) { e.preventDefault(); search.focus(); search.select(); }
    if (ctrl && e.shiftKey && (e.key === 'n' || e.key === 'N')) { e.preventDefault(); newCollection(); }
  });
  document.addEventListener('contextmenu', e => { if (!e.target.closest('input')) e.preventDefault(); });
  setupDrop();

  // live progress from reader windows
  store.onBroadcast(m => {
    if (m.type === 'settings' && m.from !== 'library' && m.settings) {
      const before = `${readerSettings.studio}|${readerSettings.appearance}`;
      readerSettings = { ...readerSettings, studio: m.settings.studio, appearance: m.settings.appearance, theme: m.settings.theme };
      if (`${readerSettings.studio}|${readerSettings.appearance}` !== before) applyLibraryStyle();
    }
    if (m.type === 'progress' && states[m.id] !== undefined) {
      states[m.id] = { ...(states[m.id] || {}), fraction: m.fraction, opened: m.lastOpen };
      clearTimeout(main._t); main._t = setTimeout(render, 300);
    }
    if (m.type === 'finished') {
      const b = lib.books.find(b => b.id === m.id);
      if (b && !b.finished) { states[m.id] = { ...(states[m.id] || {}), finished: Date.now() }; b.unfinished = false; saveLib(); render(); }
    }
  });
  window.addEventListener('focus', async () => {
    await refreshLinks();
    await Promise.all(lib.books.map(async b => { states[b.id] = (await store.load(`state/${b.id}.json`, {})) || {}; }));
    render();
  });

  $('#content').addEventListener('scroll', e => $('#main').classList.toggle('scrolled', e.target.scrollTop > 34), { passive: true });

  // files passed on the command line ("Open with readr.")
  // books opened with readr. (command line / second launch): the host has already imported the files
  let opened = null, importedAny = false, chain = Promise.resolve();
  // handle host messages strictly in order (the "done" message must wait for the books to be added)
  store.onHostMessage(msg => { chain = chain.then(() => onImport(msg)).catch(() => {}); });
  async function onImport(msg) {
    if (msg.startsWith('imported|')) {
      const [, name, size, ...rest] = msg.split('|');
      const result = JSON.parse(rest.join('|'));
      if (result.error) { toast(`Couldn’t add “${name}”`); return; }
      const known = result.existing && lib.books.find(b => b.id === result.id);
      if (known) { opened = known; if (!importedAny) toast(`“${known.title}” is already in your library`); return; }
      try { const rec = await addToLibrary(() => Promise.resolve(result), name, +size || 0); if (rec) { opened = rec; importedAny = true; saveLib(); await refreshLinks(); renderSidebar(); render(); } }
      catch (e) { toast(`Couldn’t add “${name}”`); }
    } else if (msg.startsWith('imported-done|')) {
      if (importedAny && prefs.section !== 'all' && !msg.endsWith('open')) { prefs.section = 'all'; renderSidebar(); render(); }
      if (msg.endsWith('open') && opened) openBook(opened);
      opened = null; importedAny = false;
    }
  }
  window.__importPaths = importPaths;
  async function importPaths(paths, open) {
    let last = null;
    for (const p of paths) {
      try { const rec = await addToLibrary(() => store.importPath(p), p.split(/[\\/]/).pop(), 0); if (rec) last = rec; } catch (e) { toast('Couldn’t add ' + p); }
    }
    if (last) { saveLib(); renderSidebar(); render(); if (open) openBook(last); }
  }
  store.hostSend('pending');
  store.hostSend('chrome', matchMedia('(prefers-color-scheme: dark)').matches ? '#1E1E1E' : '#FFFFFF', matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => applyLibraryStyle());
}
main();
