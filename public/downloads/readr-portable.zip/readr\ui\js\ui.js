// Shared macOS-style UI primitives: popovers, context menus, alerts, toasts.
import { icon } from './icons.js';

export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'style' && typeof v === 'object') {
      for (const [p, val] of Object.entries(v)) {
        if (p.startsWith('--')) el.style.setProperty(p, val);
        else el.style[p] = val;
      }
    }
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(String(k)));
  return el;
}
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

let openPops = [];
export function closePopovers(except) {
  for (const p of [...openPops]) if (p !== except) p.close();
}
export const anyPopoverOpen = () => openPops.length > 0;

// anchor: element or {x,y,w,h} rect in viewport coords
export function popover(anchor, content, opts = {}) {
  if (!opts.keepOthers) closePopovers();
  const el = h('div', { class: 'popover ' + (opts.className || ''), role: 'dialog' });
  const arrow = h('div', { class: 'pop-arrow' });
  if (opts.arrow !== false) el.append(arrow);
  el.append(content);
  document.body.append(el);
  const rect = anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : { left: anchor.x, top: anchor.y, width: anchor.w || 0, height: anchor.h || 0, right: anchor.x + (anchor.w || 0), bottom: anchor.y + (anchor.h || 0) };
  const place = () => {
    const pw = el.offsetWidth, ph = el.offsetHeight, vw = innerWidth, vh = innerHeight;
    let below = opts.placement !== 'above';
    if (below && rect.bottom + ph + 12 > vh && rect.top - ph - 12 > 0) below = false;
    if (!below && rect.top - ph - 12 < 0) below = true;
    let x = rect.left + rect.width / 2 - pw / 2;
    if (opts.align === 'start') x = rect.left - 10;
    x = Math.max(8, Math.min(vw - pw - 8, x));
    let y = below ? rect.bottom + 8 : rect.top - ph - 8;
    y = Math.max(8, Math.min(vh - ph - 8, y));
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.classList.toggle('above', !below);
    const ax = Math.max(14, Math.min(pw - 14, rect.left + rect.width / 2 - x));
    arrow.style.left = ax + 'px';
    el.style.transformOrigin = `${ax}px ${below ? 0 : ph}px`;
  };
  place();
  requestAnimationFrame(() => el.classList.add('in'));
  const api = {
    el, place,
    close() {
      if (api.closed) return;
      api.closed = true;
      openPops = openPops.filter(p => p !== api);
      el.classList.remove('in');
      el.classList.add('out');
      setTimeout(() => el.remove(), 160);
      document.removeEventListener('pointerdown', outside, true);
      document.removeEventListener('keydown', onEsc, true);
      if (opts.onClose) opts.onClose();
    },
  };
  const outside = e => {
    if (el.contains(e.target)) return;
    if (opts.anchorEl && opts.anchorEl.contains(e.target)) { e.stopPropagation(); e.preventDefault(); api.close(); return; }
    api.close();
  };
  const onEsc = e => { if (e.key === 'Escape') { e.stopPropagation(); api.close(); } };
  setTimeout(() => document.addEventListener('pointerdown', outside, true), 0);
  document.addEventListener('keydown', onEsc, true);
  openPops.push(api);
  return api;
}

// macOS context menu. items: {label, icon, action, danger, disabled, checked, sep, submenu:[...], shortcut}
export function menu(x, y, items, opts = {}) {
  if (!opts.sub) closePopovers();
  const el = h('div', { class: 'menu', role: 'menu' });
  let sub = null;
  for (const it of items) {
    if (!it) continue;
    if (it.sep) { el.append(h('div', { class: 'menu-sep' })); continue; }
    if (it.header) { el.append(h('div', { class: 'menu-header' }, it.header)); continue; }
    const row = h('div', { class: 'menu-item' + (it.danger ? ' danger' : '') + (it.disabled ? ' disabled' : ''), role: 'menuitem' },
      h('span', { class: 'menu-check' }, it.checked ? '✓' : ''),
      it.icon ? h('span', { class: 'menu-icon', html: icon(it.icon) }) : null,
      h('span', { class: 'menu-label' }, it.label),
      it.shortcut ? h('span', { class: 'menu-shortcut' }, it.shortcut) : null,
      it.submenu ? h('span', { class: 'menu-sub', html: icon('chevronRight') }) : null,
    );
    if (it.submenu) {
      row.addEventListener('mouseenter', () => {
        if (sub) sub.close();
        const r = row.getBoundingClientRect();
        sub = menu(r.right - 4, r.top - 5, it.submenu, { sub: true, parent: api });
      });
    } else {
      row.addEventListener('mouseenter', () => { if (sub) { sub.close(); sub = null; } });
      row.addEventListener('click', e => {
        if (it.disabled) return;
        e.stopPropagation();
        rootClose();
        setTimeout(() => it.action && it.action(), 0);
      });
    }
    el.append(row);
  }
  document.body.append(el);
  const mw = el.offsetWidth, mh = el.offsetHeight;
  el.style.left = Math.max(4, Math.min(innerWidth - mw - 4, x)) + 'px';
  el.style.top = Math.max(4, Math.min(innerHeight - mh - 4, y)) + 'px';
  requestAnimationFrame(() => el.classList.add('in'));
  const api = {
    el,
    close() {
      if (api.closed) return;
      api.closed = true;
      if (sub) sub.close();
      el.remove();
      openPops = openPops.filter(p => p !== api);
      document.removeEventListener('pointerdown', outside, true);
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('blur', rootClose);
    },
  };
  const rootClose = () => { let p = api; while (p.parent) p = p.parent; p.close(); };
  api.parent = opts.parent;
  const outside = e => { if (!e.target.closest('.menu')) rootClose(); };
  const onKey = e => { if (e.key === 'Escape') { e.stopPropagation(); rootClose(); } };
  if (!opts.sub) {
    setTimeout(() => document.addEventListener('pointerdown', outside, true), 0);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('blur', rootClose);
  }
  openPops.push(api);
  return api;
}

export function alertDialog({ title, message, ok = 'OK', cancel = 'Cancel', danger = false, input = null }) {
  return new Promise(resolve => {
    closePopovers();
    const field = input != null ? h('input', { class: 'alert-input', type: 'text', value: input, spellcheck: 'false' }) : null;
    const done = v => { back.classList.remove('in'); setTimeout(() => back.remove(), 180); document.removeEventListener('keydown', key, true); resolve(v); };
    const okBtn = h('button', { class: 'btn ' + (danger ? 'btn-danger' : 'btn-primary'), onclick: () => done(field ? field.value : true) }, ok);
    const box = h('div', { class: 'alert' },
      h('div', { class: 'alert-icon', html: '<img src="/ui/img/icon.png" alt="">' }),
      h('div', { class: 'alert-title' }, title),
      message ? h('div', { class: 'alert-msg' }, message) : null,
      field,
      h('div', { class: 'alert-buttons' }, cancel ? h('button', { class: 'btn', onclick: () => done(field ? null : false) }, cancel) : null, okBtn),
    );
    const back = h('div', { class: 'alert-back' }, box);
    const key = e => {
      if (e.key === 'Escape') { e.preventDefault(); done(field ? null : false); }
      if (e.key === 'Enter') { e.preventDefault(); done(field ? field.value : true); }
    };
    document.addEventListener('keydown', key, true);
    document.body.append(back);
    requestAnimationFrame(() => back.classList.add('in'));
    setTimeout(() => (field ? (field.focus(), field.select()) : okBtn.focus()), 30);
  });
}

let toastT;
export function toast(msg) {
  let t = $('.toast');
  if (!t) { t = h('div', { class: 'toast' }); document.body.append(t); }
  t.textContent = msg;
  t.classList.add('in');
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove('in'), 2200);
}

export function fmtDate(ts) {
  const d = new Date(ts);
  const now = new Date();
  const opts = d.getFullYear() === now.getFullYear() ? { month: 'long', day: 'numeric' } : { year: 'numeric', month: 'long', day: 'numeric' };
  return d.toLocaleDateString(undefined, opts);
}
