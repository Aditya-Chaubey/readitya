// Minimal custom title bar: the host removes the Windows caption, the page marks its toolbar as
// `app-region: drag` and draws these window controls in its own colours.
import * as store from './store.js';
import { h } from './ui.js';

const GLYPH = {
  min: '<path d="M1 6h10"/>',
  max: '<rect x="1.5" y="1.5" width="9" height="9" rx="1.6"/>',
  restore: '<rect x="1.5" y="3.5" width="7" height="7" rx="1.4"/><path d="M3.5 3.5V2.9c0-.8.6-1.4 1.4-1.4h4.2c.8 0 1.4.6 1.4 1.4v4.2c0 .8-.6 1.4-1.4 1.4h-.6"/>',
  close: '<path d="M1.5 1.5l9 9M10.5 1.5l-9 9"/>',
};
const svg = g => `<svg viewBox="0 0 12 12" aria-hidden="true">${g}</svg>`;

let state = 'normal';
const listeners = new Set();
export const onWindowState = fn => { listeners.add(fn); fn(state); };

export function windowControls() {
  if (!store.isHost) return null;
  document.body.classList.add('has-titlebar');
  const max = h('button', { class: 'win-btn max', title: 'Maximize', html: svg(GLYPH.max), onclick: () => store.hostSend('max') });
  const el = h('div', { class: 'win-controls' },
    h('button', { class: 'win-btn min', title: 'Minimize', html: svg(GLYPH.min), onclick: () => store.hostSend('min') }),
    max,
    h('button', { class: 'win-btn close', title: 'Close', html: svg(GLYPH.close), onclick: () => { store.flushAll(); store.hostSend('close'); } }));
  store.onHostMessage(msg => {
    if (!msg.startsWith('winstate|')) return;
    const [, s, focus] = msg.split('|');
    state = s;
    document.body.classList.toggle('win-max', s === 'max');
    document.body.classList.toggle('win-full', s === 'full');
    document.body.classList.toggle('win-inactive', focus === 'inactive');
    max.innerHTML = svg(s === 'max' ? GLYPH.restore : GLYPH.max);
    max.title = s === 'max' ? 'Restore Down' : 'Maximize';
    listeners.forEach(fn => fn(s));
  });
  store.hostSend('winstate');
  return el;
}
