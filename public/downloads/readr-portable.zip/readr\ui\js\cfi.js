// EPUB Canonical Fragment Identifiers — the position currency of Books (cfi_utilities).
// epubcfi(/6/14[chap05]!/4/2[para01]/1:42)
//   spine step  ! element steps (even = element, odd = text chunk) : character offset

const isEl = n => n.nodeType === 1;
const isText = n => n.nodeType === 3 || n.nodeType === 4;

function stepFor(node) {
  const parent = node.parentNode;
  let elIndex = 0;
  for (const c of parent.childNodes) {
    if (c === node) break;
    if (isEl(c)) elIndex++;
  }
  if (isEl(node)) {
    const id = node.getAttribute('id');
    return { n: (elIndex + 1) * 2, id };
  }
  return { n: elIndex * 2 + 1 };
}

// offset of `node` inside its text chunk (adjacent text nodes between two elements)
function chunkOffset(node) {
  let off = 0, c = node.previousSibling;
  while (c && !isEl(c)) { if (isText(c)) off += c.nodeValue.length; c = c.previousSibling; }
  return off;
}

export function pathFor(node, offset) {
  const doc = node.ownerDocument;
  let steps = [];
  let charOffset = null;
  if (isText(node)) {
    charOffset = chunkOffset(node) + (offset || 0);
  } else if (isEl(node) && offset != null && node.childNodes.length) {
    // element + child offset -> descend to the child
    const child = node.childNodes[Math.min(offset, node.childNodes.length - 1)];
    if (child) {
      if (isText(child)) { charOffset = chunkOffset(child) + (offset >= node.childNodes.length ? child.nodeValue.length : 0); node = child; }
      else node = child;
    }
  }
  let n = node;
  while (n && n !== doc.documentElement && n.parentNode) {
    const s = stepFor(n);
    steps.unshift(s.id ? `/${s.n}[${cssEsc(s.id)}]` : `/${s.n}`);
    n = n.parentNode;
  }
  return steps.join('') + (charOffset != null ? ':' + charOffset : '');
}
const cssEsc = s => s.replace(/[\[\]\^,();]/g, m => '^' + m);

export function make(spineStep, node, offset) {
  return `epubcfi(${spineStep}!${pathFor(node, offset)})`;
}

export function parse(cfi) {
  const m = /^epubcfi\((.*)\)$/.exec(cfi || '');
  if (!m) return null;
  const [spinePart, docPart = ''] = m[1].split('!');
  const ss = /\/(\d+)(?:\[[^\]]*\])?\/(\d+)/.exec(spinePart);
  const spineIndex = ss ? (+ss[2] / 2) - 1 : 0;
  const steps = [];
  let offset = null;
  const re = /\/(\d+)(?:\[((?:\^.|[^\]])*)\])?|:(\d+)/g;
  let t;
  while ((t = re.exec(docPart))) {
    if (t[3] != null) offset = +t[3];
    else steps.push({ n: +t[1], id: t[2] ? t[2].replace(/\^(.)/g, '$1') : null });
  }
  return { spineIndex, steps, offset };
}

export function resolve(doc, cfi) {
  const p = typeof cfi === 'string' ? parse(cfi) : cfi;
  if (!p) return null;
  let node = doc.documentElement;
  for (let i = 0; i < p.steps.length; i++) {
    const s = p.steps[i];
    if (s.id) {
      const byId = doc.getElementById(s.id);
      if (byId) { node = byId; continue; }
    }
    if (s.n % 2 === 0) {
      const els = [...node.childNodes].filter(isEl);
      const next = els[s.n / 2 - 1];
      if (!next) break;
      node = next;
    } else {
      // text chunk: the k-th run of non-elements
      const k = (s.n - 1) / 2;
      let elCount = 0, chunk = [];
      for (const c of node.childNodes) {
        if (isEl(c)) { elCount++; if (elCount > k) break; continue; }
        if (elCount === k && isText(c)) chunk.push(c);
      }
      if (!chunk.length) break;
      let off = p.offset || 0;
      for (const c of chunk) {
        if (off <= c.nodeValue.length) return { node: c, offset: off };
        off -= c.nodeValue.length;
      }
      const last = chunk[chunk.length - 1];
      return { node: last, offset: last.nodeValue.length };
    }
  }
  return { node, offset: p.offset != null && isText(node) ? p.offset : 0 };
}

export function toRange(doc, startCfi, endCfi) {
  const a = resolve(doc, startCfi), b = resolve(doc, endCfi || startCfi);
  if (!a || !b) return null;
  const r = doc.createRange();
  try {
    setPoint(r, 'setStart', a);
    setPoint(r, 'setEnd', b);
  } catch { return null; }
  return r;
}
function setPoint(r, fn, p) {
  if (isText(p.node)) r[fn](p.node, Math.min(p.offset, p.node.nodeValue.length));
  else if (fn === 'setStart') r.setStartBefore(p.node.firstChild ? p.node : p.node);
  else r.setEndAfter(p.node);
}

// numeric comparison for sorting positions
export function compare(a, b) {
  const pa = parse(a), pb = parse(b);
  if (!pa || !pb) return 0;
  if (pa.spineIndex !== pb.spineIndex) return pa.spineIndex - pb.spineIndex;
  const n = Math.min(pa.steps.length, pb.steps.length);
  for (let i = 0; i < n; i++) if (pa.steps[i].n !== pb.steps[i].n) return pa.steps[i].n - pb.steps[i].n;
  if (pa.steps.length !== pb.steps.length) return pa.steps.length - pb.steps.length;
  return (pa.offset || 0) - (pb.offset || 0);
}
