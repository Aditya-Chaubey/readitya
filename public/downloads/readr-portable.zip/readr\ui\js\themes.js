// Reader themes, typography and the injected "user stylesheets".
// Colours, line-heights, margin math and size ladders are the decompiled Books values
// (BookThemeEntity, BookLayoutGutterCalculator, FontPresets). CSS is reimplemented from
// the behaviour of user_stylesheet_{base,flowable,fonts,colors_light,colors_dark}.css.
import { FONT_PRESETS } from './presets.js';

// type -> [bgLight, bgDark, textLight, textDark, linkLight, linkDark, defaultLineHeight]
export const THEMES = {
  original: { name: 'Original', light: ['#FFFFFF', '#000000', null], dark: ['#000000', '#FFFFFF', '#009DDC'], lh: 1.2 },
  quiet:    { name: 'Quiet',    light: ['#4A4A4D', 'rgba(235,235,245,0.6)', '#009DDC'], dark: ['#000000', '#8D8D93', '#009DDC'], lh: 1.4 },
  paper:    { name: 'Paper',    light: ['#EEEDED', '#201C1C', '#007AFF'], dark: ['#1C1C1E', '#F2F2F0', '#009DDC'], lh: 1.55 },
  bold:     { name: 'Bold',     light: ['#FFFFFF', '#1C1C1E', '#007AFF'], dark: ['#000000', '#EFEFF2', '#009DDC'], lh: 1.5, bold: true },
  calm:     { name: 'Calm',     light: ['#F1E2C9', '#372D24', '#BF9230'], dark: ['#423B30', '#F9ECDB', '#009DDC'], lh: 1.55 },
  focus:    { name: 'Focus',    light: ['#FFFCF4', '#141200', '#BF9230'], dark: ['#18160C', '#FFF9EB', '#009DDC'], lh: 1.4 },
};
export const THEME_ORDER = ['original', 'quiet', 'paper', 'bold', 'calm', 'focus'];

export function resolveTheme(type, appearance /* 'light'|'dark'|'auto' */) {
  const t = THEMES[type] || THEMES.original;
  let variant = appearance === 'auto'
    ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : appearance;
  const [bg, text, link] = t[variant];
  const dark = variant === 'dark' || type === 'quiet'; // hasDarkBackground
  return { type, variant, bg, text, link, dark, lh: t.lh, name: t.name };
}

// Font families. `local()` first so a user with the real Apple fonts gets them; otherwise an
// open-licence lookalike bundled in /ui/fonts.
const F = (n, w, s) => `url('/ui/fonts/${n}-latin-${w}-${s}.woff2') format('woff2')`;
export const FAMILIES = {
  '':                { label: 'Original' },
  'Athelas':         { label: 'Athelas',         local: ['Athelas', 'Athelas-Regular'], bundle: 'eb-garamond', fallback: 'Georgia, serif' },
  'Charter':         { label: 'Charter',         local: ['Charter', 'Charter Roman', 'Bitstream Charter'], bundle: 'charis-sil', fallback: 'Georgia, serif' },
  'Georgia':         { label: 'Georgia',         system: 'Georgia', fallback: 'serif' },
  'Iowan Old Style': { label: 'Iowan',           local: ['Iowan Old Style', 'IowanOldStyle-Roman'], bundle: 'source-serif-4', fallback: 'Georgia, serif' },
  'Palatino':        { label: 'Palatino',        system: "Palatino, 'Palatino Linotype', 'Book Antiqua'", fallback: 'serif' },
  'San Francisco':   { label: 'San Francisco',   system: "-apple-system, 'Segoe UI Variable Text', 'Segoe UI'", fallback: 'sans-serif' },
  'Seravek':         { label: 'Seravek',         local: ['Seravek', 'Seravek-Regular'], bundle: 'source-sans-3', fallback: "'Segoe UI', sans-serif" },
  'Times New Roman': { label: 'Times New Roman', system: "'Times New Roman'", fallback: 'serif' },
  'Avenir Next':     { label: 'Avenir Next',     local: ['Avenir Next', 'AvenirNext-Regular'], bundle: 'nunito-sans', fallback: "'Segoe UI', sans-serif" },
};
export const FAMILY_ORDER = ['', 'Athelas', 'Avenir Next', 'Charter', 'Georgia', 'Iowan Old Style', 'Palatino', 'San Francisco', 'Seravek', 'Times New Roman'];
export const DEFAULT_FAMILY = 'Iowan Old Style';
export const DEFAULT_SIZE = 3;
export const SIZE_STEPS = 12;

export function presetFor(family) {
  if (family === 'San Francisco') return FONT_PRESETS[10];
  return FONT_PRESETS.find(p => p.family === family) || FONT_PRESETS[0];
}

function familyStack(family) {
  const f = FAMILIES[family];
  if (!f || !family) return null;
  if (f.system) return `${f.system}, ${f.fallback}`;
  return `'iBooks_${family.replace(/\s+/g, '_')}', ${f.fallback}`;
}

export function fontFaceCSS(family) {
  const f = FAMILIES[family];
  if (!f || !f.local) return '';
  const name = `iBooks_${family.replace(/\s+/g, '_')}`;
  let css = '';
  for (const [w, s] of [[400, 'normal'], [700, 'normal'], [400, 'italic'], [700, 'italic']]) {
    const locals = w === 400 && s === 'normal' ? f.local.map(l => `local('${l}')`).join(', ') + ', ' : '';
    css += `@font-face{font-family:'${name}';src:${locals}${F(f.bundle, w, s)};font-weight:${w === 400 ? '100 500' : '600 900'};font-style:${s};font-display:block}\n`;
  }
  return css;
}

// marginScale(a) — BookThemeEntity.marginAdjustmentScaleFactor (EXACT)
export function marginScale(a) {
  if (a == null) return 1;
  if (a >= 0.1) return 2.0;
  if (a >= 0) return 1 + 10 * a;
  if (a >= -0.1) return 1 + 7.5 * a;
  return 0.25;
}

// Page geometry for paged mode (BookLayoutGutterCalculator, EXACT formula).
export function pageGeometry(W, H, twoUp, s) {
  const columns = twoUp ? 2 : 1;
  let side = Math.floor(0.085 * W * (twoUp ? 2 / 3 : 1)) * marginScale(s.margin);
  side = Math.max(16, Math.round(side));
  // Keep a readable measure in very wide single-page windows.
  const pageW = W / columns;
  const maxMeasure = Math.max(520, typography(s).fontPx * 37);
  if (pageW - 2 * side > maxMeasure) side = Math.round((pageW - maxMeasure) / 2);
  const top = Math.max(56, Math.round(H * 0.075));
  const bottom = Math.max(52, Math.round(H * 0.07));
  return { W, H, columns, side, top, bottom, pageW, contentW: pageW - 2 * side, contentH: H - top - bottom };
}

// Line height: user override, else the theme's default (BookThemeEntity.defaultOverrides) scaled by
// the family's per-step ladder so it still tightens at the largest sizes.
export function typography(s, theme) {
  const studio = theme && theme.studio;
  // studio styles bring their own type; they use the default (Iowan) size ladder, optionally scaled
  const preset = presetFor(studio ? DEFAULT_FAMILY : s.family);
  const step = preset.steps[Math.max(0, Math.min(SIZE_STEPS - 1, s.size))];
  const fontPx = +(step[0] * 16 * ((studio && studio.scale) || 1)).toFixed(2);
  let lh = null;
  if (s.lineHeight != null) lh = s.lineHeight;
  else if (step[1]) {
    const base = preset.steps[0][1] || step[1];
    lh = theme ? +(theme.lh * (step[1] / base)).toFixed(3) : step[1];
  }
  return { fontPx, lineHeight: lh, scale: step[0] };
}
export const isBold = (s, theme) => s.bold != null ? s.bold : theme.type === 'bold';

// The combined user stylesheet injected into every content document.
export function contentCSS(s, theme, geo, mode /* 'paged'|'scroll' */) {
  const typo = typography(s, theme);
  const studio = theme.studio;
  const stack = studio ? studio.body : familyStack(s.family);
  const original = !s.family && !studio;
  const justify = s.justify ? 'justify' : 'start';
  const hy = s.hyphenate !== false && s.justify ? 'auto' : (s.hyphenate === true ? 'auto' : 'manual');
  const linkLight = theme.link;
  const bold = isBold(s, theme);
  let css = '';

  // ---- base
  css += `@namespace epub "http://www.idpf.org/2007/ops";
iframe{border-style:none}
body{-webkit-text-size-adjust:none}table{-webkit-text-size-adjust:initial}
audio[epub|type~="ibooks:soundtrack"]{display:none!important;height:0!important}
`;
  // ---- variables
  css += `:root{--background-color:${theme.bg};--text-color:${theme.text};--link-color:${linkLight || 'inherit'};
--page-width:${geo.pageW}px;--page-height:${geo.H}px;--margin:${geo.side}px;--td-clamp:${Math.max(120, Math.round(geo.contentW * 0.9))}px;
--ibooks-line-height:${typo.lineHeight || 'normal'};--ibooks-letter-spacing:${s.letterSpacing || 0}em;--ibooks-word-spacing:${s.wordSpacing || 0}em;
color-scheme:${theme.dark ? 'dark' : 'light'}!important}
`;
  // ---- flowable
  css += `html{background:var(--background-color)!important;padding:0!important;margin:0!important;-webkit-line-box-contain:block glyphs replaced}
body{padding:0!important;background:transparent!important}
@page{margin:0!important}
p{widows:2;orphans:2}
td{max-width:var(--td-clamp)!important}
img,svg,audio{max-width:100%!important;box-sizing:border-box;object-fit:contain;break-inside:avoid;page-break-inside:avoid}
video{width:300px;height:150px;max-width:100%;object-fit:contain;break-inside:avoid}
[epub|type~="noteref"]{-webkit-tap-highlight-color:transparent}
aside[epub|type~="footnote"],aside[epub|type~="endnote"],aside[epub|type~="rearnote"]{display:none!important}
ruby>rt,ruby>rp{-webkit-user-select:none;user-select:none}
a{text-decoration:none}
pre{white-space:pre-wrap}
h1,h2,h3,h4,h5,h6{text-rendering:optimizeLegibility}
::selection{background:${theme.dark ? 'rgba(10,132,255,.45)' : 'rgba(0,122,255,.25)'}}
`;
  if (mode === 'paged') {
    const n = geo.columns;
    css += `html{height:${geo.H}px!important;width:${geo.W}px!important;max-width:none!important;max-height:none!important;
box-sizing:border-box!important;padding:${geo.top}px ${geo.side}px ${geo.bottom}px!important;
column-count:${n}!important;column-gap:${geo.side * 2}px!important;column-fill:auto!important;overflow:hidden!important;
writing-mode:horizontal-tb!important}
body{margin:0!important;width:auto!important;max-width:none!important;height:auto!important;min-height:0!important;overflow:visible!important;position:static!important;columns:auto!important}
img,svg,video,figure,table{max-height:${Math.floor(geo.contentH * 0.95)}px!important}
img{height:auto}
body div,body table,body pre,body figure,body section,body article,body blockquote,body img,body svg,body video,body p,body ul,body ol,body dl,body hr{max-width:100%!important}
body table{table-layout:auto}
`;
  } else {
    css += `html{overflow:hidden!important;height:auto!important}
body{margin:${geo.top}px ${geo.side}px ${geo.bottom}px!important;max-width:none!important}
img,svg,video{max-height:${Math.floor(geo.contentH * 0.95)}px!important}
`;
  }

  // ---- fonts / typography
  css += fontFaceCSS(s.family);
  css += `body{font-size:${typo.fontPx}px!important;text-align:${justify}!important;
-webkit-hyphens:${hy};hyphens:${hy};-webkit-hyphenate-character:'-';hyphenate-character:'-';
-webkit-hyphenate-limit-before:3;-webkit-hyphenate-limit-after:3;-webkit-hyphenate-limit-lines:2;hyphenate-limit-chars:auto 3 3;
text-rendering:optimizeLegibility;-webkit-font-smoothing:antialiased;
letter-spacing:var(--ibooks-letter-spacing);word-spacing:var(--ibooks-word-spacing)}
h1,h2,h3,h4,h5,h6,table,ol,ul{text-align:-webkit-auto}
`;
  if (!original) {
    css += `body,body p,body div,body span,body li,body blockquote,body td,body dd,body dt,body em,body i,body b,body strong,body cite,body a,body small,body big,body sup,body sub,body figcaption,body h1,body h2,body h3,body h4,body h5,body h6{font-family:${stack}!important}
body p,body li,body div,body blockquote,body dd,body td{text-align:${justify}!important}
body *{font-size-adjust:none}
math{font-family:'Latin Modern Math','STIX Two Math','Cambria Math',STIXGeneral,Symbol,${stack}!important}
`;
    if (typo.lineHeight) css += `body,body p,body li,body div,body blockquote{line-height:${typo.lineHeight}!important}\n`;
    // Publisher font sizes are normalised relative to the reader size (Books keeps relative em sizes)
  } else {
    css += `body{font-size:${typo.fontPx}px!important}\n`;
  }
  if (s.lineHeight != null) css += `body,body *{line-height:${s.lineHeight}!important}\n`;
  if (bold) css += `body,body *{font-weight:700!important}\n`;

  // ---- colours
  if (!theme.dark) {
    css += `:root{background-color:var(--background-color)!important;color:var(--text-color)}
body{color:var(--text-color)}
${linkLight ? `a:link,a:visited{color:var(--link-color)}` : ''}
`;
    if (theme.type !== 'original') css += `body *:not(a):not(a *){color:var(--text-color)}\n`;
  } else {
    css += `:root{background-color:var(--background-color)!important}
:root *:not(a, a *){background-color:transparent!important;color:var(--text-color)}
:root *:not(a, a *, .ibooks-dark-theme-use-custom-text-color),
:root *:not(a, a *, .ibooks-dark-theme-use-custom-text-color)::first-line{color:var(--text-color)!important}
:root svg text{fill:var(--text-color)!important;stroke:none!important}
a:link,a:visited,a *{color:var(--link-color)!important;background-color:transparent!important}
img{filter:${theme.type === 'quiet' ? 'brightness(.85)' : 'none'}}
`;
  }
  // highlights (CSS Custom Highlight API)
  if (studio) {
    // texture on the page canvas + the style's own heading/ornament rules (last, so they win)
    css += `html{background-image:${studio.texture}!important;background-attachment:local!important}\n`;
    css += studio.extra + '\n';
  }
  css += highlightCSS(theme.dark);
  return css;
}

// Books highlight colours (annotationStyle index): 1 green, 2 blue, 3 yellow, 4 pink, 5 purple, 0 underline
export const HIGHLIGHTS = [
  { id: 3, name: 'Yellow', light: 'rgba(255,214,10,.42)', dark: 'rgba(255,214,10,.40)', swatch: '#FFD60A' },
  { id: 1, name: 'Green', light: 'rgba(52,199,89,.32)', dark: 'rgba(48,209,88,.40)', swatch: '#34C759' },
  { id: 2, name: 'Blue', light: 'rgba(10,132,255,.25)', dark: 'rgba(10,132,255,.45)', swatch: '#0A84FF' },
  { id: 4, name: 'Pink', light: 'rgba(255,55,95,.25)', dark: 'rgba(255,55,95,.45)', swatch: '#FF375F' },
  { id: 5, name: 'Purple', light: 'rgba(175,82,222,.25)', dark: 'rgba(191,90,242,.45)', swatch: '#AF52DE' },
];
function highlightCSS(dark) {
  let css = '';
  for (const h of HIGHLIGHTS) css += `::highlight(hl-${h.id}){background-color:${dark ? h.dark : h.light}}\n`;
  css += `::highlight(hl-0){text-decoration:underline 2px #FF3B30;text-underline-offset:3px;background-color:transparent}\n`;
  css += `::highlight(hl-search){background-color:${dark ? 'rgba(255,214,10,.55)' : 'rgba(255,214,10,.7)'};color:inherit}\n`;
  return css;
}

// Book-chrome colours derived from the theme (labels/separators: IMThemePage element matrix, approximated)
export function chromeColors(theme) {
  const d = theme.dark;
  return {
    bg: theme.bg,
    label: d ? 'rgba(235,235,245,.62)' : 'rgba(60,60,67,.62)',
    labelStrong: d ? 'rgba(255,255,255,.88)' : 'rgba(0,0,0,.82)',
    tertiary: d ? 'rgba(235,235,245,.32)' : 'rgba(60,60,67,.32)',
    sep: d ? 'rgba(255,255,255,.12)' : 'rgba(0,0,0,.1)',
    fill: d ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.05)',
    popover: d ? '#2C2C2E' : '#FFFFFF',
    curlBack: d ? mix(theme.bg, '#ffffff', 0.08) : mix(theme.bg, '#000000', 0.04),
  };
}

export function mix(a, b, t) {
  const pa = parse(a), pb = parse(b);
  const c = pa.map((v, i) => Math.round(v + (pb[i] - v) * t));
  return '#' + c.map(v => v.toString(16).padStart(2, '0')).join('');
}
function parse(c) {
  if (c.startsWith('rgba')) return c.match(/[\d.]+/g).slice(0, 3).map(Number);
  c = c.replace('#', '');
  return [0, 2, 4].map(i => parseInt(c.substr(i, 2), 16));
}

export const DEFAULT_SETTINGS = {
  theme: 'original',
  appearance: 'auto',
  family: DEFAULT_FAMILY,
  size: DEFAULT_SIZE,
  bold: null,            // null = theme default (Bold theme bolds)
  justify: false,
  hyphenate: true,
  lineHeight: null,       // null = theme/preset default
  letterSpacing: 0,
  wordSpacing: 0,
  margin: null,           // marginAdjustment a ∈ [-0.1, 0.1]
  scroll: false,
  layout: 'auto',         // auto | single | double
  turn: 'slide',          // BKPageTurnStyle: slide | curl | fastFade
  leftTapNext: false,     // BKLeftTapTurnToNext
  customize: false,
};
