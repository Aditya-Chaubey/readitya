// PDF reading (BKPDFModernBookViewController equivalent) on pdf.js: page/spread display with the
// same page-turn engine, outline TOC, page labels, text selection, highlights and search.
import * as pdfjsLib from '../vendor/pdfjs/pdf.min.mjs';
import { flatten } from './epub.js';

pdfjsLib.GlobalWorkerOptions.workerSrc = '/ui/vendor/pdfjs/pdf.worker.min.mjs';

class PdfView {
  constructor(engine) {
    this.engine = engine;
    this.el = document.createElement('div');
    this.el.className = 'pv pdf-pv';
    this.inner = document.createElement('div');
    this.inner.className = 'pv-inner';
    this.el.appendChild(this.inner);
    engine.stage.insertBefore(this.el, engine.turner.flap);
    this.spread = -1;
    this.used = 0;
    this.hidden();
    this.el.addEventListener('click', e => engine.reader.onFrameClick(this, e));
    this.el.addEventListener('mouseup', e => setTimeout(() => engine.reader.onFrameMouseUp(this, e), 0));
    this.el.addEventListener('mousedown', e => engine.reader.onFrameMouseDown(this, e));
    this.el.addEventListener('contextmenu', e => engine.reader.onFrameContext(this, e));
    this.el.addEventListener('pointerdown', e => { if (!e.target.closest('.textLayer span')) engine.reader.onFramePointerDown(this, e); });
  }
  get doc() { return document; }
  get iframe() { return this.el; }
  hidden() { this.el.style.visibility = 'hidden'; this.el.style.zIndex = '0'; }

  show(spread) {
    if (this.spread === spread && this.ready && this.layoutKey === this.engine.layoutKey) return this.ready;
    this.spread = spread;
    this.layoutKey = this.engine.layoutKey;
    const token = (this.token = {});
    this.ready = (async () => {
      const e = this.engine;
      const pages = e.pagesOf(spread);
      const g = e.pageGeo(pages);
      const frag = document.createDocumentFragment();
      const jobs = [];
      pages.forEach((pi, k) => {
        const box = g.boxes[k];
        const pageEl = document.createElement('div');
        pageEl.className = 'pdf-page';
        pageEl.dataset.page = pi;
        Object.assign(pageEl.style, { left: box.x + 'px', top: box.y + 'px', width: box.w + 'px', height: box.h + 'px' });
        const canvas = document.createElement('canvas');
        pageEl.appendChild(canvas);
        const hl = document.createElement('div');
        hl.className = 'pdf-hl';
        pageEl.appendChild(hl);
        const tl = document.createElement('div');
        tl.className = 'textLayer';
        pageEl.appendChild(tl);
        frag.appendChild(pageEl);
        jobs.push(e.renderPage(pi, box, canvas, tl, token, this));
      });
      this.inner.replaceChildren(frag);
      await Promise.all(jobs);
      e.applyHighlights(this);
      return this;
    })();
    this.ready.catch(() => {});
    return this.ready;
  }
}

export class PdfEngine {
  constructor(reader, record, stage, turner) {
    this.reader = reader;
    this.record = record;
    this.stage = stage;
    this.turner = turner;
    this.views = [];
    this.cur = null;
    this.loc = { spread: 0 };
    this.queue = Promise.resolve();
    this.annotations = [];
    this.cache = new Map(); // `${page}@${w}` -> canvas
    this.textCache = new Map();
    this.toc = [];
  }

  async open() {
    const url = `/lib/${this.record.id}/${this.record.file || 'book.pdf'}`;
    this.pdf = await pdfjsLib.getDocument({ url, disableRange: true, disableStream: true, isEvalSupported: false }).promise;
    this.numPages = this.pdf.numPages;
    const first = await this.pdf.getPage(1);
    const vp = first.getViewport({ scale: 1 });
    this.aspect = vp.width / vp.height;
    this.sizes = new Map([[0, { w: vp.width, h: vp.height }]]);
    try { this.labels = await this.pdf.getPageLabels(); } catch { this.labels = null; }
    try {
      const outline = await this.pdf.getOutline();
      if (outline) this.toc = await this.mapOutline(outline, 0);
    } catch {}
    if (!this.toc.length) this.toc = [];
  }
  async mapOutline(items, level) {
    const out = [];
    for (const it of items) {
      let page = null;
      try {
        let dest = it.dest;
        if (typeof dest === 'string') dest = await this.pdf.getDestination(dest);
        if (Array.isArray(dest)) page = typeof dest[0] === 'number' ? dest[0] : await this.pdf.getPageIndex(dest[0]);
      } catch {}
      out.push({ label: it.title, pdfPage: page, level, children: it.items && it.items.length ? await this.mapOutline(it.items, level + 1) : [] });
    }
    return out;
  }

  configure(css, theme, geo, key) {
    this.theme = theme;
    const s = this.reader.settings;
    const W = this.stage.clientWidth, H = this.stage.clientHeight;
    const twoUp = s.layout === 'double' || (s.layout === 'auto' && W > H * 1.2 && W >= 900);
    this.twoUp = twoUp && this.numPages > 1;
    this.geo = { W, H, top: 50, bottom: 40, side: Math.max(18, Math.round(W * 0.03)), gap: 0, columns: this.twoUp ? 2 : 1 };
    this.layoutKey = `${W}x${H}:${this.twoUp}`;
  }
  get counts() { return null; }

  spreadCount() { return this.twoUp ? Math.ceil(this.numPages / 2) : this.numPages; }
  pagesOf(spread) {
    if (!this.twoUp) return [spread];
    const a = spread * 2;
    return a + 1 < this.numPages ? [a, a + 1] : [a];
  }
  spreadOf(page) { return this.twoUp ? Math.floor(page / 2) : page; }

  pageGeo(pages) {
    const g = this.geo;
    const availW = (g.W - 2 * g.side) / pages.length;
    const availH = g.H - g.top - g.bottom;
    const boxes = pages.map(p => {
      const sz = this.sizes.get(p) || this.sizes.get(0);
      const scale = Math.min(availW / sz.w, availH / sz.h);
      return { w: Math.floor(sz.w * scale), h: Math.floor(sz.h * scale), scale };
    });
    const totalW = boxes.reduce((a, b) => a + b.w, 0);
    let x = Math.round((g.W - totalW) / 2);
    if (pages.length === 1 && this.twoUp) {
      // a lone last/first page sits on its own side of the spine
      x = pages[0] % 2 === 0 ? Math.round(g.W / 2 - boxes[0].w) : Math.round(g.W / 2);
    }
    for (const b of boxes) { b.x = x; b.y = Math.round(g.top + (availH - b.h) / 2); x += b.w; }
    return { boxes };
  }

  async renderPage(pi, box, canvas, tl, token, view) {
    const page = await this.pdf.getPage(pi + 1);
    const base = page.getViewport({ scale: 1 });
    if (!this.sizes.has(pi)) this.sizes.set(pi, { w: base.width, h: base.height });
    const scale = box.w / base.width;
    const dpr = devicePixelRatio || 1;
    const vp = page.getViewport({ scale: scale * dpr });
    canvas.width = Math.floor(vp.width);
    canvas.height = Math.floor(vp.height);
    canvas.style.width = box.w + 'px';
    canvas.style.height = box.h + 'px';
    const key = `${pi}@${canvas.width}`;
    const hit = this.cache.get(key);
    if (hit) canvas.getContext('2d').drawImage(hit, 0, 0);
    else {
      const task = page.render({ canvasContext: canvas.getContext('2d'), viewport: vp, annotationMode: pdfjsLib.AnnotationMode.ENABLE_FORMS });
      await task.promise.catch(() => {});
      if (token !== view.token) return;
      const copy = document.createElement('canvas');
      copy.width = canvas.width; copy.height = canvas.height;
      copy.getContext('2d').drawImage(canvas, 0, 0);
      this.cache.set(key, copy);
      if (this.cache.size > 14) this.cache.delete(this.cache.keys().next().value);
    }
    // selectable text
    try {
      let tc = this.textCache.get(pi);
      if (!tc) { tc = await page.getTextContent(); this.textCache.set(pi, tc); }
      const tvp = page.getViewport({ scale });
      tl.style.setProperty('--scale-factor', scale);
      const layer = new pdfjsLib.TextLayer({ textContentSource: tc, container: tl, viewport: tvp });
      await layer.render();
      tl.appendChild(Object.assign(document.createElement('div'), { className: 'endOfContent' }));
    } catch {}
    // links
    try {
      const annots = await page.getAnnotations();
      const tvp = page.getViewport({ scale });
      for (const a of annots) {
        if (a.subtype !== 'Link') continue;
        const [x1, y1, x2, y2] = pdfjsLib.Util.normalizeRect(tvp.convertToViewportRectangle(a.rect));
        const link = document.createElement('a');
        link.className = 'pdf-link';
        Object.assign(link.style, { left: x1 + 'px', top: y1 + 'px', width: x2 - x1 + 'px', height: y2 - y1 + 'px' });
        if (a.url) link.href = a.url;
        else if (a.dest) {
          link.href = '#';
          link.addEventListener('click', async ev => {
            ev.preventDefault(); ev.stopPropagation();
            let dest = a.dest;
            if (typeof dest === 'string') dest = await this.pdf.getDestination(dest);
            if (Array.isArray(dest)) {
              const idx = typeof dest[0] === 'number' ? dest[0] : await this.pdf.getPageIndex(dest[0]);
              this.display({ page: idx });
            }
          });
        } else continue;
        tl.parentElement.appendChild(link);
      }
    } catch {}
  }

  // ---------- views & navigation ----------
  async viewFor(spread, exclude = []) {
    let v = this.views.find(v => v.spread === spread && v.layoutKey === this.layoutKey && !exclude.includes(v));
    if (!v) {
      if (this.views.length < 5) { v = new PdfView(this); this.views.push(v); }
      else v = this.views.filter(x => !exclude.includes(x) && x !== this.cur).sort((a, b) => a.used - b.used)[0];
    }
    v.used = performance.now();
    await v.show(spread);
    return v;
  }
  showFrame(v) {
    for (const o of this.views) if (o !== v) o.hidden();
    v.el.style.visibility = 'visible';
    v.el.style.zIndex = '2';
    this.cur = v;
  }
  async display(target = {}) {
    let page = 0;
    if (target.cfi && /^pdf:/.test(target.cfi)) page = +target.cfi.slice(4) - 1;
    else if (target.page != null && target.page !== 'last') page = target.page;
    else if (target.page === 'last') page = this.numPages - 1;
    else if (target.fraction != null) page = Math.round(target.fraction * (this.numPages - 1));
    page = Math.max(0, Math.min(this.numPages - 1, page | 0));
    const spread = this.spreadOf(page);
    const v = await this.viewFor(spread);
    this.showFrame(v);
    this.loc = { spread };
    this.relocated();
    this.preload();
    return true;
  }
  neighbor(dir) {
    const n = this.loc.spread + dir;
    return n >= 0 && n < this.spreadCount() ? n : null;
  }
  preload() {
    clearTimeout(this._pt);
    this._pt = setTimeout(async () => {
      const keep = [this.cur];
      for (const d of [1, -1]) {
        const n = this.neighbor(d);
        if (n != null) keep.push(await this.viewFor(n, keep));
      }
    }, 40);
  }
  // Serialise turns, but never build a backlog: at most one turn running plus one waiting.
  // (Held arrow keys auto-repeat ~30×/s; queueing all of them kept pages turning long after release.)
  get turning() { return (this._pending || 0) > 0; }
  go(dir, opts = {}) {
    if ((this._pending || 0) >= 2) return this.queue;
    this._pending = (this._pending || 0) + 1;
    this.queue = this.queue.then(() => this._go(dir, opts)).catch(e => console.warn(e)).finally(() => { this._pending--; });
    return this.queue;
  }
  async _go(dir, opts = {}) {
    const n = this.neighbor(dir);
    if (n == null) { await this.turner.bounce(this.cur, dir); this.reader.atEdge(dir); return; }
    const from = this.cur;
    const to = await this.viewFor(n, [from]);
    const style = this.reader.turnStyle();
    const flapView = style === 'curl' && this.twoUp ? await this.viewFor(dir > 0 ? n : this.loc.spread, [from, to]) : null;
    this.reader.chromeDuringTurn(true);
    await this.turner.turn(style, dir, from, to, { twoUp: this.twoUp, flapView, fast: opts.fast });
    this.reader.chromeDuringTurn(false);
    this.showFrame(to);
    this.loc = { spread: n };
    this.relocated();
    this.preload();
  }
  async dragBegin(dir) {
    if (this.turner.busy) return false;
    const n = this.neighbor(dir);
    if (n == null) return false;
    const from = this.cur, to = await this.viewFor(n, [from]);
    const style = this.reader.turnStyle();
    const flapView = style === 'curl' && this.twoUp ? await this.viewFor(dir > 0 ? n : this.loc.spread, [from, to]) : null;
    this._drag = { n, from, to };
    this.turner.beginDrag(style, dir, from, to, { twoUp: this.twoUp, flapView });
    this.reader.chromeDuringTurn(true);
    return true;
  }
  dragUpdate(p, pt) { if (this._drag) this.turner.updateDrag(p, pt); }
  async dragEnd(commit) {
    const d = this._drag;
    if (!d) return;
    this._drag = null;
    const ok = await this.turner.endDrag(commit);
    this.reader.chromeDuringTurn(false);
    if (ok) { this.showFrame(d.to); this.loc = { spread: d.n }; this.relocated(); this.preload(); }
    else this.showFrame(d.from);
  }

  async relayout(css, theme, geo, key) {
    const page = this.pagesOf(this.loc.spread)[0];
    this.configure(css, theme, geo, key);
    for (const v of this.views) v.spread = -1;
    await this.display({ page });
  }
  restyleOnly(css, theme) { this.theme = theme; }
  paginateAll() {}

  relocated() {
    const pages = this.pagesOf(this.loc.spread);
    const first = pages[0];
    const flat = flatten(this.toc);
    let chapter = null;
    for (const t of flat) if (t.pdfPage != null && t.pdfPage <= first) chapter = t;
    let next = this.numPages;
    for (const t of flat) if (t.pdfPage != null && t.pdfPage > first && t.pdfPage < next) next = t.pdfPage;
    this.reader.onRelocate({
      spine: 0, page: this.loc.spread, pages: this.spreadCount(),
      columns: this.twoUp ? 2 : 1,
      global: this.loc.spread, total: this.spreadCount(), totalColumns: this.twoUp ? this.spreadCount() * 2 : this.numPages,
      fraction: this.numPages > 1 ? first / (this.numPages - 1) : 1,
      pdfPage: first,
      pageLabels: this.labels,
      cfi: `pdf:${first + 1}`,
      chapter: { entry: chapter, label: chapter ? chapter.label : '', pagesLeft: Math.max(0, Math.ceil((next - first) / (this.twoUp ? 2 : 1)) - 1) },
      atEnd: this.loc.spread === this.spreadCount() - 1,
    });
  }
  currentCFI() { return `pdf:${this.pagesOf(this.loc.spread)[0] + 1}`; }

  // ---------- annotations ----------
  setAnnotations(list) { this.annotations = list; for (const v of this.views) this.applyHighlights(v); }
  applyHighlights(v) {
    for (const pageEl of v.el.querySelectorAll('.pdf-page')) {
      const pi = +pageEl.dataset.page;
      const layer = pageEl.querySelector('.pdf-hl');
      layer.innerHTML = '';
      const W = pageEl.offsetWidth, H = pageEl.offsetHeight;
      for (const a of this.annotations) {
        if (a.type !== 'highlight' || a.deleted || a.start !== `pdf:${pi + 1}` || !a.rects) continue;
        for (const r of a.rects) {
          const d = document.createElement('div');
          d.className = 'pdf-hl-rect hl-' + (a.underline ? 0 : a.style);
          Object.assign(d.style, { left: r[0] * W + 'px', top: r[1] * H + 'px', width: r[2] * W + 'px', height: r[3] * H + 'px' });
          layer.appendChild(d);
        }
      }
    }
  }
  rangeCFIs(v, range) {
    const node = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
    const pageEl = node.closest('.pdf-page');
    const pi = pageEl ? +pageEl.dataset.page : this.pagesOf(this.loc.spread)[0];
    const pr = pageEl.getBoundingClientRect();
    const rects = [...range.getClientRects()].filter(r => r.width > 1 && r.height > 1)
      .map(r => [(r.left - pr.left) / pr.width, (r.top - pr.top) / pr.height, r.width / pr.width, r.height / pr.height]);
    return { start: `pdf:${pi + 1}`, end: `pdf:${pi + 1}`, rects, page: pi + 1 };
  }
  annotationAt(v, x, y) {
    for (const pageEl of v.el.querySelectorAll('.pdf-page')) {
      const pr = pageEl.getBoundingClientRect();
      const pi = +pageEl.dataset.page;
      const nx = (x - pr.left) / pr.width, ny = (y - pr.top) / pr.height;
      for (const a of this.annotations) {
        if (a.type !== 'highlight' || a.deleted || a.start !== `pdf:${pi + 1}` || !a.rects) continue;
        if (a.rects.some(r => nx >= r[0] && nx <= r[0] + r[2] && ny >= r[1] && ny <= r[1] + r[3])) {
          const range = document.createRange();
          range.selectNode(pageEl.querySelector('.pdf-hl'));
          const fake = { getClientRects: () => a.rects.map(r => new DOMRect(pr.left + r[0] * pr.width, pr.top + r[1] * pr.height, r[2] * pr.width, r[3] * pr.height)), getBoundingClientRect: () => { const rs = a.rects; const r = rs[0]; return new DOMRect(pr.left + r[0] * pr.width, pr.top + r[1] * pr.height, r[2] * pr.width, r[3] * pr.height); } };
          return { a, r: fake };
        }
      }
    }
    return null;
  }
  isBookmarked(bookmarks) {
    const pages = this.pagesOf(this.loc.spread).map(p => `pdf:${p + 1}`);
    return bookmarks.find(b => pages.includes(b.start)) || null;
  }

  // ---------- search ----------
  async search(query, onResult, token) {
    const q = query.trim().toLocaleLowerCase();
    if (!q) return;
    for (let i = 0; i < this.numPages; i++) {
      if (token.cancelled) return;
      let tc = this.textCache.get(i);
      if (!tc) { const page = await this.pdf.getPage(i + 1); tc = await page.getTextContent(); this.textCache.set(i, tc); }
      const text = tc.items.map(it => it.str + (it.hasEOL ? ' ' : '')).join('');
      const low = text.toLocaleLowerCase();
      let at = low.indexOf(q);
      while (at >= 0) {
        onResult({
          page: i, start: `pdf:${i + 1}`, chapter: 'Page ' + ((this.labels && this.labels[i]) || i + 1),
          before: (at > 40 ? '…' : '') + text.slice(Math.max(0, at - 40), at),
          match: text.slice(at, at + q.length),
          after: text.slice(at + q.length, at + q.length + 70) + '…',
        });
        at = low.indexOf(q, at + q.length);
      }
      if (i % 8 === 7) await new Promise(r => setTimeout(r, 0));
    }
  }
  showSearchHit() {}

  destroy() { for (const v of this.views) v.el.remove(); this.views = []; this.pdf && this.pdf.destroy(); }
}
