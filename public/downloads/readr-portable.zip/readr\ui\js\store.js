// Persistence over the host's /api (identical on the dev server).
// library.json  — book records + collections (owned by the library window)
// state/<id>.json — per-book reading position/progress (owned by the reader window)
// notes/<id>.json — annotations (AEAnnotation-shaped)
// settings.json — reader appearance (BookTheme-like overrides)
// pages/<id>.json — pagination cache {layoutKey: [pageCounts]}

const chan = 'BroadcastChannel' in window ? new BroadcastChannel('books') : null;
const listeners = new Set();
if (chan) chan.onmessage = e => listeners.forEach(fn => fn(e.data));
export const onBroadcast = fn => listeners.add(fn);
export const broadcast = msg => chan && chan.postMessage(msg);

export const isHost = !!(window.chrome && window.chrome.webview);
export function hostSend(...parts) {
  if (isHost) window.chrome.webview.postMessage(parts.join('|'));
}
export function onHostMessage(fn) {
  if (isHost) window.chrome.webview.addEventListener('message', e => fn(String(e.data)));
}

// Every /api call carries the per-launch key the native host gives the app's own pages
// (book content never receives it, so it cannot use the API). The dev server ignores it.
function api(url, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (window.__booksKey) headers['X-Books-Key'] = window.__booksKey;
  return fetch(url, { ...opts, headers });
}

export async function load(name, fallback = null) {
  try {
    const r = await api('/api/data/' + name, { cache: 'no-store' });
    if (!r.ok) return fallback;
    const v = await r.json();
    return v == null ? fallback : v;
  } catch { return fallback; }
}

const pending = new Map();
// Debounced, ordered writes per document
export function save(name, value, delay = 250) {
  const p = pending.get(name);
  if (p) clearTimeout(p.t);
  const entry = { value, t: setTimeout(() => flush(name), delay) };
  pending.set(name, entry);
}
export async function flush(name) {
  const p = pending.get(name);
  if (!p) return;
  pending.delete(name);
  clearTimeout(p.t);
  await api('/api/data/' + name, { method: 'PUT', body: JSON.stringify(p.value), keepalive: true });
}
export function flushAll() { for (const k of [...pending.keys()]) flush(k); }
addEventListener('pagehide', flushAll);
addEventListener('beforeunload', flushAll);

export async function importFile(file) {
  const r = await api('/api/import?name=' + encodeURIComponent(file.name), { method: 'POST', body: file });
  const j = await r.json();
  if (!r.ok || j.error) throw new Error(j.error || 'Import failed');
  return j;
}
// dev server only: the native host has no path import (it imports opened files itself)
export async function importPath(path) {
  const name = path.split(/[\\/]/).pop();
  const r = await api('/api/import?name=' + encodeURIComponent(name) + '&path=' + encodeURIComponent(path), { method: 'POST' });
  const j = await r.json();
  if (!r.ok || j.error) throw new Error(j.error || 'Import failed');
  return j;
}
export async function writeFile(path, blob) {
  await api('/api/file/' + path, { method: 'PUT', body: blob });
}
export async function deleteBook(id) {
  await api('/api/delete?id=' + encodeURIComponent(id), { method: 'POST' });
}

export const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2)).toUpperCase();

// native host: location + existence of books that are linked in place (not copied)
export async function links() {
  try { const r = await api('/api/links', { cache: 'no-store' }); return r.ok ? (await r.json()) || {} : {}; } catch { return {}; }
}
