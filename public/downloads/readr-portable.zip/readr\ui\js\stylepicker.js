// The Styles picker (studio themes), shared by the reader and the library window.
import { STUDIO, STUDIO_ORDER, resolveStudio } from './studio.js';
import * as T from './themes.js';
import { icon } from './icons.js';
import { h, popover } from './ui.js';

// the style fonts are needed in the app pages themselves (picker previews, chrome labels, library titles)
let fontsLoaded = false;
export function ensureStudioFonts() {
  if (fontsLoaded) return;
  fontsLoaded = true;
  document.head.append(h('style', { id: 'studio-fonts' }, Object.values(STUDIO).map(st => st.fonts.join('\n')).join('\n')));
}

// settings: { studio, theme, appearance }; onPick(id|null) applies + persists and may return a promise
export function showStylePicker(anchor, settings, onPick) {
  ensureStudioFonts();
  const box = h('div', { class: 'styles' });
  const render = () => {
    box.innerHTML = '';
    box.append(h('div', { class: 'styles-head' },
      h('div', { class: 'styles-title' }, 'Styles'),
      h('div', { class: 'styles-sub' }, 'Designer reading themes. Choose Apple Books to return to the original look.')));
    const grid = h('div', { class: 'styles-grid' });
    const apple = T.resolveTheme(settings.theme || 'original', settings.appearance || 'auto');
    grid.append(card({
      on: !settings.studio, name: 'Apple Books', tagline: `${apple.name} theme · set in Aa`,
      bg: apple.bg, text: apple.text, head: apple.text, texture: 'none', headFont: 'Georgia, serif', bodyFont: "'iBooks_Iowan_Old_Style', Georgia, serif",
      swatch: [apple.bg, apple.text, apple.link || apple.text],
    }, () => pick(null)));
    for (const id of STUDIO_ORDER) {
      const t = resolveStudio(id, settings.appearance || 'auto'), st = t.studio;
      grid.append(card({
        on: settings.studio === id, name: st.name, tagline: st.tagline, bg: t.bg, text: t.text, head: st.v.head, texture: st.texture,
        headFont: st.head, bodyFont: st.body, swatch: st.swatch, id,
        note: st.variants.light && st.variants.dark ? 'Follows Light / Dark' : (t.dark ? 'Dark' : 'Light'),
      }, () => pick(id)));
    }
    box.append(grid);
  };
  const pick = async id => { settings.studio = id; await onPick(id); render(); };
  render();
  return popover(anchor, box, { className: 'styles-pop', anchorEl: anchor });
}

function card(o, pick) {
  const preview = h('div', { class: 'sc-page sc-' + (o.id || 'apple'), style: { background: o.texture && o.texture !== 'none' ? `${o.texture}, ${o.bg}` : o.bg, color: o.text } },
    h('div', { class: 'sc-h', style: { fontFamily: o.headFont, color: o.head } }, 'Chapter One'),
    h('div', { class: 'sc-p', style: { fontFamily: o.bodyFont } }, 'It was the best of times; the sea was calm and the pages turned softly.'),
    h('div', { class: 'sc-dots' }, ...o.swatch.map(c => h('span', { style: { background: c } }))));
  return h('button', { class: 'style-card' + (o.on ? ' on' : ''), onclick: pick },
    preview,
    h('div', { class: 'sc-meta' },
      h('div', { class: 'sc-name' }, o.name, o.on ? h('span', { class: 'sc-check', html: icon('check') }) : null),
      h('div', { class: 'sc-tag' }, o.tagline),
      o.note ? h('div', { class: 'sc-note' }, o.note) : null));
}
