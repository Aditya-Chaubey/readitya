// Reader window (BookContentViewController equivalent): chrome, gestures, settings,
// annotations, search and persistence around an engine (EPUB paged / EPUB scroll / PDF).
import * as store from './store.js';
import { parseEpub, flatten } from './epub.js';
import { PagedEngine } from './epubengine.js';
import { ScrollEngine } from './scrollengine.js';
import { PdfEngine } from './pdfengine.js';
import { Turner } from './turner.js';
import * as T from './themes.js';
import { icon } from './icons.js';
import { $, $$, h, esc, popover, menu, closePopovers, anyPopoverOpen, alertDialog, toast, fmtDate } from './ui.js';
import * as CFI from './cfi.js';
import { windowControls, onWindowState } from './titlebar.js';
import { STUDIO, resolveStudio } from './studio.js';
import { showStylePicker, ensureStudioFonts } from './stylepicker.js';

const params = new URLSearchParams(location.search);
const bookId = params.get('id');

class Reader {
  constructor() {
    this.stage = $('#stage');
    this.turner = new Turner(this.stage);
    this.settings = { ...T.DEFAULT_SETTINGS };
    this.notes = [];
    this.state = {};
    this.pageCache = {};
    this.info = null;
    this.chromeVisible = false;
  }

  async init() {
    const lib = await store.load('library.json', { books: [] });
    this.record = (lib.books || []).find(b => b.id === bookId);
    if (!this.record) { document.body.innerHTML = '<div class="missing">This book is no longer in your library.</div>'; return; }
    document.title = this.record.title;
    store.hostSend('title', this.record.title);
    const [settings, state, notes, pages] = await Promise.all([
      store.load('settings.json', {}),
      store.load(`state/${bookId}.json`, {}),
      store.load(`notes/${bookId}.json`, []),
      store.load(`pages/${bookId}.json`, {}),
    ]);
    this.settings = { ...T.DEFAULT_SETTINGS, ...settings, overrides: settings.overrides || {} };
    this.state = state || {};
    this.notes = notes || [];
    this.pageCache = pages || {};
    this.buildChrome();

    this.kind = this.record.kind;
    if (this.kind === 'pdf') {
      this.book = { title: this.record.title, toc: [], spine: [] };
      this.engine = new PdfEngine(this, this.record, this.stage, this.turner);
      await this.engine.open();
      this.book.toc = this.engine.toc;
    } else {
      this.book = await parseEpub(`/lib/${bookId}/${this.record.root || 'content'}/`);
      this.engine = this.makeEngine();
    }
    this.engine.setAnnotations && this.engine.setAnnotations(this.notes);
    await this.layout(true);
    document.body.classList.remove('loading');
    this.markOpened();
    window.addEventListener('resize', () => { clearTimeout(this._rz); this._rz = setTimeout(() => this.layout(), 90); });
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => this.apply());
    store.onBroadcast(m => { if (m.type === 'settings' && m.from !== bookId) { this.settings = { ...this.settings, ...m.settings }; this.apply(); } });
    // show the chrome briefly when the book opens, then fade it away
    this.showChrome(true);
    this.hideChromeSoon(2600);
  }

  makeEngine() {
    if (this.settings.scroll) return new ScrollEngine(this, this.book, this.stage);
    return new PagedEngine(this, this.book, this.stage, this.turner);
  }

  // effective settings = global + per-theme overrides (BookTheme rows override the parent theme)
  get eff() {
    const s = this.settings;
    return { ...s, ...(s.overrides[this.themeKey] || {}) };
  }
  // Customize-panel overrides are stored per theme; a studio style has its own slot
  get themeKey() { return this.settings.studio && STUDIO[this.settings.studio] ? 'studio-' + this.settings.studio : this.settings.theme; }
  turnStyle() {
    const s = this.settings.turn;
    if (matchMedia('(prefers-reduced-motion: reduce)').matches && s === 'curl') return 'fastFade';
    return s;
  }

  computeLayout() {
    const s = this.eff;
    const theme = (s.studio && resolveStudio(s.studio, s.appearance)) || T.resolveTheme(s.theme, s.appearance);
    const W = this.stage.clientWidth, H = this.stage.clientHeight;
    let twoUp = s.layout === 'double' || (s.layout === 'auto' && W >= 960 && W > H * 1.12);
    if (s.scroll || W < 640) twoUp = false;
    const W2 = twoUp ? W - (W % 2) : W;
    const geo = T.pageGeometry(W2, H, twoUp, s);
    const css = T.contentCSS(s, theme, geo, s.scroll ? 'scroll' : 'paged');
    const key = [W2, H, geo.columns, s.family, s.size, s.lineHeight, s.letterSpacing, s.wordSpacing, s.margin, s.justify, s.hyphenate, T.isBold(s, theme), theme.type === 'original', s.studio || ''].join('|');
    return { theme, geo, css, key };
  }

  async layout(first) {
    const { theme, geo, css, key } = this.computeLayout();
    this.theme = theme;
    this.geo = geo;
    this.applyChromeColors(theme);
    if (first) {
      this.engine.configure(css, theme, geo, key);
      const target = this.state.cfi ? { cfi: this.state.cfi } : (this.state.page != null ? { page: this.state.page } : this.startTarget());
      try { await this.engine.display(target); } catch (e) { console.warn(e); await this.engine.display({ spine: 0 }); }
      this.engine.paginateAll && this.engine.paginateAll();
    } else {
      await this.engine.relayout(css, theme, geo, key);
    }
    this._layoutKey = key;
  }

  startTarget() {
    // open at body matter like Books (EPUB3 landmarks / guide "text"), else the start
    const lm = (this.book.landmarks || []).find(l => /bodymatter/.test(l.type || ''));
    return lm && lm.href ? { href: lm.href } : { spine: 0 };
  }

  // Called after any settings change
  async apply() {
    const { theme, geo, css, key } = this.computeLayout();
    const modeChanged = !!this.settings.scroll !== this.engine instanceof ScrollEngine && this.kind !== 'pdf';
    if (modeChanged) {
      const cfi = this.engine.currentCFI();
      this.engine.destroy();
      this.engine = this.makeEngine();
      this.engine.setAnnotations(this.notes);
      this.theme = theme; this.geo = geo;
      this.applyChromeColors(theme);
      this.engine.configure(css, theme, geo, key);
      await this.engine.display(cfi ? { cfi } : { spine: this.info ? this.info.spine : 0 });
      this.engine.paginateAll && this.engine.paginateAll();
      this._layoutKey = key;
      return;
    }
    this.theme = theme;
    this.applyChromeColors(theme);
    if (key === this._layoutKey) { this.engine.restyleOnly(css, theme); this.updateFolios(); return; }
    this.geo = geo;
    this._layoutKey = key;
    await this.engine.relayout(css, theme, geo, key);
  }

  // PaginationCache: keep page counts for the few most recent layout keys
  savePageCounts(key, counts) {
    this.pageCache[key] = counts;
    const keys = Object.keys(this.pageCache);
    if (keys.length > 4) delete this.pageCache[keys[0]];
    store.save(`pages/${bookId}.json`, this.pageCache, 1000);
  }

  saveSettings() {
    const { overrides, ...rest } = this.settings;
    store.save('settings.json', { ...rest, overrides });
    store.broadcast({ type: 'settings', from: bookId, settings: this.settings });
  }
  setSetting(k, v) { this.settings[k] = v; this.saveSettings(); return this.apply(); }
  setOverride(k, v) {
    const o = (this.settings.overrides[this.themeKey] = { ...(this.settings.overrides[this.themeKey] || {}) });
    if (v == null) delete o[k]; else o[k] = v;
    this.saveSettings();
    return this.apply();
  }

  applyChromeColors(theme) {
    document.body.classList.toggle('scroll-mode', !!this.settings.scroll && this.kind !== 'pdf');
    const c = T.chromeColors(theme);
    const r = document.documentElement.style;
    r.setProperty('--page-bg', theme.bg);
    r.setProperty('--page-text', theme.text);
    r.setProperty('--chrome-label', c.label);
    r.setProperty('--chrome-strong', c.labelStrong);
    r.setProperty('--chrome-tertiary', c.tertiary);
    r.setProperty('--chrome-sep', c.sep);
    r.setProperty('--chrome-fill', c.fill);
    document.body.classList.toggle('dark-page', theme.dark);
    document.documentElement.style.colorScheme = theme.dark ? 'dark' : 'light';
    // studio styles: chrome typography + their own page-back colour for the curl
    const st = theme.studio;
    document.body.classList.toggle('studio', !!st);
    if (st) ensureStudioFonts();
    const sb = $('#btn-styles');
    if (sb) sb.classList.toggle('active-style', !!st);
    r.setProperty('--chrome-font', st ? st.ui : '');
    r.setProperty('--chrome-case', st ? st.uiCase : 'none');
    r.setProperty('--page-accent', st ? st.v.link : '');
    if (st) {
      this.turner.setColors({ back0: st.v.curl, back1: st.v.curl, dark: theme.dark });
      store.hostSend('chrome', theme.bg, theme.dark ? 'dark' : 'light');
      return;
    }
    this.turner.setColors({ back0: c.curlBack, back1: T.mix(theme.bg.startsWith('#') ? theme.bg : '#4A4A4D', theme.dark ? '#ffffff' : '#000000', theme.dark ? 0.05 : 0.02), dark: theme.dark });
    store.hostSend('chrome', theme.bg.startsWith('#') ? theme.bg : '#4A4A4D', theme.dark ? 'dark' : 'light');
  }

  // ---------------- chrome ----------------
  buildChrome() {
    $('#btn-library').innerHTML = icon('library');
    $('#btn-toc').innerHTML = icon('list');
    $('#btn-notes').innerHTML = icon('notes');
    $('#btn-appearance').innerHTML = icon('textsize');
    $('#btn-styles').innerHTML = icon('palette');
    $('#btn-styles').onclick = e => this.showStyles(e.currentTarget);
    $('#btn-search').innerHTML = icon('search');
    $('#btn-bookmark').innerHTML = icon('bookmark');
    $('#btn-fullscreen').innerHTML = icon('fullscreen');
    $('#btn-fullscreen').onclick = () => this.toggleFullscreen();
    const wc = windowControls();
    if (wc) $('#winctl').replaceWith(wc);
    onWindowState(st => this.setFullscreenState(st === 'full'));
    document.addEventListener('fullscreenchange', () => this.setFullscreenState(!!document.fullscreenElement));
    $('#arrow-prev').innerHTML = icon('chevronLeft');
    $('#arrow-next').innerHTML = icon('chevronRight');
    $('#tb-title').textContent = this.record.title;
    $('#runhead').textContent = this.record.title;

    $('#btn-library').onclick = () => this.openLibrary();
    $('#btn-toc').onclick = e => this.showTOC(e.currentTarget);
    $('#btn-notes').onclick = () => this.toggleNotes();
    $('#btn-appearance').onclick = e => this.showAppearance(e.currentTarget);
    $('#btn-search').onclick = e => this.showSearch(e.currentTarget);
    $('#btn-bookmark').onclick = () => this.toggleBookmark();
    $('#arrow-prev').onclick = () => this.turn(-1);
    $('#arrow-next').onclick = () => this.turn(1);

    document.addEventListener('keydown', e => this.onKey(e));
    document.addEventListener('mousemove', e => this.onPointerMove(e.clientX, e.clientY));
    document.addEventListener('wheel', e => this.onWheel(e), { passive: false });
    $('#toolbar').addEventListener('mouseenter', () => this.showChrome(true));
    $('#footer').addEventListener('mouseenter', () => this.showChrome(true));
    this.setupScrubber();
  }

  showChrome(on) {
    if (this.chromeVisible === on) return;
    this.chromeVisible = on;
    document.body.classList.toggle('chrome-on', on);
  }
  hideChromeSoon(ms = 1800) {
    clearTimeout(this._chromeT);
    this._chromeT = setTimeout(() => {
      if (anyPopoverOpen() || this._scrubbing || document.body.classList.contains('notes-open')) return this.hideChromeSoon(ms);
      if (this._overChrome) return this.hideChromeSoon(ms);
      this.showChrome(false);
    }, ms);
  }
  onPointerMove(x, y) {
    const H = innerHeight;
    this._overChrome = y < 64 || y > H - 64;
    document.body.classList.toggle('near-left', x < Math.min(110, (this.geo ? this.geo.side : 80) + 20) && y > 64 && y < H - 64);
    document.body.classList.toggle('near-right', x > innerWidth - Math.min(110, (this.geo ? this.geo.side : 80) + 20) && y > 64 && y < H - 64);
    if (this._overChrome) { this.showChrome(true); this.hideChromeSoon(); }
  }
  chromeDuringTurn(on) {
    // kMostlyFadeChrome: chrome fades while a page is moving
    document.body.classList.toggle('turning', on);
  }

  openLibrary() {
    if (store.isHost) window.open('/ui/index.html', '_blank');
    else location.href = '/ui/index.html';
  }

  // ---------------- turning & input ----------------
  turn(dir, opts) {
    closePopovers();
    if (this.engine.go) return this.engine.go(dir, opts);
  }
  atEdge(dir) {
    if (dir > 0) this.reachedEnd();
  }

  onKey(e) {
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
    const ctrl = e.ctrlKey || e.metaKey;
    const k = e.key;
    const rtl = this.book && this.book.ppd === 'rtl';
    if (ctrl && (k === '=' || k === '+')) { e.preventDefault(); return this.bumpSize(1); }
    if (ctrl && k === '-') { e.preventDefault(); return this.bumpSize(-1); }
    if (ctrl && k === '0') { e.preventDefault(); return this.setSetting('size', T.DEFAULT_SIZE); }
    if (ctrl && (k === 'f' || k === 'F')) { e.preventDefault(); return this.showSearch($('#btn-search')); }
    if (ctrl && (k === 'd' || k === 'D')) { e.preventDefault(); return this.toggleBookmark(); }
    if (ctrl && (k === 'w' || k === 'W')) { e.preventDefault(); store.flushAll(); return store.isHost ? store.hostSend('close') : window.close(); }
    if (ctrl && e.shiftKey && (k === 'l' || k === 'L')) { e.preventDefault(); return this.openLibrary(); }
    if (ctrl && (k === 'c' || k === 'C')) return; // native copy
    if (k === 'F11' || (ctrl && e.shiftKey && (k === 'f' || k === 'F'))) { e.preventDefault(); return this.toggleFullscreen(); }
    if (k === 'Escape') { if (this._fullscreen) this.toggleFullscreen(); return; }
    if (this.settings.scroll && this.kind !== 'pdf') { this.toggleChrome(); return; } // native scrolling
    if (anyPopoverOpen() && !['ArrowLeft', 'ArrowRight'].includes(k)) return;
    let dir = 0;
    if (k === 'ArrowRight' || k === 'PageDown' || (k === ' ' && !e.shiftKey) || k === 'ArrowDown') dir = 1;
    if (k === 'ArrowLeft' || k === 'PageUp' || (k === ' ' && e.shiftKey) || k === 'ArrowUp') dir = -1;
    if (rtl && (k === 'ArrowLeft' || k === 'ArrowRight')) dir = -dir;
    if (k === 'Home') { e.preventDefault(); return this.engine.display({ spine: 0 }); }
    if (k === 'End') { e.preventDefault(); return this.engine.display({ spine: this.book.spine.length - 1, page: 'last' }); }
    if (dir) {
      e.preventDefault();
      // a held key: only start the next turn once the current one is done, so flipping stops the
      // moment the key is released; repeats flip faster than single presses
      if (e.repeat && this.engine.turning) return;
      this.turn(dir, { fast: e.repeat });
    }
  }

  bumpSize(d) {
    const n = Math.max(0, Math.min(T.SIZE_STEPS - 1, this.settings.size + d));
    if (n !== this.settings.size) this.setSetting('size', n);
  }

  // distraction-free reading: window fills the screen, chrome stays hidden until the pointer
  // reaches the top edge
  toggleFullscreen() {
    const on = !this._fullscreen;
    if (store.isHost) store.hostSend('fullscreen', on ? '1' : '0');
    else if (on) document.documentElement.requestFullscreen().catch(() => {});
    else if (document.fullscreenElement) document.exitFullscreen();
    this.setFullscreenState(on);
    if (on) { closePopovers(); this.showChrome(false); }
  }
  setFullscreenState(on) {
    this._fullscreen = on;
    document.body.classList.toggle('fullscreen', on);
    const b = $('#btn-fullscreen');
    if (b) { b.innerHTML = icon(on ? 'exitFullscreen' : 'fullscreen'); b.title = on ? 'Exit Full Screen (F11)' : 'Enter Full Screen (F11)'; }
  }

  // Trackpad two-finger swipe -> interactive turn; mouse wheel -> one page per notch
  onWheel(e) {
    if (this.settings.scroll && this.kind !== 'pdf') { this.toggleChrome(); return; }
    if (e.ctrlKey) { e.preventDefault(); return; }
    if (e.target.closest && e.target.closest('.popover, .side-panel, .menu')) return;
    e.preventDefault();
    const ax = Math.abs(e.deltaX), ay = Math.abs(e.deltaY);
    const rtl = this.book && this.book.ppd === 'rtl';
    if (ax > ay && ax > 0.5) {
      const s = this._swipe || (this._swipe = { total: 0, started: false, dir: 0, pending: null, last: 0 });
      s.total += e.deltaX;
      s.last = e.deltaX;
      if (!s.dir && Math.abs(s.total) > 6) {
        s.dir = Math.sign(s.total) * (rtl ? -1 : 1);
        s.pending = this.engine.dragBegin ? this.engine.dragBegin(s.dir).then(ok => (s.started = ok)) : Promise.resolve(false);
      }
      if (s.started) {
        const p = Math.max(0, (s.total * (rtl ? -1 : 1) * s.dir) / (this.stage.clientWidth * 0.75));
        this.engine.dragUpdate(Math.min(1, p));
      }
      clearTimeout(s.t);
      s.t = setTimeout(() => this.endSwipe(), 130);
      return;
    }
    if (ay > ax && !this._swipe) {
      // discrete wheel notches turn pages (throttled)
      const now = performance.now();
      if (now - (this._wheelT || 0) < 260) return;
      if (ay < 4) return;
      this._wheelT = now;
      this.turn(e.deltaY > 0 ? 1 : -1);
    }
  }
  async endSwipe() {
    const s = this._swipe;
    if (!s) return;
    if (s.pending) await s.pending;
    this._swipe = null;
    if (!s.started) return;
    const rtl = this.book && this.book.ppd === 'rtl';
    const p = (s.total * (rtl ? -1 : 1) * s.dir) / (this.stage.clientWidth * 0.75);
    const flick = Math.sign(s.last) * (rtl ? -1 : 1) === s.dir && Math.abs(s.last) > 8;
    await this.engine.dragEnd(p > 0.18 || (flick && p > 0.04));
  }

  // Page drags: touch/pen anywhere, or a mouse grab on the "paper" (margins, gutter, between lines,
  // images) — a press on words still selects text like Books. The fold tracks the pointer.
  onFramePointerDown(f, e) {
    if (e.button !== 0 || this.turner.busy || this.engine._drag) return;
    if (e.target.closest && e.target.closest('a[href]')) return;
    const g = this.geo;
    if (e.pointerType === 'mouse' && this.kind !== 'pdf' && overText(f.doc, e.clientX, e.clientY, g)) return;
    if (e.pointerType === 'mouse' && this.kind === 'pdf' && e.target.closest && e.target.closest('.textLayer span')) return;
    e.preventDefault();
    const doc = f.doc, root = doc.documentElement;
    const rect = f.iframe.getBoundingClientRect();
    // screen coordinates: immune to the page itself moving under the pointer during a slide
    const st = { sx: e.screenX, sy: e.screenY, x: e.clientX + rect.left, y: e.clientY + rect.top, dir: 0, started: false, pending: null, last: { x: e.screenX, t: e.timeStamp }, vx: 0 };
    const W = this.stage.clientWidth, H = this.stage.clientHeight;
    const twoUp = this.kind === 'pdf' ? !!this.engine.twoUp : this.geo.columns > 1;
    const x0 = twoUp ? W / 2 : 0, w = W - x0;
    const corner = st.y < H / 2 ? 'top' : 'bottom';
    const cy = corner === 'top' ? 0 : H;
    try { root.setPointerCapture(e.pointerId); } catch {}
    root.style.userSelect = 'none';
    const move = ev => {
      const dx = ev.screenX - st.sx, dy = ev.screenY - st.sy;
      if (!st.dir && Math.abs(dx) > 6 && Math.abs(dx) > Math.abs(dy) * 0.6) {
        st.dir = dx < 0 ? 1 : -1;
        if (this.book.ppd === 'rtl') st.dir = -st.dir;
        doc.getSelection && doc.getSelection().removeAllRanges();
        st.pending = this.engine.dragBegin(st.dir).then(ok => (st.started = ok));
      }
      const dt = Math.max(1, ev.timeStamp - st.last.t);
      st.vx = 0.7 * ((ev.screenX - st.last.x) / dt) + 0.3 * st.vx;
      st.last = { x: ev.screenX, t: ev.timeStamp };
      if (!st.started) return;
      const p = Math.max(0, Math.min(1, (-dx * st.dir) / (this.turnStyle() === 'curl' ? w : W)));
      let point = null;
      if (this.turnStyle() === 'curl') {
        // corner = C + 2·Δx keeps the fold line (midpoint of corner and C) right under the pointer's travel
        const lift = Math.sin(Math.PI * p) * H * 0.16 * (corner === 'top' ? -1 : 1);
        const baseX = st.dir > 0 ? W : x0 - w;
        point = { x: baseX + 2 * dx, y: cy + dy - lift, corner };
      }
      this.engine.dragUpdate(p, point);
    };
    const up = async () => {
      doc.removeEventListener('pointermove', move);
      doc.removeEventListener('pointerup', up);
      doc.removeEventListener('pointercancel', up);
      root.style.userSelect = '';
      if (!st.dir) return;
      this._suppressClick = true;
      setTimeout(() => (this._suppressClick = false), 60);
      if (st.pending) await st.pending;
      if (!st.started) return;
      const dx = st.last.x - st.sx;
      const p = (-dx * st.dir) / (this.turnStyle() === 'curl' ? w : W);
      const fling = -st.vx * st.dir > 0.4;
      await this.engine.dragEnd(p > 0.25 || (fling && p > 0.02));
    };
    doc.addEventListener('pointermove', move);
    doc.addEventListener('pointerup', up);
    doc.addEventListener('pointercancel', up);
  }

  onFrameMouseDown(f, e) { this._downAt = { x: e.clientX, y: e.clientY }; }

  onFrameClick(f, e) {
    if (this._suppressClick) return;
    const a = e.target.closest && e.target.closest('a[href]');
    if (a) { e.preventDefault(); return this.followLink(f, a); }
    if (anyPopoverOpen()) { closePopovers(); return; }
    const sel = f.doc.getSelection();
    if (sel && !sel.isCollapsed) return;
    if (this._downAt && Math.hypot(e.clientX - this._downAt.x, e.clientY - this._downAt.y) > 5) return;
    const hit = this.engine.annotationAt && this.engine.annotationAt(f, e.clientX, e.clientY);
    if (hit) return this.showHighlightMenu(f, hit, e);
    if (this.settings.scroll && this.kind !== 'pdf') { this.toggleChrome(); return; }
    // A mouse click never turns the page (Books on Mac): it only shows/hides the chrome.
    // Touch/pen taps keep the iPad tap zones: outer thirds turn (BKLeftTapTurnToNext flips the left zone).
    if (e.pointerType !== 'touch' && e.pointerType !== 'pen') { this.toggleChrome(); return; }
    const rect = f.iframe.getBoundingClientRect();
    const x = e.clientX + rect.left;
    const W = this.stage.clientWidth;
    const rtl = this.book.ppd === 'rtl';
    if (x < W / 3) this.turn(this.settings.leftTapNext ? 1 : (rtl ? 1 : -1));
    else if (x > (W * 2) / 3) this.turn(rtl ? -1 : 1);
    else this.toggleChrome();
  }
  toggleChrome() {
    this.showChrome(!this.chromeVisible);
    if (this.chromeVisible) this.hideChromeSoon(3500);
  }

  async followLink(f, a) {
    const href = a.getAttribute('href');
    if (/^(https?|mailto):/i.test(href)) { window.open(href, '_blank'); return; }
    const base = this.engine.docURL ? this.engine.docURL(f) : this.book.spine[f.spine].href;
    const url = new URL(href, base).href;
    const type = a.getAttribute('epub:type') || a.getAttributeNS('http://www.idpf.org/2007/ops', 'type') || '';
    if (/noteref/.test(type)) {
      const note = await this.footnoteContent(url);
      if (note) {
        const r = a.getBoundingClientRect(), fr = f.iframe.getBoundingClientRect();
        const box = h('div', { class: 'footnote' });
        box.textContent = note;
        popover({ x: r.left + fr.left, y: r.top + fr.top, w: r.width, h: r.height }, box, { className: 'footnote-pop' });
        return;
      }
    }
    this.pushHistory();
    await this.engine.display({ href: url });
  }
  async footnoteContent(url) {
    const [file, hash] = url.split('#');
    if (!hash) return null;
    try {
      const text = await (await fetch(file)).text();
      const doc = new DOMParser().parseFromString(text, /\.x?html?$/i.test(file) && !/\.html?$/i.test(file) ? 'application/xhtml+xml' : 'text/html');
      let el = doc.getElementById(decodeURIComponent(hash));
      if (!el) return null;
      if (el.localName === 'a' && el.parentElement) el = el.parentElement;
      return el.textContent.replace(/\s+/g, ' ').trim();
    } catch { return null; }
  }
  pushHistory() { this._history = this.engine.currentCFI(); }

  // ---------------- relocation / progress ----------------
  onRelocate(info) {
    this.info = info;
    this.updateFolios();
    this.updateBookmarkButton();
    const s = this.state;
    s.cfi = info.cfi || s.cfi;
    if (info.pdfPage != null) s.page = info.pdfPage;
    s.fraction = info.fraction;
    s.updated = Date.now();
    s.highWater = Math.max(s.highWater || 0, info.fraction || 0);
    store.save(`state/${bookId}.json`, s, 500);
    store.broadcast({ type: 'progress', id: bookId, fraction: info.fraction, lastOpen: Date.now() });
    if (info.atEnd) this.reachedEnd();
  }
  markOpened() {
    this.state.opened = Date.now();
    store.save(`state/${bookId}.json`, this.state, 100);
    store.broadcast({ type: 'progress', id: bookId, fraction: this.state.fraction || 0, lastOpen: Date.now() });
  }
  reachedEnd() {
    if (this.state.finished) return;
    this.state.finished = Date.now();
    store.save(`state/${bookId}.json`, this.state, 100);
    store.broadcast({ type: 'finished', id: bookId });
  }

  updateFolios() {
    const info = this.info;
    const fol = $('#folios');
    if (!info) return;
    const g = this.geo;
    $('#runhead').textContent = info.chapter && info.chapter.label ? info.chapter.label : this.record.title;
    if (this.settings.scroll && this.kind !== 'pdf') { fol.innerHTML = ''; this.updateScrub(); return; }
    const pageLabel = n => (info.pageLabels && info.pageLabels[n - 1]) || String(n);
    if (info.global != null) {
      const first = info.global * info.columns + 1;
      const total = info.totalColumns;
      if (info.columns > 1) {
        fol.innerHTML = `<span style="left:${g.W / 4}px">${pageLabel(first)}</span>` + (first + 1 <= total ? `<span style="left:${(3 * g.W) / 4}px">${pageLabel(first + 1)}</span>` : '');
      } else {
        fol.innerHTML = `<span style="left:${g.W / 2}px">${pageLabel(first)}</span>`;
      }
    } else fol.innerHTML = '';
    this.updateScrub();
  }

  setupScrubber() {
    const scrub = $('#scrub');
    const track = scrub.querySelector('.scrub-track');
    const at = e => {
      const r = track.getBoundingClientRect();
      return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    };
    track.addEventListener('pointerdown', e => {
      track.setPointerCapture(e.pointerId);
      this._scrubbing = at(e);
      this.updateScrub();
    });
    track.addEventListener('pointermove', e => {
      if (this._scrubbing == null || this._scrubbing === false) return;
      this._scrubbing = at(e);
      this.updateScrub();
    });
    track.addEventListener('pointerup', async e => {
      const f = at(e);
      this._scrubbing = null;
      this.pushHistory();
      await this.engine.display({ fraction: f });
    });
  }
  updateScrub() {
    const info = this.info;
    if (!info) return;
    const f = typeof this._scrubbing === 'number' ? this._scrubbing : info.fraction || 0;
    $('#scrub-fill').style.width = f * 100 + '%';
    $('#scrub-knob').style.left = f * 100 + '%';
    let label = '';
    if (typeof this._scrubbing === 'number' && info.totalColumns) {
      label = `Page ${Math.max(1, Math.round(f * (info.totalColumns - 1)) + 1)} of ${info.totalColumns}`;
    } else if (info.totalColumns) {
      const p = info.global * info.columns + 1;
      const left = info.chapter ? info.chapter.pagesLeft * info.columns : 0;
      label = `${p} of ${info.totalColumns}` + (left > 0 ? `  ·  ${left} ${left === 1 ? 'page' : 'pages'} left in this chapter` : '');
    } else label = `${Math.round(f * 100)}%`;
    $('#scrub-label').textContent = label;
  }

  // ---------------- bookmarks ----------------
  bookmarks() { return this.notes.filter(n => n.type === 'bookmark' && !n.deleted); }
  updateBookmarkButton() {
    const b = this.engine.isBookmarked ? this.engine.isBookmarked(this.bookmarks()) : null;
    this._curBookmark = b;
    $('#btn-bookmark').innerHTML = icon(b ? 'bookmarkFill' : 'bookmark');
    $('#btn-bookmark').classList.toggle('marked', !!b);
    $('#ribbon').classList.toggle('on', !!b);
  }
  toggleBookmark() {
    if (this._curBookmark) {
      this._curBookmark.deleted = true;
      this._curBookmark.modified = Date.now();
    } else {
      const cfi = this.engine.currentCFI();
      if (!cfi) return;
      this.notes.push({
        uuid: store.uid(), assetID: bookId, type: 'bookmark', start: cfi, end: cfi,
        text: this.engine.textAt ? this.engine.textAt(cfi) : '', chapter: this.info && this.info.chapter ? this.info.chapter.label : '',
        page: this.info && this.info.global != null ? this.info.global * this.info.columns + 1 : null,
        created: Date.now(), modified: Date.now(),
      });
    }
    this.saveNotes();
    this.updateBookmarkButton();
  }
  saveNotes() {
    store.save(`notes/${bookId}.json`, this.notes.filter(n => !n.deleted || Date.now() - n.modified < 864e5 * 30));
    this.engine.setAnnotations && this.engine.setAnnotations(this.notes);
    if (document.body.classList.contains('notes-open')) this.renderNotes();
  }

  // ---------------- selection & highlights ----------------
  onFrameMouseUp(f, e) {
    const sel = f.doc.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return;
    const range = sel.getRangeAt(0);
    if (this.kind !== 'pdf' && snapToWords(range)) { sel.removeAllRanges(); sel.addRange(range); }
    const text = sel.toString().trim();
    if (!text) return;
    this.showSelectionMenu(f, range, text);
  }
  frameRect(f, r) {
    const fr = f.iframe.getBoundingClientRect();
    const rects = [...r.getClientRects()].filter(x => x.width > 0 && x.right > 0 && x.left < fr.width);
    const a = rects[0] || r.getBoundingClientRect();
    const b = rects[rects.length - 1] || a;
    const top = Math.min(a.top, b.top), bottom = Math.max(a.bottom, b.bottom);
    const left = Math.min(...rects.map(x => x.left), a.left), right = Math.max(...rects.map(x => x.right), a.right);
    return { x: left + fr.left, y: top + fr.top, w: right - left, h: bottom - top };
  }
  showSelectionMenu(f, range, text) {
    const rect = this.frameRect(f, range);
    const bar = this.colorBar(null, style => {
      const n = this.addHighlight(this.engine.rangeCFIs(f, range), text, style);
      f.doc.getSelection().removeAllRanges();
      return n;
    }, [
      { label: 'Add Note', icon: 'note', act: () => { const n = this.addHighlight(this.engine.rangeCFIs(f, range), text, 3); f.doc.getSelection().removeAllRanges(); this.editNote(n, rect); } },
      { label: 'Copy', icon: 'copy', act: () => { navigator.clipboard.writeText(text).catch(() => f.doc.execCommand('copy')); toast('Copied'); } },
      { label: 'Search', icon: 'search', act: () => { f.doc.getSelection().removeAllRanges(); this.showSearch($('#btn-search'), text); } },
    ]);
    popover(rect, bar, { className: 'sel-pop', placement: 'above' });
  }
  showHighlightMenu(f, hit, e) {
    const r = this.frameRect(f, hit.r);
    const n = hit.a;
    const bar = this.colorBar(n, style => {
      if (style === 0) n.underline = !n.underline; else { n.style = style; n.underline = false; }
      n.modified = Date.now();
      this.saveNotes();
      return n;
    }, [
      { label: n.note ? 'Edit Note' : 'Add Note', icon: 'note', act: () => this.editNote(n, r) },
      { label: 'Copy', icon: 'copy', act: () => { navigator.clipboard.writeText(n.text || ''); toast('Copied'); } },
      { label: 'Remove', icon: 'trash', act: () => { n.deleted = true; n.modified = Date.now(); this.saveNotes(); } },
    ]);
    popover(r, bar, { className: 'sel-pop', placement: 'above' });
  }
  colorBar(current, onPick, actions) {
    const bar = h('div', { class: 'colorbar' });
    const dots = h('div', { class: 'cb-colors' });
    for (const c of T.HIGHLIGHTS) {
      const on = current && !current.underline && current.style === c.id;
      dots.append(h('button', { class: 'cb-dot' + (on ? ' on' : ''), title: c.name, style: { '--c': c.swatch }, onclick: () => { onPick(c.id); closePopovers(); } }));
    }
    dots.append(h('button', { class: 'cb-dot underline' + (current && current.underline ? ' on' : ''), title: 'Underline', html: icon('underline'), onclick: () => { onPick(0); closePopovers(); } }));
    bar.append(dots);
    for (const a of actions) bar.append(h('button', { class: 'cb-act', onclick: () => { closePopovers(); setTimeout(a.act, 10); } }, a.label));
    return bar;
  }
  addHighlight(loc, text, style) {
    const n = {
      uuid: store.uid(), assetID: bookId, type: 'highlight', style: style === 0 ? 3 : style, underline: style === 0,
      start: loc.start, end: loc.end, rects: loc.rects, page: loc.page, text, note: '', chapter: this.info && this.info.chapter ? this.info.chapter.label : '',
      created: Date.now(), modified: Date.now(),
    };
    this.notes.push(n);
    this.saveNotes();
    return n;
  }
  editNote(n, rect) {
    const ta = h('textarea', { class: 'note-text', placeholder: 'Add Note', spellcheck: 'true' });
    ta.value = n.note || '';
    const box = h('div', { class: 'note-editor' },
      h('div', { class: 'note-date' }, fmtDate(n.created)),
      ta);
    popover(rect, box, {
      className: 'note-pop', onClose: () => {
        const v = ta.value.trim();
        if (v !== (n.note || '')) { n.note = v; n.modified = Date.now(); this.saveNotes(); }
      },
    });
    setTimeout(() => ta.focus(), 50);
  }
  onFrameContext(f, e) {
    e.preventDefault();
    const sel = f.doc.getSelection();
    const fr = f.iframe.getBoundingClientRect();
    const text = sel ? sel.toString().trim() : '';
    menu(e.clientX + fr.left, e.clientY + fr.top, [
      { label: 'Copy', disabled: !text, action: () => navigator.clipboard.writeText(text) },
      { label: 'Highlight', disabled: !text, action: () => { this.addHighlight(this.engine.rangeCFIs(f, sel.getRangeAt(0)), text, 3); sel.removeAllRanges(); } },
      { label: 'Search in Book', disabled: !text, action: () => this.showSearch($('#btn-search'), text) },
      { sep: true },
      { label: this._curBookmark ? 'Remove Bookmark' : 'Add Bookmark', shortcut: 'Ctrl+D', action: () => this.toggleBookmark() },
      { label: 'Table of Contents', action: () => this.showTOC($('#btn-toc')) },
    ]);
  }

  // ---------------- TOC ----------------
  showTOC(anchor) {
    const info = this.info || {};
    const list = h('div', { class: 'toc-list' });
    const flat = flatten(this.book.toc);
    const cur = info.chapter && info.chapter.entry;
    const counts = this.engine.counts;
    for (const t of flat) {
      let page = '';
      if (counts && t.spine != null && this.kind !== 'pdf') {
        const before = counts.slice(0, t.spine).reduce((a, b) => a + b, 0);
        const hash = t.href && t.href.split('#')[1];
        const within = hash && this.engine.anchors ? this.engine.anchors[t.spine + '#' + hash] || 0 : 0;
        page = (before + within) * this.geo.columns + 1;
      } else if (t.pdfPage != null) page = t.pdfPage + 1;
      const row = h('button', { class: 'toc-row' + (t === cur ? ' current' : ''), style: { paddingLeft: 16 + t.level * 16 + 'px' } },
        h('span', { class: 'toc-label' }, t.label || 'Untitled'),
        h('span', { class: 'toc-page' }, page ? String(page) : ''));
      row.onclick = () => { closePopovers(); this.pushHistory(); this.engine.display(t.pdfPage != null ? { page: t.pdfPage } : { href: t.href }); };
      list.append(row);
    }
    const head = h('div', { class: 'toc-head' },
      this.record.cover ? h('img', { class: 'toc-cover', src: this.record.cover, alt: '' }) : h('div', { class: 'toc-cover generic' }),
      h('div', { class: 'toc-meta' },
        h('div', { class: 'toc-title' }, this.record.title),
        h('div', { class: 'toc-author' }, this.record.author || ''),
        h('div', { class: 'toc-progress' }, info.fraction != null ? `${Math.round(info.fraction * 100)}% read` : '')));
    const p = popover(anchor, h('div', { class: 'toc' }, head, list), { className: 'toc-pop', anchorEl: anchor });
    const c = list.querySelector('.current');
    if (c) c.scrollIntoView({ block: 'center' });
    p.place();
  }

  // ---------------- Notes panel ----------------
  toggleNotes() {
    const on = !document.body.classList.contains('notes-open');
    document.body.classList.toggle('notes-open', on);
    if (on) this.renderNotes();
  }
  renderNotes() {
    const panel = $('#notes-panel');
    const tab = this._notesTab || 'highlights';
    const items = this.notes.filter(n => !n.deleted && (tab === 'bookmarks' ? n.type === 'bookmark' : n.type === 'highlight'))
      .sort((a, b) => (a.start.startsWith('epubcfi') && b.start.startsWith('epubcfi') ? CFI.compare(a.start, b.start) : (a.page || 0) - (b.page || 0)));
    panel.innerHTML = '';
    const seg = h('div', { class: 'seg' },
      h('button', { class: tab === 'highlights' ? 'on' : '', onclick: () => { this._notesTab = 'highlights'; this.renderNotes(); } }, 'Highlights & Notes'),
      h('button', { class: tab === 'bookmarks' ? 'on' : '', onclick: () => { this._notesTab = 'bookmarks'; this.renderNotes(); } }, 'Bookmarks'));
    panel.append(h('div', { class: 'side-head' },
      h('div', { class: 'side-title' }, 'Notes'),
      h('button', { class: 'icon-btn', title: 'Close', html: icon('close'), onclick: () => this.toggleNotes() })), h('div', { class: 'side-seg' }, seg));
    const body = h('div', { class: 'side-body' });
    if (!items.length) {
      body.append(h('div', { class: 'side-empty' },
        h('div', { class: 'side-empty-title' }, tab === 'bookmarks' ? 'No Bookmarks' : 'No Highlights or Notes'),
        h('div', {}, tab === 'bookmarks' ? 'Press Ctrl+D or click the bookmark button to bookmark a page.' : 'Select text and choose a colour to highlight it.')));
    }
    let lastChapter = null;
    for (const n of items) {
      if (n.chapter !== lastChapter) { body.append(h('div', { class: 'note-chapter' }, n.chapter || 'Untitled')); lastChapter = n.chapter; }
      const color = (T.HIGHLIGHTS.find(c => c.id === n.style) || T.HIGHLIGHTS[0]).swatch;
      const card = h('div', { class: 'note-card' + (n.type === 'bookmark' ? ' bm' : ''), style: { '--c': n.underline ? '#FF3B30' : color } },
        h('div', { class: 'note-card-date' }, fmtDate(n.created) + (n.page ? ` · Page ${n.page}` : '')),
        n.type === 'bookmark' ? h('div', { class: 'note-card-text' }, n.text || 'Bookmark') : h('div', { class: 'note-card-quote' }, n.text),
        n.note ? h('div', { class: 'note-card-note' }, n.note) : null,
        h('button', { class: 'note-del icon-btn', title: 'Delete', html: icon('trash'), onclick: e => { e.stopPropagation(); n.deleted = true; n.modified = Date.now(); this.saveNotes(); this.updateBookmarkButton(); } }));
      card.onclick = () => this.engine.display({ cfi: n.start });
      body.append(card);
    }
    panel.append(body);
  }

  // ---------------- Search ----------------
  showSearch(anchor, preset) {
    const input = h('input', { class: 'search-field', type: 'search', placeholder: 'Search Book', spellcheck: 'false' });
    const status = h('div', { class: 'search-status' });
    const results = h('div', { class: 'search-results' });
    const box = h('div', { class: 'search' }, h('div', { class: 'search-bar', html: icon('search') }, input), status, results);
    popover(anchor, box, { className: 'search-pop', anchorEl: anchor, onClose: () => { if (this._searchTok) this._searchTok.cancelled = true; this.engine.showSearchHit && this.engine.showSearchHit(null); } });
    const run = () => {
      if (this._searchTok) this._searchTok.cancelled = true;
      const q = input.value.trim();
      results.innerHTML = '';
      this._lastQuery = q;
      if (!q) { status.textContent = ''; return; }
      const tok = (this._searchTok = { cancelled: false });
      let count = 0, lastCh = null;
      status.textContent = 'Searching…';
      const frag = () => results;
      this.engine.search(q, r => {
        if (tok.cancelled) return;
        count++;
        if (count > 1000) return;
        if (r.chapter !== lastCh) { frag().append(h('div', { class: 'search-chapter' }, r.chapter || '')); lastCh = r.chapter; }
        const row = h('button', { class: 'search-row', html: `${esc(r.before)}<b>${esc(r.match)}</b>${esc(r.after)}` });
        row.onclick = () => {
          $$('.search-row.on', results).forEach(x => x.classList.remove('on'));
          row.classList.add('on');
          this.engine.showSearchHit && this.engine.showSearchHit(r);
          this.engine.display(r.start ? { cfi: r.start } : { page: r.page });
        };
        frag().append(row);
        status.textContent = `${count} ${count === 1 ? 'result' : 'results'}`;
      }, tok).then(() => { if (!tok.cancelled) status.textContent = count ? `${count} ${count === 1 ? 'result' : 'results'}` : 'No results'; });
    };
    let t;
    input.addEventListener('input', () => { clearTimeout(t); t = setTimeout(run, 280); });
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { clearTimeout(t); run(); } });
    input.value = preset || this._lastQuery || '';
    setTimeout(() => { input.focus(); input.select(); if (input.value) run(); }, 30);
  }


  // ---------------- Styles (studio themes, separate from Apple's "Aa") ----------------
  showStyles(anchor) {
    showStylePicker(anchor, this.settings, () => { this.saveSettings(); return this.apply(); });
  }

  // ---------------- Appearance (Themes & Settings) ----------------
  showAppearance(anchor) {
    const s = this.settings;
    const box = h('div', { class: 'appearance' });
    const render = () => {
      const e = this.eff;
      box.innerHTML = '';
      // font size
      box.append(h('div', { class: 'ap-size' },
        h('button', { class: 'ap-size-btn small', title: 'Decrease Font Size', disabled: s.size <= 0, onclick: () => { this.bumpSize(-1); render(); } }, 'A'),
        h('div', { class: 'ap-size-sep' }),
        h('button', { class: 'ap-size-btn large', title: 'Increase Font Size', disabled: s.size >= T.SIZE_STEPS - 1, onclick: () => { this.bumpSize(1); render(); } }, 'A')));
      // themes
      const grid = h('div', { class: 'ap-themes' });
      for (const type of T.THEME_ORDER) {
        const th = T.resolveTheme(type, s.appearance);
        const fam = T.FAMILIES[s.family] || {};
        const tile = h('button', { class: 'ap-theme' + (s.theme === type && !s.studio ? ' on' : ''), style: { background: th.bg, color: th.text } },
          h('span', { class: 'ap-theme-aa', style: { fontFamily: s.family ? `'iBooks_${s.family.replace(/\s+/g, '_')}', ${fam.system || ''} ${fam.fallback || 'serif'}` : 'inherit', fontWeight: type === 'bold' ? '700' : '400' } }, 'Aa'),
          h('span', { class: 'ap-theme-name' }, th.name));
        // an Apple theme always brings back the stock Books look
        tile.onclick = () => { this.settings.studio = null; this.setSetting('theme', type); render(); };
        grid.append(tile);
      }
      box.append(grid);
      const appear = h('div', { class: 'seg ap-appear' });
      for (const [v, ic, label] of [['light', 'sun', 'Light'], ['auto', 'auto', 'Auto'], ['dark', 'moon', 'Dark']]) {
        appear.append(h('button', { class: s.appearance === v ? 'on' : '', title: label, html: icon(ic) + `<span>${label}</span>`, onclick: () => { this.setSetting('appearance', v); render(); } }));
      }
      box.append(appear);
      // font
      const styleOn = !!(s.studio && STUDIO[s.studio]);
      const famLabel = styleOn ? `Set by ${STUDIO[s.studio].name}` : (T.FAMILIES[s.family] || {}).label || 'Original';
      const fontRow = h('button', { class: 'ap-row ap-font', disabled: styleOn }, h('span', {}, 'Font'), h('span', { class: 'ap-value' }, famLabel, h('span', { html: icon('chevronUpDown') })));
      fontRow.onclick = () => {
        const r = fontRow.getBoundingClientRect();
        const m = menu(r.right - 220, r.bottom + 2, T.FAMILY_ORDER.map(f => ({
          label: T.FAMILIES[f].label, checked: s.family === f, action: () => { this.setSetting('family', f); render(); },
        })));
        m.el.classList.add('font-menu');
        $$('.menu-label', m.el).forEach((l, i) => {
          const f = T.FAMILY_ORDER[i];
          if (f) l.style.fontFamily = T.FAMILIES[f].system ? T.FAMILIES[f].system : `'iBooks_${f.replace(/\s+/g, '_')}', ${T.FAMILIES[f].fallback}`;
        });
      };
      box.append(h('div', { class: 'ap-section' }, fontRow,
        this.switchRow('Bold Text', T.isBold(e, this.theme), v => { this.setOverride('bold', v); })));

      // customize
      const open = s.customize;
      const cust = h('div', { class: 'ap-section ap-customize' + (open ? ' open' : '') });
      const head = h('button', { class: 'ap-row ap-disclose' }, h('span', {}, 'Customize'), h('span', { class: 'ap-chev', html: icon('chevronDown') }));
      head.onclick = () => { s.customize = !s.customize; this.saveSettings(); render(); };
      cust.append(head);
      if (open) {
        const typo = T.typography(e, this.theme);
        cust.append(
          this.sliderRow('Line Spacing', e.lineHeight != null ? e.lineHeight : (typo.lineHeight || 1.4), 1, 2.2, 0.05, v => this.setOverride('lineHeight', v)),
          this.sliderRow('Character Spacing', e.letterSpacing || 0, 0, 0.12, 0.005, v => this.setOverride('letterSpacing', v || null)),
          this.sliderRow('Word Spacing', e.wordSpacing || 0, 0, 0.5, 0.02, v => this.setOverride('wordSpacing', v || null)),
          this.sliderRow('Margins', e.margin != null ? e.margin : 0, -0.1, 0.1, 0.01, v => this.setOverride('margin', v)),
          this.switchRow('Justify Text', !!e.justify, v => this.setOverride('justify', v)),
          this.switchRow('Hyphenation', e.hyphenate !== false, v => this.setOverride('hyphenate', v)),
          h('button', { class: 'ap-reset', onclick: () => { delete s.overrides[this.themeKey]; this.saveSettings(); this.apply(); render(); } }, 'Reset Theme'));
      }
      box.append(cust);

      // view
      const view = h('div', { class: 'ap-section' });
      if (this.kind !== 'pdf') {
        const lay = h('div', { class: 'seg ap-layout' });
        for (const [v, ic, label] of [['single', 'page', 'Single'], ['double', 'twoPages', 'Two'], ['auto', 'auto', 'Auto']]) {
          lay.append(h('button', { class: s.layout === v ? 'on' : '', title: label, html: icon(ic) + `<span>${label}</span>`, disabled: s.scroll, onclick: () => { this.setSetting('layout', v); render(); } }));
        }
        view.append(lay, this.switchRow('Scrolling View', !!s.scroll, v => { this.setSetting('scroll', v); render(); }));
      } else {
        const lay = h('div', { class: 'seg ap-layout' });
        for (const [v, ic, label] of [['single', 'page', 'Single'], ['double', 'twoPages', 'Two'], ['auto', 'auto', 'Auto']]) {
          lay.append(h('button', { class: s.layout === v ? 'on' : '', html: icon(ic) + `<span>${label}</span>`, onclick: () => { this.setSetting('layout', v); render(); } }));
        }
        view.append(lay);
      }
      const turn = h('div', { class: 'ap-turn' }, h('span', {}, 'Page Turn'));
      const tseg = h('div', { class: 'seg' });
      for (const [v, label] of [['slide', 'Slide'], ['curl', 'Curl'], ['fastFade', 'None']]) {
        tseg.append(h('button', { class: s.turn === v ? 'on' : '', disabled: s.scroll && this.kind !== 'pdf', onclick: () => { this.settings.turn = v; this.settings.turnChosen = Date.now(); this.saveSettings(); render(); } }, label));
      }
      turn.append(tseg);
      view.append(turn);
      box.append(view);
    };
    render();
    popover(anchor, box, { className: 'appearance-pop', anchorEl: anchor });
  }
  switchRow(label, on, fn) {
    const input = h('input', { type: 'checkbox' });
    input.checked = on;
    input.onchange = () => fn(input.checked);
    return h('label', { class: 'ap-row' }, h('span', {}, label), h('span', { class: 'switch' }, input, h('span')));
  }
  sliderRow(label, value, min, max, step, fn) {
    const input = h('input', { class: 'slider', type: 'range', min, max, step });
    input.value = value;
    const pct = () => input.style.setProperty('--p', ((input.value - min) / (max - min)) * 100 + '%');
    pct();
    let t;
    input.oninput = () => { pct(); clearTimeout(t); t = setTimeout(() => fn(+input.value), 120); };
    return h('div', { class: 'ap-slider' }, h('div', { class: 'ap-slider-label' }, label), input);
  }
}

// is (x, y) on a glyph? (presses there select text; anywhere else grabs the page)
function overText(doc, x, y, g) {
  if (x < g.side - 4 || x > g.W - g.side + 4 || y < g.top - 4 || y > g.H - g.bottom + 4) return false;
  if (g.columns > 1 && Math.abs(x - g.W / 2) < g.side - 4) return false; // the gutter between pages
  const r = doc.caretRangeFromPoint && doc.caretRangeFromPoint(x, y);
  if (!r || r.startContainer.nodeType !== 3) return false;
  const n = r.startContainer, o = r.startOffset;
  const rg = doc.createRange();
  rg.setStart(n, Math.max(0, o - 1));
  rg.setEnd(n, Math.min(n.nodeValue.length, o + 1));
  for (const rc of rg.getClientRects()) if (x >= rc.left - 4 && x <= rc.right + 4 && y >= rc.top - 1 && y <= rc.bottom + 1) return true;
  return false;
}

// Books selects whole words: grow a selection that starts or ends mid-word
function snapToWords(range) {
  const W = /[\p{L}\p{N}'’]/u;
  let changed = false;
  const s = range.startContainer, e = range.endContainer;
  if (s.nodeType === 3) {
    let o = range.startOffset;
    while (o > 0 && W.test(s.nodeValue[o - 1]) && W.test(s.nodeValue[o] || ' ')) o--;
    if (o !== range.startOffset) { range.setStart(s, o); changed = true; }
  }
  if (e.nodeType === 3) {
    let o = range.endOffset;
    while (o < e.nodeValue.length && W.test(e.nodeValue[o]) && W.test(e.nodeValue[o - 1] || ' ')) o++;
    if (o !== range.endOffset) { range.setEnd(e, o); changed = true; }
  }
  return changed;
}

const reader = new Reader();
window.__reader = reader;
reader.init().catch(e => {
  console.error(e);
  document.body.classList.remove('loading');
  document.body.insertAdjacentHTML('beforeend', `<div class="missing">Couldn’t open this book.<br><small>${esc(e.message)}</small></div>`);
});
