// Studio styles — designer reading themes that live beside (not inside) the Apple Books themes.
// Each one restyles the page completely: palette, type, heading treatment, ornaments, paper texture
// and the reader chrome. Picking an Apple theme in "Aa" switches back to the stock Books look.

const F = (family, file, weight, style = 'normal') =>
  `@font-face{font-family:'${family}';src:url('/ui/fonts/${file}-latin-${weight}-${style}.woff2') format('woff2');font-weight:${weight};font-style:${style};font-display:block}`;

// tileable film grain (feTurbulence), tinted per theme
const grain = (opacity, tone = '0 0 0') =>
  `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 ${tone.split(' ')[0]} 0 0 0 0 ${tone.split(' ')[1]} 0 0 0 0 ${tone.split(' ')[2]} 0 0 0 ${opacity} 0'/></filter><rect width='100%' height='100%' filter='url(#n)'/></svg>`)}")`;

// selectors for "headings" and the root-level body (specific enough to beat the dark-theme flatten rule)
const H12 = ':root body h1, :root body h2';
const H36 = ':root body h3, :root body h4, :root body h5, :root body h6';

export const STUDIO = {
  readitya: {
    name: 'Readitya',
    tagline: 'a personal mixtape of words & things',
    // follows Light / Auto / Dark like the site's own theme switch
    variants: {
      dark: { bg: '#121011', text: '#EDE3D2', soft: '#C6B9A6', faint: '#8F8475', link: '#E8A33A', head: '#F3E9D9', curl: '#1C1918', dark: true },
      light: { bg: '#F1EDE5', text: '#17130F', soft: '#4D453B', faint: '#7A6F61', link: '#D9532E', head: '#17130F', curl: '#E8E2D6', dark: false },
    },
    lh: 1.6,
    fonts: [F('RD Newsreader', 'newsreader', 400), F('RD Newsreader', 'newsreader', 400, 'italic'), F('RD Newsreader', 'newsreader', 700), F('RD Newsreader', 'newsreader', 700, 'italic'),
      F('RD Archivo', 'archivo', 900), F('RD Archivo', 'archivo', 700), F('RD Space Mono', 'space-mono', 400), F('RD Space Mono', 'space-mono', 700)],
    body: "'RD Newsreader', Georgia, serif",
    head: "'RD Archivo', 'Arial Black', sans-serif",
    ui: "'RD Space Mono', Consolas, monospace",
    uiCase: 'uppercase',
    texture: v => `${grain(v.dark ? 0.09 : 0.13, v.dark ? '1 .92 .8' : '.18 .12 .06')}`,
    css: v => `
${H12}{font-family:'RD Archivo','Arial Black',sans-serif!important;font-weight:900!important;letter-spacing:-.025em!important;text-transform:uppercase;line-height:1.08!important;color:${v.head}!important;text-align:left!important}
${H12}{padding-top:.75em!important;background:linear-gradient(90deg,#E8A33A 0 33.3%,#D9532E 33.3% 66.6%,#8A3324 66.6%) top left/3.2em 5px no-repeat!important}
${H36}{font-family:'RD Space Mono',monospace!important;font-weight:700!important;text-transform:uppercase;letter-spacing:.08em!important;font-size:.82em!important;color:${v.dark ? '#FFB347' : '#D9532E'}!important}
:root body blockquote{border-left:3px solid #E8A33A!important;padding-left:1em!important;margin-left:0!important;font-style:italic;color:${v.soft}!important}
:root body hr{border:0!important;height:5px!important;width:4.5em!important;margin:1.6em auto!important;background:linear-gradient(90deg,#E8A33A 0 33.3%,#D9532E 33.3% 66.6%,#8A3324 66.6%)!important}
:root body em, :root body i{color:${v.soft}!important}
::selection{background:${v.dark ? 'rgba(232,163,58,.35)' : 'rgba(232,163,58,.45)'}}`,
    swatch: ['#E8A33A', '#D9532E', '#1F8A85'],
  },

  okinawa: {
    name: 'Okinawa Blue',
    tagline: 'coral sand, ryukyu indigo, turquoise shallows',
    variants: { light: { bg: '#EEF5F4', text: '#11293B', soft: '#3B5A6E', faint: '#7E97A4', link: '#0E8FA6', head: '#1B4F8A', curl: '#E1ECEB', dark: false } },
    lh: 1.62,
    fonts: [F('OK Literata', 'literata', 400), F('OK Literata', 'literata', 400, 'italic'), F('OK Literata', 'literata', 700),
      F('OK Zen Kaku', 'zen-kaku-gothic-new', 400), F('OK Zen Kaku', 'zen-kaku-gothic-new', 700)],
    body: "'OK Literata', Georgia, serif",
    head: "'OK Zen Kaku', 'Yu Gothic', 'Segoe UI', sans-serif",
    ui: "'OK Zen Kaku', 'Segoe UI', sans-serif",
    uiCase: 'none',
    texture: () => `${grain(0.05, '.05 .2 .3')}, linear-gradient(180deg, rgba(255,255,255,.55), rgba(14,143,166,.06))`,
    css: v => `
${H12}{font-family:'OK Zen Kaku','Yu Gothic',sans-serif!important;font-weight:700!important;letter-spacing:.06em!important;color:${v.head}!important;text-align:left!important;line-height:1.3!important}
${H12}{padding-bottom:.55em!important;background:radial-gradient(circle at 6px -2px, transparent 5px, #0E8FA6 5.5px 7px, transparent 7.5px) bottom left/12px 8px repeat-x!important;background-size:12px 8px!important;background-position:0 100%!important;background-repeat:repeat-x!important;-webkit-box-decoration-break:clone}
${H36}{font-family:'OK Zen Kaku',sans-serif!important;color:#F07C5C!important;letter-spacing:.05em!important}
:root body blockquote{border-left:3px solid #F07C5C!important;padding-left:1em!important;margin-left:0!important;color:${v.soft}!important}
:root body hr{border:0!important;height:8px!important;margin:1.6em auto!important;width:6em!important;background:radial-gradient(circle at 6px -2px, transparent 5px, #0E8FA6 5.5px 7px, transparent 7.5px) 0 0/12px 8px repeat-x!important}
::selection{background:rgba(14,143,166,.22)}`,
    swatch: ['#1B4F8A', '#0E8FA6', '#F07C5C'],
  },

  zenolive: {
    name: 'Zen Olive',
    tagline: 'washi paper, olive ink, unhurried margins',
    variants: { light: { bg: '#ECE9DB', text: '#2C2F23', soft: '#55593F', faint: '#8B8C74', link: '#6B7B3A', head: '#4F5B2A', curl: '#E2DECB', dark: false } },
    lh: 1.68,
    scale: 1.07, // EB Garamond sets small for its size
    fonts: [F('ZO Cormorant', 'cormorant-garamond', 500), F('ZO Cormorant', 'cormorant-garamond', 500, 'italic'), F('ZO Cormorant', 'cormorant-garamond', 600),
      F('ZO Garamond', 'eb-garamond', 400), F('ZO Garamond', 'eb-garamond', 400, 'italic'), F('ZO Garamond', 'eb-garamond', 700)],
    body: "'ZO Garamond', Garamond, Georgia, serif",
    head: "'ZO Cormorant', Garamond, serif",
    ui: "'ZO Cormorant', Garamond, serif",
    uiCase: 'none',
    texture: () => `${grain(0.09, '.25 .24 .12')}, radial-gradient(ellipse at 30% 20%, rgba(255,255,240,.5), transparent 60%)`,
    css: v => `
${H12}{font-family:'ZO Cormorant',Garamond,serif!important;font-weight:600!important;font-style:normal;letter-spacing:.04em!important;color:${v.head}!important;text-align:center!important;line-height:1.2!important}
${H12}{padding-bottom:.7em!important;background:radial-gradient(circle, #6B7B3A 0 3px, transparent 3.5px) bottom center/8px 8px no-repeat!important}
${H36}{font-family:'ZO Cormorant',serif!important;font-style:italic!important;font-weight:500!important;color:${v.head}!important;font-size:1.15em!important}
:root body blockquote{margin:1.2em 1.5em!important;font-style:italic;color:${v.soft}!important;border:0!important}
:root body hr{border:0!important;height:1em!important;margin:1.4em auto!important;background:radial-gradient(circle, #6B7B3A 0 2.5px, transparent 3px) center/1.4em 1em repeat-x!important;width:4.2em!important}
::selection{background:rgba(107,123,58,.25)}`,
    swatch: ['#4F5B2A', '#8A9A5B', '#ECE9DB'],
  },

  gallery: {
    name: 'Korean Minimal Gallery',
    tagline: 'white walls, celadon accents, quiet space',
    variants: { light: { bg: '#FAFAF7', text: '#222222', soft: '#5C5C58', faint: '#A3A39E', link: '#5F8C7F', head: '#111111', curl: '#F0F0EC', dark: false } },
    lh: 1.78,
    fonts: [F('KG Gowun', 'gowun-batang', 400), F('KG Gowun', 'gowun-batang', 700), F('KG Plex', 'ibm-plex-sans-kr', 300), F('KG Plex', 'ibm-plex-sans-kr', 500)],
    body: "'KG Gowun', 'Batang', Georgia, serif",
    head: "'KG Plex', 'Malgun Gothic', 'Segoe UI', sans-serif",
    ui: "'KG Plex', 'Malgun Gothic', 'Segoe UI', sans-serif",
    uiCase: 'uppercase',
    texture: () => `linear-gradient(180deg, rgba(0,0,0,.012), transparent 18%, transparent 82%, rgba(0,0,0,.018))`,
    css: v => `
:root body{letter-spacing:.01em}
${H12}{font-family:'KG Plex','Malgun Gothic',sans-serif!important;font-weight:300!important;text-transform:uppercase;letter-spacing:.32em!important;font-size:1.05em!important;color:${v.head}!important;text-align:left!important;line-height:1.6!important;margin-bottom:2.2em!important}
${H12}{padding-top:2.2em!important;background:linear-gradient(#5F8C7F,#5F8C7F) top left/1.6em 1px no-repeat!important}
${H36}{font-family:'KG Plex',sans-serif!important;font-weight:500!important;letter-spacing:.18em!important;text-transform:uppercase;font-size:.78em!important;color:${v.soft}!important}
:root body blockquote{border-left:1px solid #5F8C7F!important;padding-left:1.4em!important;margin-left:0!important;color:${v.soft}!important}
:root body hr{border:0!important;height:1px!important;width:1.6em!important;background:#5F8C7F!important;margin:2.4em 0!important}
::selection{background:rgba(95,140,127,.2)}`,
    swatch: ['#111111', '#5F8C7F', '#FAFAF7'],
  },

  cyberpunk: {
    name: 'Cyberpunk Green',
    tagline: 'phosphor terminal, neon after midnight',
    variants: { dark: { bg: '#050A07', text: '#A9F0C2', soft: '#6FC596', faint: '#3F7A58', link: '#FF3EC8', head: '#39FF88', curl: '#0B1710', dark: true } },
    lh: 1.62,
    fonts: [F('CP Plex Mono', 'ibm-plex-mono', 400), F('CP Plex Mono', 'ibm-plex-mono', 400, 'italic'), F('CP Plex Mono', 'ibm-plex-mono', 600), F('CP Share Tech', 'share-tech-mono', 400)],
    body: "'CP Plex Mono', Consolas, monospace",
    head: "'CP Share Tech', Consolas, monospace",
    ui: "'CP Share Tech', Consolas, monospace",
    uiCase: 'uppercase',
    scale: 0.92,
    texture: () => `repeating-linear-gradient(180deg, rgba(57,255,136,.035) 0 1px, transparent 1px 3px), radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,.55))`,
    css: v => `
${H12}{font-family:'CP Share Tech',monospace!important;font-weight:400!important;text-transform:uppercase;letter-spacing:.12em!important;color:${v.head}!important;text-shadow:0 0 6px rgba(57,255,136,.75),0 0 18px rgba(57,255,136,.35)!important;text-align:left!important}
${H12}::before{content:'> ';color:#FF3EC8!important;text-shadow:0 0 8px rgba(255,62,200,.7)!important}
${H36}{font-family:'CP Share Tech',monospace!important;color:#FF3EC8!important;letter-spacing:.1em!important;text-transform:uppercase;text-shadow:0 0 6px rgba(255,62,200,.5)!important}
:root body blockquote{border-left:2px solid #39FF88!important;padding-left:1em!important;margin-left:0!important;box-shadow:-6px 0 12px -8px #39FF88}
:root body hr{border:0!important;height:1px!important;background:linear-gradient(90deg,transparent,#39FF88,transparent)!important;box-shadow:0 0 8px #39FF88;margin:1.6em 0!important}
:root body a, :root body a *{text-shadow:0 0 6px rgba(255,62,200,.55)}
::selection{background:rgba(57,255,136,.3);color:#EFFFF5}`,
    swatch: ['#39FF88', '#FF3EC8', '#050A07'],
  },

  persona: {
    name: 'Neo Persona',
    tagline: 'take your time — rebel red, ink black',
    variants: { dark: { bg: '#0D0D0D', text: '#F2F2F2', soft: '#BDBDBD', faint: '#7A7A7A', link: '#FF2D46', head: '#FFFFFF', curl: '#1A0B0D', dark: true } },
    lh: 1.55,
    fonts: [F('NP Barlow', 'barlow', 400), F('NP Barlow', 'barlow', 400, 'italic'), F('NP Barlow', 'barlow', 600), F('NP Anton', 'anton', 400)],
    body: "'NP Barlow', 'Segoe UI', sans-serif",
    head: "'NP Anton', Impact, 'Arial Black', sans-serif",
    ui: "'NP Anton', Impact, sans-serif",
    uiCase: 'uppercase',
    texture: () => `radial-gradient(rgba(229,0,27,.11) 1px, transparent 1.6px) 0 0/7px 7px, linear-gradient(115deg, transparent 72%, rgba(229,0,27,.10) 72% 74%, transparent 74%)`,
    css: v => `
${H12}{font-family:'NP Anton',Impact,sans-serif!important;font-weight:400!important;text-transform:uppercase;letter-spacing:.02em!important;color:#FFFFFF!important;background-color:#E5001B!important;display:table!important;padding:.08em .45em .12em!important;transform:rotate(-2deg) skewX(-8deg);box-shadow:5px 5px 0 #FFFFFF, 8px 8px 0 #000000!important;margin:.4em 0 1.1em .2em!important;text-align:left!important;line-height:1.15!important}
${H36}{font-family:'NP Anton',Impact,sans-serif!important;text-transform:uppercase;letter-spacing:.04em!important;color:#FF2D46!important;font-weight:400!important}
:root body blockquote{border-left:6px solid #E5001B!important;padding:.2em 0 .2em 1em!important;margin-left:0!important;font-style:italic}
:root body hr{border:0!important;height:6px!important;background:#E5001B!important;transform:skewX(-30deg);width:5em!important;margin:1.6em auto!important}
:root body strong, :root body b{color:#FF2D46!important}
::selection{background:#E5001B;color:#fff}`,
    swatch: ['#E5001B', '#0D0D0D', '#FFFFFF'],
  },

  tokyo: {
    name: 'Tokyo Vermillion',
    tagline: 'torii red, sumi ink on kinari paper',
    variants: { light: { bg: '#F5EEE2', text: '#1D1A17', soft: '#4E4741', faint: '#9A8F84', link: '#D23A21', head: '#C8321B', curl: '#EAE1D2', dark: false } },
    lh: 1.72,
    fonts: [F('TV Shippori', 'shippori-mincho', 400), F('TV Shippori', 'shippori-mincho', 700)],
    body: "'TV Shippori', 'Yu Mincho', 'MS Mincho', Georgia, serif",
    head: "'TV Shippori', 'Yu Mincho', serif",
    ui: "'TV Shippori', 'Yu Mincho', serif",
    uiCase: 'none',
    texture: () => `${grain(0.08, '.3 .2 .1')}, radial-gradient(circle at 100% 0, rgba(210,58,33,.07) 0 14%, transparent 14.2%)`,
    css: v => `
${H12}{font-family:'TV Shippori','Yu Mincho',serif!important;font-weight:700!important;letter-spacing:.08em!important;color:${v.head}!important;text-align:left!important;line-height:1.35!important}
${H12}{padding-left:1.15em!important;background:linear-gradient(#C8321B,#C8321B) left .3em/.6em .6em no-repeat!important}
${H36}{font-family:'TV Shippori',serif!important;font-weight:700!important;color:${v.text}!important;letter-spacing:.06em!important;border-bottom:1px solid #C8321B;display:inline-block}
:root body blockquote{border-left:2px solid #C8321B!important;padding-left:1em!important;margin-left:0!important;color:${v.soft}!important}
:root body hr{border:0!important;height:.6em!important;width:.6em!important;background:#C8321B!important;margin:1.8em auto!important;transform:rotate(45deg)}
::selection{background:rgba(210,58,33,.2)}`,
    swatch: ['#C8321B', '#1D1A17', '#F5EEE2'],
  },
};
export const STUDIO_ORDER = ['readitya', 'okinawa', 'zenolive', 'gallery', 'cyberpunk', 'persona', 'tokyo'];

// Resolve a studio style to the same shape as an Apple theme (themes.resolveTheme), plus `studio`.
export function resolveStudio(id, appearance) {
  const st = STUDIO[id];
  if (!st) return null;
  let key = st.variants.light && st.variants.dark
    ? (appearance === 'auto' ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : appearance)
    : (st.variants.dark ? 'dark' : 'light');
  if (!st.variants[key]) key = Object.keys(st.variants)[0];
  const v = st.variants[key];
  return {
    type: 'studio-' + id, variant: key, bg: v.bg, text: v.text, link: v.link, dark: v.dark, lh: st.lh, name: st.name,
    studio: { id, ...st, v, texture: st.texture(v), extra: st.fonts.join('\n') + st.css(v) },
  };
}
