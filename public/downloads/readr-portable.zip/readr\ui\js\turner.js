// Page turning (BEPageViewController + BookPageCurl equivalent).
// Styles (BKPageTurnStyle): 'slide' | 'curl' | 'fastFade'.
//  - slide: adjacent pages move together, UIScrollView-paging feel, velocity decides on release
//  - fastFade: cross-dissolve, 0.2 s
//  - curl: front page folds along the perpendicular bisector of corner→pointer. The folded part is
//    clipped away (revealing the next page underneath), and its mirror image — the back of the
//    sheet — is drawn as a flap. Shading follows BEPageCurlConfig's front/back0/back1/shadow recipe.

const ease = {
  outCubic: t => 1 - Math.pow(1 - t, 3),
  inOutCubic: t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  outQuart: t => 1 - Math.pow(1 - t, 4),
};

export class Turner {
  constructor(stage) {
    this.stage = stage;
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'curl-canvas';
    this.flap = document.createElement('div');
    this.flap.className = 'curl-flap';
    stage.append(this.flap, this.canvas);
    this.busy = false;
    this.drag = null;
    this.colors = { back0: '#f4f4f4', back1: '#e9e9e9', dark: false };
    this.duration = { slide: 340, fade: 200, curl: 620 };
    this.reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  setColors(c) { this.colors = c; }

  get W() { return this.stage.clientWidth; }
  get H() { return this.stage.clientHeight; }

  // ---------- public API ----------
  // from/to: {el} views. dir: +1 next, -1 previous. opts.twoUp; opts.flapView = a second view showing
  // the same spread as the page underneath (to when turning forward, from when turning back)
  async turn(style, dir, from, to, opts = {}) {
    if (this.reduceMotion && style === 'curl') style = 'fastFade';
    this.busy = true;
    const k = opts.fast ? 0.5 : 1; // held-key page flipping runs at double speed
    try {
      if (style === 'slide') await this._slide(dir, from, to, 0, 1, this.duration.slide * k, ease.outCubic);
      else if (style === 'curl') await this._curlAnimate(dir, from, to, opts, dir > 0 ? 0 : 1, dir > 0 ? 1 : 0, this.duration.curl * k, ease.inOutCubic);
      else await this._fade(from, to, k);
    } finally {
      this._reset(from, to, opts);
      this.busy = false;
    }
  }

  // Interactive turns (trackpad swipe / touch / edge drag)
  beginDrag(style, dir, from, to, opts = {}) {
    if (this.reduceMotion && style === 'curl') style = 'slide';
    if (style === 'fastFade') style = 'slide';
    this.busy = true;
    this.drag = { style, dir, from, to, opts, progress: 0, point: null };
    if (style === 'slide') this._slideFrame(dir, from, to, 0);
    else this._curlSetup(dir, from, to, opts);
    this.updateDrag(0);
  }
  // progress 0..1 (fraction of the turn), or point {x,y} for curl finger-follow
  updateDrag(progress, point) {
    const d = this.drag;
    if (!d) return;
    d.progress = Math.max(0, Math.min(1, progress));
    d.point = point || null;
    // pointer/wheel events arrive faster than (and out of step with) the display: render the latest
    // state once per frame
    if (this._dragRaf) return;
    this._dragRaf = requestAnimationFrame(() => { this._dragRaf = 0; this._renderDrag(); });
  }
  _renderDrag() {
    const d = this.drag;
    if (!d) return;
    if (d.style === 'slide') this._slideFrame(d.dir, d.from, d.to, d.progress);
    else this._curlFrame(d, d.dir > 0 ? d.progress : 1 - d.progress, d.point);
  }
  async endDrag(commit) {
    const d = this.drag;
    if (!d) return false;
    if (this._dragRaf) { cancelAnimationFrame(this._dragRaf); this._dragRaf = 0; this._renderDrag(); }
    this.drag = null;
    try {
      if (d.style === 'slide') {
        const dur = 260 * (commit ? 1 - d.progress : d.progress) + 90;
        await this._slide(d.dir, d.from, d.to, d.progress, commit ? 1 : 0, dur, ease.outCubic);
      } else {
        const t0 = d.dir > 0 ? d.progress : 1 - d.progress;
        const t1 = commit ? (d.dir > 0 ? 1 : 0) : (d.dir > 0 ? 0 : 1);
        const startPoint = d.point ? this._clampPoint(d.point, d.opts) : null;
        await this._curlAnimate(d.dir, d.from, d.to, d.opts, t0, t1, 300 + 200 * Math.abs(t1 - t0), ease.outCubic, startPoint, true);
      }
    } finally {
      this._reset(d.from, d.to, d.opts, !commit);
      this.busy = false;
    }
    return commit;
  }

  // small resistance bounce at the first/last page
  async bounce(view, dir) {
    const el = view.el;
    const W = this.W;
    await this._tween(320, t => {
      const k = Math.sin(Math.PI * t) * (1 - t);
      el.style.transform = `translateX(${-dir * k * W * 0.06}px)`;
    });
    el.style.transform = '';
  }

  // ---------- slide ----------
  _slideFrame(dir, from, to, p) {
    const W = this.W;
    show(to.el, 2);
    show(from.el, 3);
    from.el.style.transform = `translate3d(${-dir * p * W}px,0,0)`;
    to.el.style.transform = `translate3d(${dir * (1 - p) * W}px,0,0)`;
    from.el.style.boxShadow = to.el.style.boxShadow = '';
  }
  _slide(dir, from, to, p0, p1, dur, fn) {
    return this._tween(dur, t => this._slideFrame(dir, from, to, p0 + (p1 - p0) * fn(t)));
  }

  // ---------- fade ----------
  _fade(from, to, k = 1) {
    show(to.el, 2);
    show(from.el, 3);
    return this._tween(this.duration.fade * k, t => { from.el.style.opacity = String(1 - t); });
  }

  // ---------- curl ----------
  _sheet(opts) {
    const W = this.W, H = this.H;
    const x0 = opts.twoUp ? W / 2 : 0; // spine
    return { x0, x1: W, w: W - x0, H, W };
  }

  _curlSetup(dir, from, to, opts) {
    // forward: front=from, under=to. backward: front=to (unfolds), under=from.
    const front = dir > 0 ? from : to, under = dir > 0 ? to : from;
    show(under.el, 2);
    show(front.el, 3);
    const W = this.W, H = this.H;
    // shading is all soft gradients: a half-resolution canvas looks the same and is 4x+ cheaper
    const cw = Math.ceil(W * CANVAS_SCALE), ch = Math.ceil(H * CANVAS_SCALE);
    if (this.canvas.width !== cw || this.canvas.height !== ch) { this.canvas.width = cw; this.canvas.height = ch; }
    this.canvas.style.display = 'block';
    this.D = Math.ceil(Math.hypot(W, H) * 2);
    // every clip is a rotated overflow:hidden box + a counter-transformed child, so a frame only
    // changes transforms (composited on the GPU, no repaint of the page content)
    prepClipper(front, W, H, this.D);
    this.flap.innerHTML = '';
    const sheet = this._sheet(opts);
    if (opts.twoUp && opts.flapView) {
      // the back of the right-hand sheet is the next spread's left page
      // (never re-parent an iframe: moving it in the DOM reloads it — just stack it above the front)
      const fv = opts.flapView;
      show(fv.el, 4);
      prepClipper(fv, sheet.x0, H, this.D);
      opts._flapView = fv;
      this.flap.style.display = 'none';
    } else {
      const page = document.createElement('div');
      page.className = 'flap-page';
      Object.assign(page.style, { width: sheet.w + 'px', height: H + 'px', background: this.colors.back1 });
      this.flap.appendChild(page);
      Object.assign(this.flap.style, { display: 'block', width: this.D + 'px', height: 2 * this.D + 'px' });
      this._flapPage = page;
    }
    this._curlCur = { front, under };
  }

  _pathPoint(t, sheet, corner) {
    // tap/keyboard path: the corner lifts and sweeps over the spine
    const { x1, w, H } = sheet;
    const cy = corner === 'top' ? 0 : H;
    const lift = Math.sin(Math.PI * t) * H * 0.22 * (corner === 'top' ? -1 : 1);
    return { x: x1 - t * 2 * w, y: cy - lift };
  }

  _clampPoint(p, opts) {
    const s = this._sheet(opts);
    const corner = p.corner || (p.y < s.H / 2 ? 'top' : 'bottom');
    const cy = corner === 'top' ? 0 : s.H;
    let x = Math.min(p.x, s.x1 - 0.5), y = Math.max(-s.H * 0.2, Math.min(s.H * 1.2, p.y));
    // the sheet cannot tear away from the spine
    const sx = s.x0, sy = cy;
    let dx = x - sx, dy = y - sy, dist = Math.hypot(dx, dy);
    if (dist > s.w) { x = sx + dx * s.w / dist; y = sy + dy * s.w / dist; }
    const oy = s.H - cy, diag = Math.hypot(s.w, s.H);
    dx = x - sx; dy = y - oy; dist = Math.hypot(dx, dy);
    if (dist > diag) { x = sx + dx * diag / dist; y = oy + dy * diag / dist; }
    return { x, y, corner };
  }

  async _curlAnimate(dir, from, to, opts, t0, t1, dur, fn, startPoint, fromDrag) {
    if (!fromDrag || !this._curlCur) this._curlSetup(dir, from, to, opts);
    const sheet = this._sheet(opts);
    const d = { dir, from, to, opts };
    if (startPoint) {
      // continue from the finger position toward the end state
      const corner = startPoint.corner;
      const end = this._pathPoint(t1, sheet, corner);
      await this._tween(dur, t => {
        const k = fn(t);
        this._curlFrame(d, null, { x: startPoint.x + (end.x - startPoint.x) * k, y: startPoint.y + (end.y - startPoint.y) * k, corner });
      });
      return;
    }
    await this._tween(dur, t => this._curlFrame(d, t0 + (t1 - t0) * fn(t)));
  }

  // t: 0 = flat, 1 = fully turned (for the front sheet)
  _curlFrame(d, t, point) {
    const { front } = this._curlCur || {};
    if (!front) return;
    const sheet = this._sheet(d.opts);
    let P;
    if (point) P = this._clampPoint(point, d.opts);
    else P = { ...this._pathPoint(t, sheet, 'bottom'), corner: 'bottom' };
    const C = { x: sheet.x1, y: P.corner === 'top' ? 0 : sheet.H };
    const geo = foldGeometry(sheet, C, P);
    if (!geo) {
      // flat: nothing folded
      setClip(front, IDENT, IDENT);
      if (this._flapPage) this.flap.style.transform = 'scale(0)';
      if (d.opts._flapView) d.opts._flapView.el.style.transform = 'scale(0)';
      this._paint(null);
      return;
    }
    // the unfolded side of the fold line: local x axis along n, left edge on the fold
    const Tc = halfPlane(geo, this.D);
    const Ti = invert(Tc);
    setClip(front, Tc, Ti);
    const Rf = reflection(geo);
    if (d.opts._flapView) {
      // flap content: next spread's left page, mirrored across the spine then reflected across the fold
      setClip(d.opts._flapView, Tc, mul(Ti, mul(Rf, mirrorX(sheet.x0))));
    } else if (this._flapPage) {
      // solid sheet back: the page rect reflected across the fold, clipped to the unfolded side
      this.flap.style.transform = css(Tc);
      this._flapPage.style.transform = css(mul(Ti, mul(Rf, translate(sheet.x0, 0))));
    }
    this._paint(geo);
  }

  _paint(geo) {
    const ctx = this.canvas.getContext('2d');
    ctx.setTransform(CANVAS_SCALE, 0, 0, CANVAS_SCALE, 0, 0);
    ctx.clearRect(0, 0, this.W, this.H);
    if (!geo) return;
    const { M, n, len } = geo; // fold midpoint, unit normal pointing to the unfolded side, |C-P|
    const dark = this.colors.dark;
    const reach = Math.min(len * 0.5, 90);

    // 1) shadow cast on the page underneath (revealed region), strongest at the fold
    let g = ctx.createLinearGradient(M.x, M.y, M.x - n.x * reach * 1.2, M.y - n.y * reach * 1.2);
    g.addColorStop(0, `rgba(0,0,0,${dark ? 0.55 : 0.32})`);
    g.addColorStop(0.35, `rgba(0,0,0,${dark ? 0.25 : 0.12})`);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; pathPoly(ctx, geo.folded); ctx.fill();

    // 2) soft drop shadow of the flap onto the front page: the flap itself is clipped away so only
    //    the blurred shadow outside it lands (blur is in canvas pixels, hence the scale)
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 0, this.W, this.H); pathPoly(ctx, geo.flap, true); ctx.clip('evenodd');
    ctx.shadowColor = `rgba(0,0,0,${dark ? 0.6 : 0.3})`;
    ctx.shadowBlur = 22 * CANVAS_SCALE;
    pathPoly(ctx, geo.flap); ctx.fillStyle = '#000'; ctx.fill();
    ctx.restore();

    // 3) bend shading on the front page just before the fold (inputFrontColor)
    g = ctx.createLinearGradient(M.x, M.y, M.x + n.x * reach * 0.6, M.y + n.y * reach * 0.6);
    g.addColorStop(0, `rgba(0,0,0,${dark ? 0.25 : 0.10})`);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; pathPoly(ctx, geo.visible); ctx.fill();

    // 4) curvature on the flap: dark crease at the fold, highlight, then fading (back0 → back1)
    const far = Math.max(40, len * 0.5);
    g = ctx.createLinearGradient(M.x, M.y, M.x + n.x * far, M.y + n.y * far);
    g.addColorStop(0, `rgba(0,0,0,${dark ? 0.35 : 0.16})`);
    g.addColorStop(0.18, `rgba(255,255,255,${dark ? 0.04 : 0.22})`);
    g.addColorStop(0.55, `rgba(255,255,255,${dark ? 0.02 : 0.08})`);
    g.addColorStop(1, `rgba(0,0,0,${dark ? 0.12 : 0.05})`);
    ctx.fillStyle = g; pathPoly(ctx, geo.flap); ctx.fill();

    // 5) soft outline on the flap: rotated clip edges aren't anti-aliased by the compositor, a faint
    //    stroke (blurred by the half-resolution canvas) hides the stair-stepping along fold and edges
    ctx.lineJoin = 'round';
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = `rgba(0,0,0,${dark ? 0.45 : 0.16})`;
    pathPoly(ctx, geo.flap); ctx.stroke();
  }

  // When the turn completed, the outgoing page is hidden *before* its clip is removed; otherwise it
  // flashes back for one frame at the very end of the turn.
  _reset(from, to, opts, cancelled) {
    const gone = cancelled ? to : from;
    gone.el.style.visibility = 'hidden';
    gone.el.style.zIndex = '0';
    for (const v of [from, to]) {
      v.el.style.transform = '';
      v.el.style.opacity = '';
      v.el.style.boxShadow = '';
      clearClipper(v);
    }
    this.canvas.style.display = 'none';
    this.flap.style.display = 'none';
    this.flap.style.transform = '';
    this.flap.innerHTML = '';
    this._flapPage = null;
    if (opts && opts._flapView) {
      const fv = opts._flapView;
      fv.el.style.visibility = 'hidden';
      fv.el.style.zIndex = '';
      clearClipper(fv);
      opts._flapView = null;
    }
    this._curlCur = null;
  }

  _tween(dur, frame) {
    return new Promise(resolve => {
      const t0 = performance.now();
      const step = now => {
        const t = Math.min(1, (now - t0) / dur);
        frame(t);
        if (t < 1) requestAnimationFrame(step); else resolve();
      };
      requestAnimationFrame(step);
    });
  }
}

const CANVAS_SCALE = 0.5;
const IDENT = { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 };
const css = m => `matrix(${m.a},${m.b},${m.c},${m.d},${m.e},${m.f})`;
// A∘B (apply B first)
function mul(A, B) {
  return {
    a: A.a * B.a + A.c * B.b, b: A.b * B.a + A.d * B.b,
    c: A.a * B.c + A.c * B.d, d: A.b * B.c + A.d * B.d,
    e: A.a * B.e + A.c * B.f + A.e, f: A.b * B.e + A.d * B.f + A.f,
  };
}
function invert(m) {
  const det = m.a * m.d - m.b * m.c;
  const a = m.d / det, b = -m.b / det, c = -m.c / det, d = m.a / det;
  return { a, b, c, d, e: -(a * m.e + c * m.f), f: -(b * m.e + d * m.f) };
}
const translate = (x, y) => ({ a: 1, b: 0, c: 0, d: 1, e: x, f: y });
const mirrorX = x0 => ({ a: -1, b: 0, c: 0, d: 1, e: 2 * x0, f: 0 });
// a [0,D]x[0,2D] box whose left edge runs along the fold, extending over the unfolded side
function halfPlane(geo, D) {
  const { M, n } = geo, c = n.x, s = n.y;
  return { a: c, b: s, c: -s, d: c, e: M.x + s * D, f: M.y - c * D };
}
// Rf(p) = p - 2((p-M)·n)n
function reflection(geo) {
  const { M, n } = geo;
  const r11 = 1 - 2 * n.x * n.x, r12 = -2 * n.x * n.y, r22 = 1 - 2 * n.y * n.y;
  const md = M.x * n.x + M.y * n.y;
  return { a: r11, b: r12, c: r12, d: r22, e: 2 * md * n.x, f: 2 * md * n.y };
}
function prepClipper(view, innerW, H, D) {
  Object.assign(view.el.style, { width: D + 'px', height: 2 * D + 'px', background: 'transparent' });
  Object.assign(view.inner.style, { width: innerW + 'px', height: H + 'px', background: 'var(--page-bg)' });
}
function setClip(view, Tc, Ti) {
  view.el.style.transform = css(Tc);
  view.inner.style.transform = css(Ti);
}
function clearClipper(view) {
  for (const k of ['width', 'height', 'background', 'transform']) { view.el.style[k] = ''; view.inner.style[k] = ''; }
}

function show(el, z) {
  el.style.visibility = 'visible';
  el.style.zIndex = String(z);
}

// ---------- geometry ----------
function foldGeometry(sheet, C, P) {
  const dx = P.x - C.x, dy = P.y - C.y;
  const len = Math.hypot(dx, dy);
  if (len < 0.5) return null;
  const n = { x: dx / len, y: dy / len }; // points from C toward P (unfolded side)
  const M = { x: (P.x + C.x) / 2, y: (P.y + C.y) / 2 };
  const f = p => (p.x - M.x) * n.x + (p.y - M.y) * n.y;
  const rect = [{ x: sheet.x0, y: 0 }, { x: sheet.x1, y: 0 }, { x: sheet.x1, y: sheet.H }, { x: sheet.x0, y: sheet.H }];
  const visible = clipHalf(rect, f, true);
  const folded = clipHalf(rect, f, false);
  const flap = folded.map(p => { const k = 2 * f(p); return { x: p.x - k * n.x, y: p.y - k * n.y }; });
  return { M, n, len, visible, folded, flap };
}

// Sutherland–Hodgman against the half-plane f>=0 (keep=true) or f<0
function clipHalf(polyPts, f, keep) {
  const out = [];
  const inside = p => (keep ? f(p) >= 0 : f(p) < 0);
  for (let i = 0; i < polyPts.length; i++) {
    const a = polyPts[i], b = polyPts[(i + 1) % polyPts.length];
    const ia = inside(a), ib = inside(b);
    if (ia) out.push(a);
    if (ia !== ib) {
      const fa = f(a), fb = f(b), t = fa / (fa - fb);
      out.push({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
    }
  }
  return out;
}

function pathPoly(ctx, pts, noBegin) {
  if (!noBegin) ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.closePath();
}
