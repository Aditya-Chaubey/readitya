// EPUB package parsing (BKEpubBookParser equivalent):
// container.xml -> OPF -> metadata, manifest, spine (ordinals), nav/NCX TOC tree, landmarks,
// page-list, cover, page-progression-direction, Apple display options.

const NS = {
  opf: 'http://www.idpf.org/2007/opf',
  dc: 'http://purl.org/dc/elements/1.1/',
  xhtml: 'http://www.w3.org/1999/xhtml',
  epub: 'http://www.idpf.org/2007/ops',
  ncx: 'http://www.daisy.org/z3986/2005/ncx/',
};

export function resolveURL(href, base) {
  try { return new URL(href, base).href; } catch { return href; }
}
export const stripHash = u => u.split('#')[0];

async function fetchXML(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error('Missing ' + url);
  const text = await r.text();
  const doc = new DOMParser().parseFromString(text, 'application/xml');
  if (doc.querySelector('parsererror')) {
    // tolerate sloppy XML (entities etc.)
    return new DOMParser().parseFromString(text, 'text/html');
  }
  return doc;
}

const byTag = (root, ns, tag) => [...root.getElementsByTagNameNS(ns, tag), ...(ns ? [] : [])];
function first(root, tag) {
  // namespace-agnostic first element by local name
  const all = root.getElementsByTagName('*');
  for (const el of all) if (el.localName === tag) return el;
  return null;
}
function all(root, tag) {
  return [...root.getElementsByTagName('*')].filter(el => el.localName === tag);
}
const text = el => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');

export async function parseEpub(baseURL /* .../lib/<id>/content/ */) {
  baseURL = new URL(baseURL, location.href).href;
  const container = await fetchXML(resolveURL('META-INF/container.xml', baseURL));
  const rootfile = first(container, 'rootfile');
  const opfURL = resolveURL(rootfile.getAttribute('full-path'), baseURL);
  const opf = await fetchXML(opfURL);
  const pkg = first(opf, 'package');
  const meta = first(opf, 'metadata');

  // ---- metadata
  const metas = all(meta, 'meta');
  const metaProp = (prop) => metas.find(m => m.getAttribute('property') === prop);
  const refines = (id, prop) => metas.find(m => m.getAttribute('refines') === '#' + id && m.getAttribute('property') === prop);
  const title = text(first(meta, 'title')) || 'Untitled';
  const creators = all(meta, 'creator').filter(c => {
    const role = c.getAttribute('opf:role') || c.getAttributeNS(NS.opf, 'role') || (c.id && text(refines(c.id, 'role')));
    return !role || role === 'aut';
  });
  const author = creators.map(text).filter(Boolean).join(', ') || '';
  const sortAuthorEl = creators[0] && (creators[0].getAttribute('opf:file-as') || creators[0].getAttributeNS(NS.opf, 'file-as') || (creators[0].id && text(refines(creators[0].id, 'file-as'))));
  const language = text(first(meta, 'language')) || 'en';
  const identifier = text(first(meta, 'identifier'));
  const publisher = text(first(meta, 'publisher'));
  const description = text(first(meta, 'description')).replace(/<[^>]+>/g, '');
  const date = text(first(meta, 'date'));
  let series = null, seriesIndex = null;
  const cal = metas.find(m => m.getAttribute('name') === 'calibre:series');
  if (cal) { series = cal.getAttribute('content'); const ix = metas.find(m => m.getAttribute('name') === 'calibre:series_index'); seriesIndex = ix ? +ix.getAttribute('content') : null; }
  const coll = metaProp('belongs-to-collection');
  if (coll) { series = text(coll); const pos = coll.id && refines(coll.id, 'group-position'); seriesIndex = pos ? +text(pos) : null; }
  const layout = text(metaProp('rendition:layout'));

  // ---- manifest
  const manifest = {};
  for (const item of all(first(opf, 'manifest'), 'item')) {
    const id = item.getAttribute('id');
    manifest[id] = {
      id,
      href: resolveURL(item.getAttribute('href'), opfURL),
      type: item.getAttribute('media-type') || '',
      props: (item.getAttribute('properties') || '').split(/\s+/),
    };
  }
  const manifestByHref = {};
  for (const m of Object.values(manifest)) manifestByHref[stripHash(m.href)] = m;

  // ---- spine (BKDocument[])
  const spineEl = first(opf, 'spine');
  const ppd = spineEl.getAttribute('page-progression-direction') || 'default';
  const spine = [];
  const itemrefs = all(spineEl, 'itemref');
  const spineStep = ([...pkg.children].indexOf(spineEl) + 1) * 2;
  itemrefs.forEach((ref, i) => {
    const m = manifest[ref.getAttribute('idref')];
    if (!m) return;
    spine.push({
      ordinal: spine.length,
      idref: m.id,
      href: m.href,
      type: m.type,
      linear: ref.getAttribute('linear') !== 'no',
      cfiStep: `/${spineStep}/${(i + 1) * 2}[${m.id}]`,
      props: (ref.getAttribute('properties') || '').split(/\s+/),
    });
  });
  const spineIndexByHref = {};
  spine.forEach((s, i) => (spineIndexByHref[stripHash(s.href)] = i));

  // ---- cover
  let cover = Object.values(manifest).find(m => m.props.includes('cover-image'));
  if (!cover) {
    const cm = metas.find(m => m.getAttribute('name') === 'cover');
    if (cm) cover = manifest[cm.getAttribute('content')] || Object.values(manifest).find(m => m.href.endsWith(cm.getAttribute('content')));
  }
  if (!cover) cover = Object.values(manifest).find(m => /^image\//.test(m.type) && /cover/i.test(m.id + m.href));
  let coverURL = cover && /^image\//.test(cover.type) ? cover.href : null;
  if (!coverURL) {
    // guide cover page or first spine doc -> first image
    const guideCover = all(opf, 'reference').find(r => /cover/i.test(r.getAttribute('type') || ''));
    const pageURL = guideCover ? resolveURL(guideCover.getAttribute('href'), opfURL) : (spine[0] && spine[0].href);
    if (pageURL) coverURL = await firstImageIn(pageURL);
  }

  // ---- Apple display options
  let displayOptions = {};
  try {
    const d = await fetchXML(resolveURL('META-INF/com.apple.ibooks.display-options.xml', baseURL));
    for (const o of all(d, 'option')) displayOptions[o.getAttribute('name')] = o.textContent.trim();
  } catch {}
  const fixedLayout = layout === 'pre-paginated' || displayOptions['fixed-layout'] === 'true';

  // ---- TOC / landmarks / page list
  let toc = [], landmarks = [], pageList = [];
  const navItem = Object.values(manifest).find(m => m.props.includes('nav'));
  if (navItem) {
    try {
      const nav = await fetchXML(navItem.href);
      for (const n of all(nav, 'nav')) {
        const type = n.getAttribute('epub:type') || n.getAttributeNS(NS.epub, 'type') || '';
        const ol = [...n.children].find(c => c.localName === 'ol');
        if (!ol) continue;
        const list = parseNavList(ol, navItem.href, 0);
        if (/\btoc\b/.test(type)) toc = list;
        else if (/landmarks/.test(type)) landmarks = flatten(list).map(x => ({ ...x }));
        else if (/page-list/.test(type)) pageList = flatten(list);
      }
    } catch {}
  }
  if (!toc.length) {
    const ncxId = spineEl.getAttribute('toc');
    const ncxItem = manifest[ncxId] || Object.values(manifest).find(m => m.type === 'application/x-dtbncx+xml');
    if (ncxItem) {
      try {
        const ncx = await fetchXML(ncxItem.href);
        const navMap = first(ncx, 'navMap');
        if (navMap) toc = parseNcx(navMap, ncxItem.href, 0);
        const pl = first(ncx, 'pageList');
        if (pl && !pageList.length) pageList = all(pl, 'pageTarget').map(p => ({ label: text(first(p, 'text')), href: resolveURL(first(p, 'content').getAttribute('src'), ncxItem.href) }));
      } catch {}
    }
  }
  if (!toc.length) toc = spine.filter(s => s.linear).map((s, i) => ({ label: `Chapter ${i + 1}`, href: s.href, level: 0, children: [] }));
  let order = 0;
  for (const t of flatten(toc)) { t.order = order++; t.spine = spineIndexByHref[stripHash(t.href)]; }

  return {
    title, author, sortAuthor: sortAuthorEl || lastFirst(author), language, identifier, publisher, description, date,
    series, seriesIndex, ppd, fixedLayout, displayOptions,
    opfURL, spine, manifest, toc, landmarks, pageList, coverURL,
    spineIndexByHref,
  };
}

function lastFirst(a) {
  const p = (a || '').split(',')[0].trim().split(/\s+/);
  return p.length > 1 ? p[p.length - 1] + ', ' + p.slice(0, -1).join(' ') : a;
}

async function firstImageIn(pageURL) {
  try {
    const doc = await fetchXML(stripHash(pageURL));
    const img = [...doc.getElementsByTagName('*')].find(e => e.localName === 'img' || e.localName === 'image');
    if (!img) return null;
    const src = img.getAttribute('src') || img.getAttribute('href') || img.getAttributeNS('http://www.w3.org/1999/xlink', 'href');
    return src ? resolveURL(src, pageURL) : null;
  } catch { return null; }
}

function parseNavList(ol, base, level) {
  const out = [];
  for (const li of [...ol.children].filter(c => c.localName === 'li')) {
    const a = [...li.children].find(c => c.localName === 'a' || c.localName === 'span');
    const sub = [...li.children].find(c => c.localName === 'ol');
    const href = a && a.getAttribute('href');
    out.push({
      label: text(a) || (a && a.getAttribute('title')) || '',
      href: href ? resolveURL(href, base) : null,
      type: a && (a.getAttribute('epub:type') || a.getAttributeNS(NS.epub, 'type')),
      level,
      children: sub ? parseNavList(sub, base, level + 1) : [],
    });
  }
  return out;
}

function parseNcx(parent, base, level) {
  return [...parent.children].filter(c => c.localName === 'navPoint').map(np => {
    const label = text(first(np, 'text'));
    const content = [...np.children].find(c => c.localName === 'content');
    return {
      label,
      href: content ? resolveURL(content.getAttribute('src'), base) : null,
      level,
      children: parseNcx(np, base, level + 1),
    };
  });
}

export function flatten(list, out = []) {
  for (const t of list) { out.push(t); if (t.children) flatten(t.children, out); }
  return out;
}

// Parse a chapter's source for the reader: XHTML first, HTML fallback (Books renders XHTML via WebKit).
const docCache = new Map();
export async function loadChapterText(url) {
  if (docCache.has(url)) return docCache.get(url);
  const p = fetch(url).then(r => r.text());
  docCache.set(url, p);
  if (docCache.size > 40) docCache.delete(docCache.keys().next().value);
  return p;
}
