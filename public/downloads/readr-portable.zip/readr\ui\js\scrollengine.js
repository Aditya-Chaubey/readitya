// "Scrolling View" (__ibooks_reading_mode = vertical-scroll): the spine laid out as one continuous
// column. Chapters are lazily loaded into auto-height iframes; position is still a CFI.
import * as CFI from './cfi.js';
import { loadChapterText, stripHash, flatten } from './epub.js';
import { parseChapter, PagedEngine, lockDown } from './epubengine.js';

const XHTML_NS = 'http://www.w3.org/1999/xhtml';

function blobFor(text, url, css) {
  const { doc, xml } = parseChapter(text, url);
  const html = doc.documentElement;
  const mk = t => (xml ? doc.createElementNS(XHTML_NS, t) : doc.createElement(t));
  const head = doc.head || [...html.children].find(c => c.localName === 'head');
  const base = mk('base'); base.setAttribute('href', url);
  const style = mk('style'); style.setAttribute('id', '__books_style'); style.textContent = css;
  const csp = lockDown(doc, mk);
  if (head) { head.insertBefore(base, head.firstChild); head.insertBefore(csp, head.firstChild); head.appendChild(style); }
  else { html.insertBefore(csp, html.firstChild); html.appendChild(base); html.appendChild(style); }
  html.setAttribute('__ibooks_reading_mode', 'vertical-scroll');
  html.setAttribute('__ibooks_writing_mode', 'horizontal-tb');
  const src = xml ? new XMLSerializer().serializeToString(doc) : '<!DOCTYPE html>\n' + html.outerHTML;
  return URL.createObjectURL(new Blob([src], { type: xml ? 'application/xhtml+xml' : 'text/html' }));
}

class Section {
  constructor(engine, i) {
    this.engine = engine;
    this.spine = i;
    this.el = document.createElement('section');
    this.el.className = 'scroll-section';
    this.el.style.height = '900px';
    this.iframe = null;
    this.ready = null;
  }
  get doc() { return this.iframe && this.iframe.contentDocument; }
  get win() { return this.iframe && this.iframe.contentWindow; }
  load() {
    if (this.ready) return this.ready;
    this.ready = (async () => {
      const e = this.engine;
      const item = e.book.spine[this.spine];
      const text = await loadChapterText(item.href);
      this.iframe = document.createElement('iframe');
      this.iframe.setAttribute('scrolling', 'no');
      this.iframe.title = 'Book content';
      this.el.appendChild(this.iframe);
      const url = blobFor(text, item.href, e.css);
      await new Promise(res => { this.iframe.onload = res; this.iframe.src = url; });
      URL.revokeObjectURL(url);
      this.styleEl = this.doc.getElementById('__books_style');
      e.wire(this);
      await Promise.race([this.doc.fonts.ready, new Promise(r => setTimeout(r, 1200))]);
      this.fit();
      try {
        this.ro = new this.win.ResizeObserver(() => this.fit());
        this.ro.observe(this.doc.documentElement);
      } catch {}
      e.applyHighlights(this);
      return this;
    })();
    return this.ready;
  }
  fit() {
    if (!this.doc) return;
    const h = Math.max(200, Math.ceil(this.doc.documentElement.scrollHeight));
    this.iframe.style.height = h + 'px';
    this.el.style.height = h + 'px';
  }
  restyle(css) { if (this.styleEl) { this.styleEl.textContent = css; this.fit(); } }
  // shared with PagedEngine helpers
  get se() { return this.doc && this.doc.documentElement; }
}

export class ScrollEngine {
  constructor(reader, book, stage) {
    this.reader = reader;
    this.book = book;
    this.stage = stage;
    this.counts = null;
    this.annotations = [];
    this.scroller = document.createElement('div');
    this.scroller.className = 'scroller';
    stage.appendChild(this.scroller);
    this.sections = book.spine.map((_, i) => new Section(this, i));
    for (const s of this.sections) this.scroller.appendChild(s.el);
    this.io = new IntersectionObserver(entries => {
      for (const en of entries) if (en.isIntersecting) this.sections[+en.target.dataset.i].load();
    }, { root: this.scroller, rootMargin: '1200px 0px' });
    this.sections.forEach((s, i) => { s.el.dataset.i = i; this.io.observe(s.el); });
    this.scroller.addEventListener('scroll', () => { clearTimeout(this._st); this._st = setTimeout(() => this.relocated(), 120); }, { passive: true });
  }

  configure(css, theme, geo) { this.css = css; this.theme = theme; this.geo = geo; }

  async display(target = {}) {
    let i = 0, y = 0;
    if (target.cfi) {
      const p = CFI.parse(target.cfi);
      i = Math.max(0, Math.min(this.sections.length - 1, p ? p.spineIndex : 0));
      const s = await this.sections[i].load();
      const pos = CFI.resolve(s.doc, target.cfi);
      y = pos ? this.yOf(s, pos.node, pos.offset) : 0;
    } else if (target.href) {
      i = this.book.spineIndexByHref[stripHash(target.href)];
      if (i == null) return false;
      const s = await this.sections[i].load();
      const hash = target.href.split('#')[1];
      const el = hash && s.doc.getElementById(decodeURIComponent(hash));
      y = el ? el.getBoundingClientRect().top - 20 : 0;
    } else if (target.fraction != null) {
      const f = target.fraction * this.sections.length;
      i = Math.min(this.sections.length - 1, Math.floor(f));
      const s = await this.sections[i].load();
      y = (f - i) * s.el.offsetHeight;
    } else {
      i = target.spine || 0;
      const s = await this.sections[i].load();
      if (target.page === 'last') y = s.el.offsetHeight - this.stage.clientHeight;
    }
    // load the previous section first so its real height doesn't shift us later
    if (i > 0) await this.sections[i - 1].load();
    this.scroller.scrollTop = this.sections[i].el.offsetTop + Math.max(0, y);
    this.relocated();
    return true;
  }
  yOf(s, node, offset) {
    let rect;
    if (node.nodeType === 3) {
      const r = s.doc.createRange();
      r.setStart(node, Math.min(offset || 0, node.nodeValue.length));
      r.collapse(true);
      rect = r.getClientRects()[0] || r.getBoundingClientRect();
    } else rect = node.getBoundingClientRect();
    return rect ? rect.top - 24 : 0;
  }

  async relayout(css, theme, geo) {
    const cfi = this.currentCFI();
    this.configure(css, theme, geo);
    for (const s of this.sections) s.restyle(css);
    if (cfi) await this.display({ cfi });
  }
  restyleOnly(css, theme) { this.css = css; this.theme = theme; for (const s of this.sections) if (s.styleEl) s.styleEl.textContent = css; }

  topSection() {
    const st = this.scroller.scrollTop;
    for (const s of this.sections) if (s.el.offsetTop + s.el.offsetHeight > st + 1) return s;
    return this.sections[this.sections.length - 1];
  }
  currentCFI() {
    const s = this.topSection();
    if (!s || !s.doc || !s.doc.body) return null;
    const item = this.book.spine[s.spine];
    const yIn = this.scroller.scrollTop - s.el.offsetTop;
    const g = this.geo;
    for (let dy = 4; dy < 400; dy += 12) {
      const r = s.doc.caretRangeFromPoint(g.side + 2, Math.max(0, yIn) + dy);
      if (r && s.doc.body.contains(r.startContainer)) return CFI.make(item.cfiStep, r.startContainer, r.startOffset);
    }
    return `epubcfi(${item.cfiStep}!/4)`;
  }

  relocated() {
    const s = this.topSection();
    if (!s) return;
    const st = this.scroller.scrollTop;
    const intra = s.el.offsetHeight ? Math.min(1, Math.max(0, (st - s.el.offsetTop) / s.el.offsetHeight)) : 0;
    const flat = flatten(this.book.toc);
    let chapter = null;
    for (const t of flat) if (t.spine != null && t.spine <= s.spine) chapter = t;
    const atEnd = st + this.scroller.clientHeight >= this.scroller.scrollHeight - 4;
    this.reader.onRelocate({
      spine: s.spine, page: 0, pages: 1, columns: 1,
      cfi: this.currentCFI(),
      fraction: Math.min(1, (s.spine + intra) / this.sections.length),
      chapter: { entry: chapter, label: chapter ? chapter.label : '', pagesLeft: 0 },
      atEnd,
    });
  }

  go(dir) {
    this.scroller.scrollBy({ top: dir * this.scroller.clientHeight * 0.9, behavior: 'smooth' });
    return Promise.resolve(true);
  }
  dragBegin() { return Promise.resolve(false); }
  dragUpdate() {}
  dragEnd() {}

  wire(s) {
    const doc = s.doc, r = this.reader;
    doc.addEventListener('click', e => r.onFrameClick(s, e));
    doc.addEventListener('mouseup', e => setTimeout(() => r.onFrameMouseUp(s, e), 0));
    doc.addEventListener('mousedown', e => r.onFrameMouseDown(s, e));
    doc.addEventListener('contextmenu', e => r.onFrameContext(s, e));
    doc.addEventListener('mousemove', e => { const fr = s.iframe.getBoundingClientRect(); r.onPointerMove(e.clientX + fr.left, e.clientY + fr.top); });
    doc.addEventListener('dragstart', e => e.preventDefault());
    doc.addEventListener('keydown', e => this.onKey(e));
    // forward wheel to the scroller (the iframe itself never scrolls)
    doc.addEventListener('wheel', e => {
      if (e.ctrlKey) { e.preventDefault(); return; }
      e.preventDefault();
      const k = e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? this.scroller.clientHeight : 1;
      this.scroller.scrollTop += e.deltaY * k;
    }, { passive: false });
  }
  onKey(e) {
    const k = e.key, H = this.scroller.clientHeight;
    const by = { ArrowDown: 60, ArrowUp: -60, PageDown: H * 0.9, PageUp: -H * 0.9, ' ': e.shiftKey ? -H * 0.9 : H * 0.9 }[k];
    if (by != null && !(e.ctrlKey || e.metaKey)) { e.preventDefault(); this.scroller.scrollBy({ top: by, behavior: 'smooth' }); return; }
    this.reader.onKey(e);
  }

  // annotations / search: shared implementations
  setAnnotations(list) { this.annotations = list; for (const s of this.sections) if (s.styleEl) this.applyHighlights(s); }
  isBookmarked(bookmarks) {
    const s = this.topSection();
    if (!s || !s.doc) return null;
    const top = this.scroller.scrollTop - s.el.offsetTop, bottom = top + this.scroller.clientHeight;
    for (const b of bookmarks) {
      const p = CFI.parse(b.start);
      if (!p || p.spineIndex !== s.spine) continue;
      const pos = CFI.resolve(s.doc, b.start);
      if (!pos) continue;
      const y = this.yOf(s, pos.node, pos.offset) + 24;
      if (y >= top - 2 && y < bottom) return b;
    }
    return null;
  }
  destroy() {
    this.io.disconnect();
    this.scroller.remove();
  }
}
// reuse the paged engine's annotation/search helpers (they only touch .doc/.win/.spine)
for (const k of ['applyHighlights', 'annotationAt', 'rangeCFIs', 'search', 'showSearchHit']) {
  ScrollEngine.prototype[k] = PagedEngine.prototype[k];
}
ScrollEngine.prototype.showSearchHit = function (hit) {
  this.searchHit = hit;
  for (const s of this.sections) if (s.styleEl) this.applyHighlights(s);
};
