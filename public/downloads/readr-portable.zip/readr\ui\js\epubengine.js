// EPUB rendering + pagination (BookEPUB's ContentLayoutController / PaginationQueue equivalent).
// Each spine document is rendered in an iframe ("one web view per visible page") and paginated
// natively by the engine's CSS multi-column layout. Pages are addressed as {spine, page} where
// page = spread index; positions persist as CFIs and survive any relayout.
import * as CFI from './cfi.js';
import { loadChapterText, stripHash, resolveURL, flatten } from './epub.js';

const XHTML_NS = 'http://www.w3.org/1999/xhtml';

// One parse routine shared by rendering and search so CFIs line up exactly.
export function parseChapter(text, url) {
  let doc = new DOMParser().parseFromString(text, 'application/xhtml+xml');
  let xml = true;
  if (doc.getElementsByTagName('parsererror').length || !doc.documentElement || doc.documentElement.localName !== 'html') {
    doc = new DOMParser().parseFromString(text, 'text/html');
    xml = false;
  }
  // neutralise scripts without changing element indices (CFI paths)
  for (const s of doc.querySelectorAll('script')) { s.setAttribute('type', 'text/x-disabled'); }
  for (const el of doc.querySelectorAll('*')) {
    for (const a of [...el.attributes]) if (/^on/i.test(a.name)) el.removeAttribute(a.name);
  }
  return { doc, xml };
}

// Book documents may never run code or reach the network: scripts, plugins, workers, fetches and forms
// are all refused (the parent page still drives the DOM). Mirrors the host's header on /lib/ files.
export const BOOK_CSP = "default-src https://books.local data: blob:; style-src https://books.local data: blob: 'unsafe-inline'; script-src 'none'; object-src 'none'; connect-src 'none'; " +
  "worker-src 'none'; form-action 'none'; frame-src https://books.local; base-uri https://books.local blob:";
export function lockDown(doc, mk) {
  for (const m of doc.querySelectorAll('meta[http-equiv]')) if (/refresh/i.test(m.getAttribute('http-equiv'))) m.remove();
  const meta = mk('meta');
  meta.setAttribute('http-equiv', 'Content-Security-Policy');
  meta.setAttribute('content', BOOK_CSP);
  return meta;
}

function buildBlob(text, url, css, attrs) {
  const { doc, xml } = parseChapter(text, url);
  const html = doc.documentElement;
  const mk = tag => (xml ? doc.createElementNS(XHTML_NS, tag) : doc.createElement(tag));
  let head = doc.head || [...html.children].find(c => c.localName === 'head');
  const base = mk('base');
  base.setAttribute('href', url);
  const style = mk('style');
  style.setAttribute('id', '__books_style');
  style.textContent = css;
  const csp = lockDown(doc, mk);
  if (head) { head.insertBefore(base, head.firstChild); head.insertBefore(csp, head.firstChild); head.appendChild(style); }
  else { html.insertBefore(csp, html.firstChild); html.appendChild(base); html.appendChild(style); } // before/after body: body CFI index unchanged
  for (const [k, v] of Object.entries(attrs)) html.setAttribute(k, v);
  const src = xml ? new XMLSerializer().serializeToString(doc) : '<!DOCTYPE html>\n' + html.outerHTML;
  return URL.createObjectURL(new Blob([src], { type: xml ? 'application/xhtml+xml' : 'text/html' }));
}

let frameSeq = 0;
class Frame {
  constructor(engine) {
    this.engine = engine;
    this.id = ++frameSeq;
    this.el = document.createElement('div');
    this.el.className = 'pv';
    this.iframe = document.createElement('iframe');
    this.iframe.setAttribute('title', 'Book page');
    this.iframe.setAttribute('scrolling', 'no');
    // el clips (rotated during a curl), inner counter-transforms the content; never re-parented
    this.inner = document.createElement('div');
    this.inner.className = 'pv-inner';
    this.inner.appendChild(this.iframe);
    this.el.appendChild(this.inner);
    engine.stage.insertBefore(this.el, engine.turner.flap);
    this.spine = -1;
    this.page = 0;
    this.columns = 1;
    this.pages = 1;
    this.ready = null;
    this.used = 0;
    this.hidden();
  }
  hidden() { this.el.style.visibility = 'hidden'; this.el.style.zIndex = '0'; }
  get doc() { return this.iframe.contentDocument; }
  get win() { return this.iframe.contentWindow; }
  get se() { const d = this.doc; return d && (d.scrollingElement || d.documentElement); }

  size(g) {
    this.iframe.style.width = g.W + 'px';
    this.iframe.style.height = g.H + 'px';
  }

  load(spine) {
    if (this.spine === spine && this.ready) return this.ready;
    this.spine = spine;
    this.page = 0;
    const token = (this.token = {});
    this.ready = (async () => {
      const e = this.engine;
      const item = e.book.spine[spine];
      const text = await loadChapterText(item.href);
      if (token !== this.token) throw new Error('superseded');
      this.size(e.geo);
      const url = buildBlob(text, item.href, e.css, {
        __ibooks_reading_mode: 'paged',
        __ibooks_writing_mode: 'horizontal-tb',
        __ibooks_internal_theme: e.theme.type,
        ...(e.geo.columns > 1 ? { __ibooks_has_multiple_pages: 'true' } : {}),
      });
      await new Promise(res => {
        this.iframe.onload = res;
        if (this.iframe.contentWindow && this.iframe.src) this.iframe.contentWindow.location.replace(url);
        else this.iframe.src = url;
      });
      URL.revokeObjectURL(url);
      if (token !== this.token) throw new Error('superseded');
      this.styleEl = this.doc.getElementById('__books_style');
      e.wire(this);
      await Promise.race([this.doc.fonts.ready, new Promise(r => setTimeout(r, 1500))]);
      this.measure();
      this.anchorPages = null;
      e.applyHighlights(this);
      // late font/image loads change pagination
      this.doc.fonts.addEventListener('loadingdone', () => this.remeasure());
      return this;
    })();
    this.ready.catch(() => {});
    return this.ready;
  }

  restyle(css) {
    if (this.styleEl) this.styleEl.textContent = css;
    this.size(this.engine.geo);
    this.measure();
    this.anchorPages = null;
  }

  measure() {
    const g = this.engine.geo;
    const se = this.se;
    if (!se) return;
    const stride = g.W / g.columns;
    // The browser clamps scrollLeft to the content's own width, which falls short of a whole spread
    // whenever a chapter ends on an odd column (two-up) or the end padding isn't counted — the last
    // page then lands shifted right and cuts into the margin. An invisible marker at the end of the
    // final spread keeps every page reachable at an exact multiple of the page width.
    const doc = this.doc;
    let end = doc.getElementById('__books_end');
    if (end) end.style.display = 'none';
    const sw = se.scrollWidth;
    this.columns = Math.max(1, Math.ceil((sw - 2) / stride));
    this.pages = Math.max(1, Math.ceil(this.columns / g.columns));
    if (!end) {
      end = doc.createElementNS('http://www.w3.org/1999/xhtml', 'div');
      end.id = '__books_end';
      doc.documentElement.appendChild(end); // after <body>: CFI paths are unaffected
    }
    end.setAttribute('style', `position:absolute!important;top:0!important;left:${this.pages * g.W - 1}px!important;width:1px!important;height:1px!important;margin:0!important;padding:0!important;display:block!important;visibility:hidden!important;pointer-events:none!important`);
    this.goto(Math.min(this.page, this.pages - 1));
  }
  remeasure() {
    const before = this.pages;
    this.measure();
    if (before !== this.pages) this.engine.frameChanged(this);
  }

  goto(page) {
    this.page = Math.max(0, Math.min(page, this.pages - 1));
    const se = this.se;
    if (se) se.scrollLeft = this.page * this.engine.geo.W;
  }

  // page (spread) containing a DOM rect's left edge
  pageForRect(r) {
    const g = this.engine.geo;
    const x = r.left + (this.se ? this.se.scrollLeft : 0);
    const col = Math.floor((x + 1) / (g.W / g.columns));
    return Math.max(0, Math.min(this.pages - 1, Math.floor(col / g.columns)));
  }
  pageForNode(node, offset) {
    const doc = this.doc;
    let rect = null;
    if (node.nodeType === 3) {
      const r = doc.createRange();
      const len = node.nodeValue.length;
      const o = Math.min(offset || 0, Math.max(0, len - 1));
      r.setStart(node, o); r.setEnd(node, Math.min(len, o + 1));
      rect = r.getClientRects()[0] || r.getBoundingClientRect();
    } else if (node.getBoundingClientRect) {
      rect = node.getClientRects()[0] || node.getBoundingClientRect();
    }
    if (!rect) return 0;
    return this.pageForRect(rect);
  }
}

export class PagedEngine {
  constructor(reader, book, stage, turner) {
    this.reader = reader;
    this.book = book;
    this.stage = stage;
    this.turner = turner;
    this.frames = [];
    this.cur = null;
    this.loc = { spine: 0, page: 0 };
    this.counts = null; // per-spine page counts for the current layout (global page numbers)
    this.queue = Promise.resolve();
    this.annotations = [];
    this.searchHit = null;
  }

  configure(css, theme, geo, layoutKey) {
    this.css = css; this.theme = theme; this.geo = geo; this.layoutKey = layoutKey;
  }

  // ---------- frames ----------
  frameFor(spine, exclude = []) {
    let f = this.frames.find(f => f.spine === spine && !exclude.includes(f));
    if (!f) {
      if (this.frames.length < 6) { f = new Frame(this); this.frames.push(f); }
      else {
        f = this.frames.filter(f => !exclude.includes(f) && f !== this.cur).sort((a, b) => a.used - b.used)[0];
      }
    }
    f.used = performance.now();
    return f.load(spine).then(() => f);
  }
  async positioned(loc, exclude = []) {
    // prefer a frame of that spine already on the right page
    let f = this.frames.find(f => f.spine === loc.spine && f.page === loc.page && f.ready && !exclude.includes(f));
    if (f) { await f.ready; f.used = performance.now(); return f; }
    f = await this.frameFor(loc.spine, exclude);
    f.goto(loc.page);
    return f;
  }

  showFrame(f) {
    for (const o of this.frames) if (o !== f) o.hidden();
    f.el.style.visibility = 'visible';
    f.el.style.zIndex = '2';
    this.cur = f;
  }

  // ---------- navigation ----------
  async display(target = {}) {
    let spine = 0, page = 0, f;
    if (target.cfi) {
      const p = CFI.parse(target.cfi);
      spine = clampSpine(this.book, p ? p.spineIndex : 0);
      f = await this.frameFor(spine, []);
      const pos = CFI.resolve(f.doc, target.cfi);
      page = pos ? f.pageForNode(pos.node, pos.offset) : 0;
    } else if (target.href) {
      const url = stripHash(target.href);
      spine = this.book.spineIndexByHref[url];
      if (spine == null) return false;
      f = await this.frameFor(spine, []);
      const hash = target.href.split('#')[1];
      const el = hash && f.doc.getElementById(decodeURIComponent(hash));
      page = el ? f.pageForNode(el) : 0;
    } else if (target.fraction != null && this.counts) {
      const total = this.counts.reduce((a, b) => a + b, 0);
      let n = Math.min(total - 1, Math.floor(target.fraction * total));
      spine = 0;
      while (spine < this.counts.length - 1 && n >= this.counts[spine]) { n -= this.counts[spine]; spine++; }
      page = n;
      f = await this.frameFor(spine, []);
    } else {
      spine = clampSpine(this.book, target.spine || 0);
      f = await this.frameFor(spine, []);
      page = target.page === 'last' ? f.pages - 1 : (target.page || 0);
    }
    f.goto(page);
    this.showFrame(f);
    this.loc = { spine, page: f.page };
    this.anchorCFI = target.cfi || null;
    this.relocated();
    this.preload();
    return true;
  }

  async neighbor(dir, from = this.loc) {
    const f = this.frames.find(x => x.spine === from.spine && x.ready) || (await this.frameFor(from.spine, []));
    await f.ready;
    if (dir > 0) {
      if (from.page + 1 < f.pages) return { spine: from.spine, page: from.page + 1 };
      if (from.spine + 1 < this.book.spine.length) return { spine: from.spine + 1, page: 0 };
      return null;
    }
    if (from.page > 0) return { spine: from.spine, page: from.page - 1 };
    if (from.spine > 0) {
      const pf = await this.frameFor(from.spine - 1, [this.cur]);
      return { spine: from.spine - 1, page: pf.pages - 1 };
    }
    return null;
  }

  preload() {
    clearTimeout(this._preT);
    this._preT = setTimeout(async () => {
      try {
        const keep = [this.cur];
        const n = await this.neighbor(1);
        if (n) keep.push(await this.positioned(n, keep));
        if (this.reader.settings.turn === 'curl' && this.geo.columns > 1 && n) keep.push(await this.positioned(n, keep));
        const p = await this.neighbor(-1);
        if (p) keep.push(await this.positioned(p, keep));
      } catch {}
    }, 30);
  }

  // Serialise turns, but never build a backlog: at most one turn running plus one waiting.
  // (Held arrow keys auto-repeat ~30×/s; queueing all of them kept pages turning long after release.)
  get turning() { return (this._pending || 0) > 0; }
  go(dir, opts = {}) {
    if ((this._pending || 0) >= 2) return this.queue;
    this._pending = (this._pending || 0) + 1;
    this.queue = this.queue.then(() => this._go(dir, opts)).catch(e => console.warn(e)).finally(() => { this._pending--; });
    return this.queue;
  }
  async _go(dir, opts = {}) {
    const target = await this.neighbor(dir);
    if (!target) { await this.turner.bounce(this.cur, dir); this.reader.atEdge(dir); return false; }
    const from = this.cur;
    const to = await this.positioned(target, [from]);
    const style = this.reader.turnStyle();
    let flapView = null;
    if (style === 'curl' && this.geo.columns > 1) flapView = await this.positioned(dir > 0 ? target : this.loc, [from, to]);
    this.reader.chromeDuringTurn(true);
    await this.turner.turn(style, dir, from, to, { twoUp: this.geo.columns > 1, flapView, fast: opts.fast });
    this.reader.chromeDuringTurn(false);
    this.showFrame(to);
    this.loc = target;
    this.anchorCFI = null;
    this.relocated();
    this.preload();
    return true;
  }

  // interactive turn (swipe / drag)
  async dragBegin(dir) {
    if (this.turner.busy) return false;
    const target = await this.neighbor(dir);
    if (!target) return false;
    const from = this.cur;
    const to = await this.positioned(target, [from]);
    const style = this.reader.turnStyle();
    let flapView = null;
    if (style === 'curl' && this.geo.columns > 1) flapView = await this.positioned(dir > 0 ? target : this.loc, [from, to]);
    this._drag = { dir, target, from, to };
    this.turner.beginDrag(style, dir, from, to, { twoUp: this.geo.columns > 1, flapView });
    this.reader.chromeDuringTurn(true);
    return true;
  }
  dragUpdate(p, point) { if (this._drag) this.turner.updateDrag(p, point); }
  async dragEnd(commit) {
    const d = this._drag;
    if (!d) return;
    this._drag = null;
    const done = await this.turner.endDrag(commit);
    this.reader.chromeDuringTurn(false);
    if (done) {
      this.showFrame(d.to);
      this.loc = d.target;
      this.anchorCFI = null;
      this.relocated();
      this.preload();
    } else this.showFrame(d.from);
  }

  // ---------- layout ----------
  async relayout(css, theme, geo, layoutKey) {
    const cfi = this.anchorCFI || this.currentCFI();
    const sizeChanged = !this.geo || geo.W !== this.geo.W || geo.H !== this.geo.H || geo.columns !== this.geo.columns;
    this.configure(css, theme, geo, layoutKey);
    for (const f of this.frames) {
      if (!f.styleEl) continue;
      f.restyle(css);
      f.doc.documentElement.setAttribute('__ibooks_internal_theme', theme.type);
      if (geo.columns > 1) f.doc.documentElement.setAttribute('__ibooks_has_multiple_pages', 'true');
      else f.doc.documentElement.removeAttribute('__ibooks_has_multiple_pages');
    }
    if (sizeChanged || true) {
      this.counts = null;
      await this.display(cfi ? { cfi } : { spine: this.loc.spine, page: 0 });
      this.anchorCFI = cfi;
      this.paginateAll();
    }
  }
  restyleOnly(css, theme) {
    // colour-only change: no re-pagination
    this.css = css; this.theme = theme;
    for (const f of this.frames) {
      if (!f.styleEl) continue;
      f.styleEl.textContent = css;
      f.doc.documentElement.setAttribute('__ibooks_internal_theme', theme.type);
    }
  }

  frameChanged(f) {
    if (f === this.cur) {
      if (this.anchorCFI) {
        const pos = CFI.resolve(f.doc, this.anchorCFI);
        if (pos) f.goto(f.pageForNode(pos.node, pos.offset));
      }
      this.loc = { spine: f.spine, page: f.page };
      this.relocated();
    }
  }

  // Global page numbers: paginate every spine document in a hidden frame (PaginationQueue),
  // cached per layout key like PaginationCache.
  async paginateAll() {
    const token = (this._pagToken = {});
    const key = this.layoutKey;
    let cached = this.reader.pageCache && this.reader.pageCache[key];
    if (Array.isArray(cached)) cached = { counts: cached, anchors: {} };
    if (cached && cached.counts && cached.counts.length === this.book.spine.length) {
      this.counts = cached.counts.slice();
      this.anchors = cached.anchors || {};
      this.relocated();
      return;
    }
    const counts = new Array(this.book.spine.length).fill(0);
    const anchors = {};
    const tocBySpine = {};
    for (const t of flatten(this.book.toc)) {
      if (t.spine != null && t.href && t.href.includes('#')) (tocBySpine[t.spine] = tocBySpine[t.spine] || []).push(t.href.split('#')[1]);
    }
    const record = (i, f) => { for (const hash of tocBySpine[i] || []) anchors[i + '#' + hash] = this.anchorPage(f, hash); };
    if (!this.measurer) {
      this.measurer = new Frame(this);
      this.measurer.el.classList.add('measurer');
    }
    const m = this.measurer;
    for (let i = 0; i < counts.length; i++) {
      if (token !== this._pagToken) return;
      const live = this.frames.find(f => f.spine === i && f.styleEl);
      if (live) { counts[i] = live.pages; record(i, live); continue; }
      try {
        m.spine = -1;
        await m.load(i);
        counts[i] = m.pages;
        record(i, m);
      } catch { counts[i] = 1; }
      await new Promise(r => setTimeout(r, 0));
    }
    if (token !== this._pagToken) return;
    this.counts = counts;
    this.anchors = anchors;
    this.reader.savePageCounts(key, { counts, anchors });
    this.relocated();
  }

  // ---------- position ----------
  currentCFI(frame = this.cur) {
    if (!frame || !frame.doc || !frame.doc.body) return null;
    const g = this.geo, doc = frame.doc;
    const item = this.book.spine[frame.spine];
    for (let y = g.top + 2; y < g.H - g.bottom; y += 10) {
      for (const x of [g.side + 1, g.side + 24, g.side + g.contentW / 2]) {
        const r = doc.caretRangeFromPoint && doc.caretRangeFromPoint(x, y);
        if (r && doc.body.contains(r.startContainer)) {
          const rect = r.getBoundingClientRect();
          if (rect.left > g.W || rect.right < 0) continue;
          return CFI.make(item.cfiStep, r.startContainer, r.startOffset);
        }
      }
    }
    // image-only page: first element starting on this page
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_ELEMENT);
    let n;
    while ((n = walker.nextNode())) {
      const r = n.getBoundingClientRect();
      if (r.width && r.left >= -1 && r.left < g.W) return CFI.make(item.cfiStep, n, 0);
    }
    return `epubcfi(${item.cfiStep}!/4)`;
  }

  // visible text range of the current page (for bookmarks)
  pageRangeCFIs() {
    const start = this.currentCFI();
    return { start };
  }

  relocated() {
    const f = this.cur;
    if (!f) return;
    const info = {
      spine: this.loc.spine,
      page: this.loc.page,
      pages: f.pages,
      columns: this.geo.columns,
      cfi: this.anchorCFI || this.currentCFI(),
    };
    if (this.counts) {
      const before = this.counts.slice(0, info.spine).reduce((a, b) => a + b, 0);
      info.total = this.counts.reduce((a, b) => a + b, 0);
      info.global = before + info.page;
      info.fraction = info.total > 1 ? info.global / (info.total - 1) : 0;
      info.totalColumns = info.total * this.geo.columns;
    } else {
      // estimate by spine position until pagination completes
      info.fraction = (info.spine + (f.pages > 1 ? info.page / (f.pages - 1) : 0)) / Math.max(1, this.book.spine.length);
    }
    info.atEnd = info.spine === this.book.spine.length - 1 && info.page >= f.pages - 1;
    info.chapter = this.chapterAt(f, info.page);
    this.reader.onRelocate(info);
  }

  chapterAt(f, page) {
    const flat = flatten(this.book.toc);
    let best = null;
    for (const t of flat) {
      if (t.spine == null) continue;
      if (t.spine < f.spine) best = t;
      else if (t.spine === f.spine) {
        const hash = t.href && t.href.split('#')[1];
        if (!hash) { best = t; continue; }
        const p = this.anchorPage(f, hash);
        if (p <= page) best = t;
      }
    }
    // pages left in this chapter: until the next TOC anchor in this document, else document end
    let end = f.pages;
    for (const t of flat) {
      if (t.spine === f.spine && t !== best && t.href && t.href.includes('#')) {
        const p = this.anchorPage(f, t.href.split('#')[1]);
        if (p > page && p < end) end = p;
      }
    }
    return { entry: best, label: best ? best.label : '', pagesLeft: Math.max(0, end - page - 1) };
  }
  anchorPage(f, hash) {
    f.anchorPages = f.anchorPages || {};
    if (hash in f.anchorPages) return f.anchorPages[hash];
    const el = f.doc && f.doc.getElementById(decodeURIComponent(hash));
    return (f.anchorPages[hash] = el ? f.pageForNode(el) : 0);
  }

  // ---------- annotations ----------
  setAnnotations(list) {
    this.annotations = list;
    for (const f of this.frames) if (f.styleEl) this.applyHighlights(f);
  }
  applyHighlights(f) {
    const win = f.win;
    if (!win || !win.CSS || !win.CSS.highlights) return;
    const reg = win.CSS.highlights;
    reg.clear();
    f.ranges = [];
    const groups = {};
    for (const a of this.annotations) {
      if (a.type !== 'highlight' || a.deleted) continue;
      const p = CFI.parse(a.start);
      if (!p || p.spineIndex !== f.spine) continue;
      const r = CFI.toRange(f.doc, a.start, a.end);
      if (!r) continue;
      f.ranges.push({ a, r });
      const key = a.underline ? 0 : a.style;
      (groups[key] = groups[key] || []).push(r);
    }
    for (const [k, ranges] of Object.entries(groups)) reg.set('hl-' + k, new win.Highlight(...ranges));
    if (this.searchHit && this.searchHit.spine === f.spine) {
      const r = CFI.toRange(f.doc, this.searchHit.start, this.searchHit.end);
      if (r) reg.set('hl-search', new win.Highlight(r));
    }
  }
  annotationAt(f, x, y) {
    if (!f.ranges || !f.ranges.length) return null;
    const c = f.doc.caretRangeFromPoint(x, y);
    if (!c) return null;
    for (const { a, r } of f.ranges) {
      try {
        if (r.isPointInRange(c.startContainer, c.startOffset)) {
          // make sure the point is actually over the text, not the line end
          for (const rect of r.getClientRects()) if (x >= rect.left - 1 && x <= rect.right + 1 && y >= rect.top - 1 && y <= rect.bottom + 1) return { a, r };
        }
      } catch {}
    }
    return null;
  }
  rangeCFIs(f, range) {
    const item = this.book.spine[f.spine];
    return {
      start: CFI.make(item.cfiStep, range.startContainer, range.startOffset),
      end: CFI.make(item.cfiStep, range.endContainer, range.endOffset),
    };
  }
  pageOfCFI(cfi) {
    // global page number for a CFI, when its document is loaded and counts are known
    const p = CFI.parse(cfi);
    if (!p || !this.counts) return null;
    const f = this.frames.find(f => f.spine === p.spineIndex && f.styleEl);
    if (!f) return null;
    const pos = CFI.resolve(f.doc, cfi);
    if (!pos) return null;
    const page = f.pageForNode(pos.node, pos.offset);
    return this.counts.slice(0, p.spineIndex).reduce((a, b) => a + b, 0) + page;
  }
  isBookmarked(bookmarks) {
    const f = this.cur;
    if (!f || !f.doc) return null;
    for (const b of bookmarks) {
      const p = CFI.parse(b.start);
      if (!p || p.spineIndex !== f.spine) continue;
      const pos = CFI.resolve(f.doc, b.start);
      if (pos && f.pageForNode(pos.node, pos.offset) === f.page) return b;
    }
    return null;
  }

  // ---------- search (whole book) ----------
  async search(query, onResult, token) {
    const q = query.trim().toLocaleLowerCase();
    if (!q) return;
    const flat = flatten(this.book.toc);
    for (let i = 0; i < this.book.spine.length; i++) {
      if (token.cancelled) return;
      const item = this.book.spine[i];
      let text;
      try { text = await loadChapterText(item.href); } catch { continue; }
      const { doc } = parseChapter(text, item.href);
      if (!doc.body) continue;
      const prior = [...flat].reverse().find(t => t.spine != null && t.spine < i);
      const marks = flat.filter(t => t.spine === i).map(t => {
        const hash = t.href && t.href.split('#')[1];
        return { t, el: hash ? doc.getElementById(decodeURIComponent(hash)) : doc.body };
      }).filter(m => m.el);
      const chapterFor = node => {
        let best = prior;
        for (const m of marks) {
          if (m.el === node || m.el.contains(node) || (m.el.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_FOLLOWING)) best = m.t;
        }
        return best;
      };
      const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
      let n, count = 0;
      while ((n = walker.nextNode())) {
        const s = n.nodeValue.toLocaleLowerCase();
        let at = s.indexOf(q);
        const chapter = at >= 0 ? chapterFor(n) : null;
        while (at >= 0) {
          const full = n.nodeValue;
          const pre = full.slice(Math.max(0, at - 40), at);
          const post = full.slice(at + q.length, at + q.length + 70);
          onResult({
            spine: i,
            chapter: chapter ? chapter.label : '',
            start: CFI.make(item.cfiStep, n, at),
            end: CFI.make(item.cfiStep, n, at + q.length),
            before: (at > 40 ? '…' : '') + pre.replace(/\s+/g, ' ').trimStart(),
            match: full.slice(at, at + q.length),
            after: post.replace(/\s+/g, ' ') + (post.length >= 70 ? '…' : ''),
          });
          if (++count > 400) break;
          at = s.indexOf(q, at + q.length);
        }
      }
      await new Promise(r => setTimeout(r, 0));
    }
  }
  showSearchHit(hit) {
    this.searchHit = hit;
    for (const f of this.frames) if (f.styleEl) this.applyHighlights(f);
  }

  // ---------- events from content frames ----------
  wire(f) {
    const doc = f.doc;
    const r = this.reader;
    doc.addEventListener('click', e => r.onFrameClick(f, e));
    doc.addEventListener('mouseup', e => setTimeout(() => r.onFrameMouseUp(f, e), 0));
    doc.addEventListener('mousedown', e => r.onFrameMouseDown(f, e));
    doc.addEventListener('wheel', e => r.onWheel(e), { passive: false });
    doc.addEventListener('keydown', e => r.onKey(e));
    doc.addEventListener('contextmenu', e => r.onFrameContext(f, e));
    doc.addEventListener('mousemove', e => r.onPointerMove(e.clientX, e.clientY));
    doc.addEventListener('pointerdown', e => r.onFramePointerDown(f, e));
    doc.addEventListener('dragstart', e => e.preventDefault());
    doc.addEventListener('scroll', () => {
      // keep the column grid locked (selection autoscroll, find, focus)
      const want = f.page * this.geo.W;
      if (Math.abs(f.se.scrollLeft - want) > 1) f.se.scrollLeft = want;
      if (f.se.scrollTop) f.se.scrollTop = 0;
    });
  }

  destroy() {
    this._pagToken = {};
    for (const f of this.frames) f.el.remove();
    if (this.measurer) this.measurer.el.remove();
    this.frames = [];
  }
}

function clampSpine(book, i) { return Math.max(0, Math.min(book.spine.length - 1, i | 0)); }
export { resolveURL };
